# Changes made to xboxrecomp 0.12.0 for The Two Towers

This lists every change made to the vendored toolkit (and the game project) while bringing the game up, oldest first. Version numbers are internal test builds.

```text
Fixes made to xboxrecomp 0.12.0 while bringing up The Two Towers
=================================================================

kernel/kernel_rtl.c, kernel/kernel_bridge.c
  RtlTryEnterCriticalSection (306) used a separate host lock table from
  Enter/Leave, so a lock taken with TryEnter and released with
  RtlLeaveCriticalSection was never released (and Leave dropped a lock it
  never took). TryEnter now shares the Enter/Leave shadow.

kernel/nv2a_pb_scan.c
  The pushbuffer walker stopped at the first JUMP. D3D's recorded
  pushbuffers jump out of the ring and back, so everything after the jump
  was lost (including InsertCallback traps). Jumps, calls and returns are now
  followed; a jump at the end of a segment (ring wrap) still ends it.

kernel/nv2a_pb_exec.c
  - SET_CONTEXT_DMA_SEMAPHORE (0x1A4), SEMAPHORE_OFFSET (0x1D6C) and
    BACK_END_WRITE_SEMAPHORE_RELEASE (0x1D70) implemented, with RAMHT/RAMIN
    lookup of the DMA object: D3D's GPU time stamp now advances.
  - D3D InsertCallback (0x1D8C fn/ctx + NOP 6/7) is queued for the CPU.

kernel/kernel_bridge.c
  The timer thread runs the queued D3D callbacks, one at a time with a short
  pause, so the CPU sees every value a callback publishes.

kernel/xbox_memory_layout.c
  - A PUT slightly below the previous one (a kick from another thread) is no
    longer treated as a ring wrap; that re-ran old commands, including old
    semaphore releases, and wound the GPU time back.
  - XBOX_LOW_AREA_BASE is overridable (the title's image is 9 MB, past the
    default low area).

kernel/kernel_memory.c, usb/ohci.c
  OHCI read descriptor addresses as virtual addresses. They are physical:
  contiguous memory is seen through 0x80000000, and ordinary memory (the VA
  returned by MmGetPhysicalAddress) is remembered per page so the two can be
  told apart. An HCCA at physical 0 is valid.

platform/mmio_decode.h
  ALU reg, [mem] forms (add/or/and/sub/xor/cmp) for trapped registers.

apu/apu_mmio_hook.c
  MOVS/STOS (with REP) against APU memory.

apu/apu_xaudio2.c
  RECOMP_AUDIO_OUT=0 skips the XAudio2 output (hosts without audio).

tools/recomp/lifter.py
  rep movs never uses memcpy when either side is in the MMIO range
  (>= 0xFE000000): memcpy's SSE moves can't be decoded by the MMIO traps.

tools/ghidra_naming/run_ghidra.sh
  Works on Linux/macOS (analyzeHeadless, python3).

--- later fixes ---

kernel/nv2a_pb_scan.c, nv2a_pb_exec.c, xbox_memory_layout.c
  The pushbuffer is fetched from a persistent GET (nv2a_pb_run) that follows
  JUMP/CALL/RETURN and stops at PUT, run synchronously from D3D's KickOff as
  well as the poller. Semaphore methods (0x1A4/0x1D6C/0x1D70) and the NOP
  callback traps (5 = idle, 6/7 = InsertCallback) are executed.

kernel/kernel_bridge.c, kernel_hal.c, kernel_rtl.c
  KEVENTs the guest builds inline are shadowed so Wait/Set/Pulse/Reset agree;
  RtlTryEnterCriticalSection shares the Enter shadow; a dispatch lock models
  the single Xbox CPU (timer DPCs take it); pushfd/popfd/cpuid helpers report a
  Pentium III with MMX/SSE (Bink picks its blitters from cpuid).

apu/apu_core.c
  The XAudio2 monitor path submits the VP/DSP output frame (it used to clear
  the buffer, so nothing the game played was audible).

tools/recomp/lifter.py, translator.py, __main__.py
  - pushfd/popfd/cpuid lifted.
  - Mid-function call/jump targets are lifted as fragments of the containing
    function (recomp_fragments.c) instead of esp-corrupting stubs.
  - Manual wrappers (extern void sub_X_gen) receive direct calls too.
  - Found by a differential test of every instruction shape in the XBE
    (lifted C vs. the same instruction run natively, tools in
    differential-test/):
      * movsx r32, bp/sp did not sign-extend.
      * rol/ror did not set CF (a following jb/jae read a stale carry).
      * cvtss2si/cvtsd2si truncated; they round to nearest like MXCSR says.
      * sqrtps/rsqrtps/rcpps only computed the low lane.
      * fld/fstp tbyte (80-bit) were no-ops; fstp tbyte did not pop.
templates/runtime/recomp_types.h
  XMM_SQRT/RSQRT/RCP lane helpers, recomp_cvt*2si, recomp_ld80/st80.

--- v9 ---
config/seed_functions.json (game)
  11 function starts that were only reached by jmp (C++ static constructor
  bodies such as the camera/cinematic manager at 0x22C30) were stubbed as
  "unresolved"; seeded so they are recompiled. Fixes the crash after the
  montage.
kernel/nv2a_sw3d.inc (new), nv2a_pb_exec.c
  Software 3D: vertex program interpreter, fixed-function composite
  transform, w-clipping, perspective-correct rasteriser, depth + stencil
  buffers, register combiners over 4 texture stages (bilinear), alpha test,
  full blend factors/equations, colour write mask; S1/S32K/CMP vertex
  formats; ARRAY_ELEMENT32; 32-bit indices.
kernel/kernel_thread.c
  KeDelayExecutionThread: timeBeginPeriod(1) and QPC-timed short delays.

--- v10 ---
apu/apu_shim.h
  Physical addresses are resolved like the OHCI model does: identity pages
  (ordinary memory) map to low RAM, everything else to the contiguous window.
  The APU used to treat all of them as low RAM, so DirectSound's voice array
  (contiguous) was written into the middle of the game's heap and the play
  cursor the game read never moved -- the "audio loops" bug.
apu/apu_vp.c
  Voices are resampled by their pitch (linear interpolation) instead of all
  being played at 48 kHz.
apu/apu_core.c, kernel/kernel_bridge.c
  The APU interrupt line reaches DirectSound's ISR (vector 5).
kernel/kernel_bridge.c
  Vblank is paced at 60 Hz on the performance counter (was ~50 Hz), timer
  thread wakes every 2 ms.
kernel/kernel_hal.c (+ several files)
  getenv results cached: the per-method diagnostic switches were a large part
  of the frame time (about 10x faster 3D in testing).
kernel/nv2a_sw3d.inc
  Stencil buffer; decoded texture cache with wrap/mirror/clamp; NV2A fog
  factor; mirror addressing.

--- v11 ---
apu/apu_core.c
  The APU frame thread runs at time-critical priority, and when it is late it
  catches up instead of dropping the time (the sound clock kept slowing on a
  busy single core; Bink paces its video by it, so intros crawled/froze).
  The log now prints "[FPS] n flips, apu m periods" once a second
  (187 periods/s = sound running in real time).
kernel/kernel_bridge.c
  Timer/vblank thread at high priority.

--- v12 ---
kernel/kernel_bridge.c
  APU interrupt delivery is now opt-in (RECOMP_APU_IRQ=1). DirectSound's DPC
  takes the DirectSound critical section; run from the timer thread while a
  game thread held it, both stalled until the dispatch-lock timeout: the
  multi-second freezes of v10/v11 on Windows. Timer thread back to normal
  priority; APU thread above normal (was time-critical).

--- v13 ---
kernel/kernel_rtl.c
  Guest critical sections hand the lock to a waiting thread on release
  (Windows critical sections are unfair; on one core Bink's background thread
  re-took its lock in a tight loop and the video decoder starved -- the EA
  logo freeze in v12 on Windows).
kernel/kernel_sync.c
  A zero-timeout wait that times out yields the CPU.

--- v14 (diagnostic) ---
kernel/kernel_rtl.c
  [CSHOT] report: samples guest critical-section enters and prints the
  hottest call site with a guest backtrace every 20M enters.

--- v15 ---
src/twotowers_manual.c (game)
  Wrapper on DirectSound's voice GetStatus (0x0012F10A). A stopped voice
  stays "playing" (flags 0x8001) until the APU interrupt reports the release
  finished, or until DirectSoundDoWork's 0.5 s timeout (0x0012DB00) forces it.
  Bink stops its sound at the end of a movie and spins on GetStatus until it
  reads 0; with the interrupt off and no DoWork on that thread it spun forever
  (the EA logo freeze on Windows, found from the v14 [CSHOT] log: main thread
  in 0x148B33 -> 0x12A092 -> 0x1293DF). The wrapper runs DSound's own timeout
  check from the poll, so a stop always completes within 0.5 s.

--- v16 (graphics) ---
kernel/nv2a_pb_exec.c, nv2a_sw3d.inc
  - CLEAR_SURFACE honours the per-channel mask. The game clears only alpha
    mid-frame (to build a light mask); clearing all four channels wiped the
    whole rendered scene -- the main reason gameplay was black.
  - Screen-space passes that the old 2D path could not draw correctly
    (stencil, reverse-subtract blending, partial colour masks, colour from
    combiner constants, depth-as-texture) now go through the full 3D pipeline.
    The shadow pass used to paint the screen dark grey.
  - Depth buffer is written back to guest memory (Z24S8) when the game samples
    it as a texture (depth-based post pass).
  - Image blit (D3D CopyRects, NV062/NV09F on subchannels 3/2) implemented:
    the heat-haze pass copies part of the back buffer; without it, black boxes.
  - Textures decoded from a surface the GPU drew into are re-decoded after
    the draw (render-to-texture was stale).
  - Combiners decoded once per batch; attribute interpolation limited to what
    the combiners read; per-row span solving. About 30% less time per frame.
  - Raster threads (bands of rows) for big batches -- only active when the
    game is not pinned to one core (ini [Compat] single_cpu=3, experimental).
  - Developer tools: RECOMP_CAPTURE=<flip>[,every] writes a frame capture,
    RECOMP_REPLAY=<file> re-renders it without the game (seconds instead of
    minutes per experiment), RECOMP_BATCHLOG, RECOMP_DIAG_BATCH, RECOMP_REPLAY_TRACE.

--- v17 ---
tools/disasm/functions.py
  _pass_imm_ref_targets no longer accepts an immediate that lands inside the
  straight-line body of a target it has just accepted. The Two Towers'
  0x0002BC40 (picks an object's material: arg or this->0x5F4) was cut at
  0x2BC47 and 0x2BC90 by two integer constants; the `je` in the second piece
  never saw the `test` in the first, so every character was drawn with a NULL
  material -- texture offset 0, format 0 -- and came out as a black
  silhouette. Characters, weapons and armour are textured now.
src/twotowers_manual.c (game)
  Diagnostic wrapper on D3DDevice_SetTexture (0x00117AD0): with TT_DEBUG=1 it
  logs textures that were never registered (Format 0) and who bound them.

--- v18 ---
kernel/kernel_hal.c
  The guest's IRQL is mirrored into the KPCR byte it reads (fs:[0x24]).
  DirectSound's lock helper (0x00128C07) skips its critical section at
  DISPATCH_LEVEL; with the byte always 0 its DPC (run from the timer thread
  under the dispatch lock) waited on a game thread that was waiting for the
  dispatch lock -- the multi-second freezes when the sound interrupt was on.
kernel/kernel_bridge.c
  APU (sound) interrupt delivery is on again by default (RECOMP_NO_APU_IRQ=1
  turns it off). Stopped voices complete through DirectSound's interrupt
  path again instead of hanging in "stopping" (sound cutting out after the EA
  logo, long freeze between the montage and the level).
src/main.c, src/twotowers_host.h (game)
  Single-CPU mode no longer pins the whole process. A TLS callback pins every
  thread to CPU 0 as it starts; the renderer's raster threads move themselves
  to the other cores, so big draw calls are split across up to 4 cores.
  [Compat] single_cpu=2 restores the old whole-process pin.
nv2a_sw3d.inc
  Raster threads take their affinity themselves; shorter idle spin.

--- v19 ---
src/twotowers_manual.c (game)
  A voice still "stopping" a second after the game started polling it is
  force-stopped (0x0012DA17); if even that does not take, its stopping/
  playing bits are cleared. v18 on Windows still had one voice polled ten
  million times while the sound went quiet. Logged as [DSOUND].
src/main.c, src/twotowers_host.h (game)
  All-threads sampling profiler, on by default for now ([Developer] profile=0
  turns it off): every 20 s the log gets [PROFT] lines per thread, which show
  where the time goes on the player's machine (movies run at ~12 fps on
  Windows but 30 in Wine).

--- v20 ---
kernel/nv2a_d3d11.inc, kernel/nv2a_d3d11_shaders.h (new)
  Direct3D 11 renderer for the NV2A, now the default. Vertex programs still
  run on the CPU; everything after that is on the graphics card: rasterising,
  depth/stencil, blending, fog, alpha test, and the register combiners (an
  uber pixel shader runs the game's combiner program from a constant buffer).
  Render targets, depth buffers and textures are cached on the GPU by guest
  address; clears, CopyRects blits and depth-as-texture reads are done there.
  The picture is presented through a DXGI swap chain on the game window.
  [Display] renderer=software (or RECOMP_RENDERER=software) goes back to the
  CPU renderer, which is also used automatically if no D3D11 device exists.
kernel/xbox_memory_layout.c
  - PUT and GET are read under the pushbuffer lock. Read before it, a poll
    that lost the race to a newer kick ran with the older PUT, "behind" the
    GPU, and the fetch walked off past the ring into stale commands -- old
    semaphore releases, which wound D3D's GPU clock back. D3D then waited
    forever for a time that would never come: the freeze on the last frame
    of a movie / on the loading screen.
  - The NV2A poll thread, display thread and sound mixer are runtime service
    threads and no longer sit on the guest's CPU 0 (xbox_UnpinServiceThread).
    D3D's vblank handler spins until that poll thread acknowledges the
    interrupt; on the shared core it waited for its own time slice to end.
src/twotowers_manual.c (game)
  - BlockOnTime (0x0011A8E0): if the GPU is idle (GET == PUT) and a time
    that was already kicked never got released, it is completed instead of
    spinning forever ([BLOCKONTIME] in the log). Safety net for the above.
  - GetStatus: a voice that stays "stopping" after DirectSound's own forced
    stop is reported to the caller as stopped (DirectSound's state is left
    alone; v19's clearing of its bits is reverted). Bink no longer hangs on
    the last frame of a movie waiting for its sound.
  - D3D vblank handler (0x0011DA80) wrapper; TT_VBFIX=1 drops the pending
    bit before the handler's acknowledge loop (experimental, off).
  - Log: [DEVSTATE] every 20 s (GPU time, PUT/GET, vblank counts).
kernel/kernel_thread.c
  Short guest sleeps use a high-resolution waitable timer (1 ms granularity
  on Windows instead of ~15 ms), for movie pacing.
apu/apu_vp.c
  RECOMP_APU_VTRACE=1 logs voice on/off/release/pause.

--- v21 ---
src/main.c (game)
  v20 froze on Windows right after the Direct3D 11 renderer showed its
  first frame. Likely cause: the all-threads sampling profiler (on by
  default) suspended every thread, graphics-driver threads included, and then
  walked the stack with the system unwinder, which takes loader locks; a
  suspended driver thread holding one stops the profiler with another thread
  still suspended. The sampler now only copies registers and stack while a
  thread is stopped (no locks) and scans the copy afterwards. It is also off
  by default again ([Developer] profile=1 turns it on).
  New hang watchdog (always on): if no frame is presented for 6 s, the log
  gets [HANG] lines -- each thread's current module+offset and the exe
  return addresses on its stack (map with v21_syms.txt). TT_NO_WATCHDOG=1
  turns it off.
kernel/nv2a_d3d11.inc
  - Present / CreateSwapChain failures are logged; if the graphics device is
    lost the game switches to the software renderer instead of going black.
  - Alt+Enter no longer lets DXGI take the window full screen.
  - Vertex and index data go into 8 MB ring buffers (MAP_NO_OVERWRITE, one
    DISCARD per wrap) instead of a DISCARD per draw. RECOMP_GPU_DISCARD=1
    restores the old behaviour.
kernel/kernel_bridge.c, src/twotowers_manual.c
  [DEVSTATE] also reports vblank and sound-interrupt counts.

--- v22 ---
src/main.c (game)
  The hang watchdog also fires before the first frame (nothing presented
  20 s after start) and when frames stop for 8 s, and it writes [DEVSTATE]
  every 20 s on its own (it used to come only from the profiler, which is
  off by default). v21 stopped on one PC before its first frame and the log
  had nothing to say about where.

--- v23 ---
kernel/xbox_memory_layout.c, src/twotowers_manual.c (game)
  Movies ran at 5-9 fps on Windows (and, it turned out, here too): the game
  paces every frame by waiting for two vblanks counted by its vblank
  callback, and only about 11 of the 60 vblanks a second reached it. The
  vblank is raised by setting PMC_INTR_0 bit 24 / PCRTC_INTR_0 bit 0, and D3D
  services it later from a DPC that checks those bits -- but the NV2A poll
  thread was zeroing all interrupt bits continuously (from before vblanks
  were raised at all), so by the time the DPC looked, the vblank was gone.
  The poll thread now leaves those two bits alone; the wrapper of D3D's
  vblank handler (0x0011DA80) clears them as the handler's write-1-to-clear
  would on hardware. All 60 vblanks a second arrive; movies play at 30 fps.
  The sound interrupt also gets through now, and the voice that stuck in
  "stopping" at the end of the first movie completes normally.
kernel/kernel_thread.c
  [SLEEPS] in the log every 20 s: the game's sleep call sites and counts.

--- v24 ---
kernel/nv2a_sw3d.inc
  Texture change detection covered only the first width*height BYTES of a
  texture -- a quarter of a 32-bit one. A movie frame that changed only
  lower down was not re-uploaded, so the GPU kept showing the old frame:
  on one PC the New Line Cinema logo stayed on screen while the montage's
  sound played on. Linear textures (movie frames, loading screens) are now
  hashed over their whole extent; swizzled ones at 4096 points across all
  of it.

--- v25 ---
kernel/nv2a_d3d11.inc
  CPU cost of the Direct3D 11 renderer cut (gameplay was CPU-bound at
  14-20 fps, the GPU at ~10%):
  - State shadowing: render targets, viewport, scissor, constant buffers,
    textures/samplers, blend/depth/raster state objects and the pipeline
    (shaders, layout, buffers) are only sent to D3D when they change;
    a frame is about a thousand draws. Clear/present invalidate the shadow.
  - Vertex/index buffers stay bound; each draw passes its ring offsets as
    StartIndexLocation/BaseVertexLocation instead of rebinding.
  - A render target's guest-memory copy is checked for CPU writes once per
    pushbuffer run instead of before every draw.
  - RECOMP_GPU_NULL=1 (developer): skip the D3D draw calls to time the CPU
    side alone.

--- v26 ---
kernel/nv2a_sw3d.inc
  The profile from a Windows PC in the battle showed the texture checksum
  (made exhaustive for linear textures in v24) as most of the main thread's
  time: a texture is bound many times a frame and was re-hashed each time.
  A texture is now checked at most once per pushbuffer run (the CPU can only
  change it between runs; GPU writes are tracked separately), and linear
  textures are sampled every 64 bytes instead of every 16.

--- v27 ---
Diagnostics for the last step to 30 fps (the battle runs at 22-28 fps on a
Windows PC with the CPU mostly idle, so frames are lost to waiting, not work):
  - [FPS] lines also count how many vblanks each frame took (1/2/3/4+).
  - [SLEEPS] lines also give the real time spent at each sleep site.

--- v28 ---
The v27 log from the battle: frames take 2 vblanks (30 fps) most of the time
and 3 in heavy moments (down to 25 fps), so the remaining cost is CPU work.
kernel/nv2a_pb_scan.c
  The method survey (counts of every GPU method seen, for the developer
  report) searched a list linearly for each method word executed -- the
  hottest loop in the main thread's profile. Now a direct index.
kernel/kernel_bridge.c
  D3D callbacks run one per timer tick instead of up to eight with a 2 ms
  Sleep between them -- that sleep was taken while holding the dispatch lock,
  and every game thread raising IRQL (DirectSound, constantly) waited on it.

--- v29 ---
The battle now holds 30 fps on the test PC (246 s logged: 30.9 flips/s
average, 6 frames that took 3 vblanks).
input/xinput_device.c, video/fb_present.c, src/twotowers_host.h (game)
  New default keyboard + mouse layout ([Input] layout=wasd):
    W/A/S/D           left stick (move); diagonals at full, not 1.41x, deflection
    left click, K, Space   A        right click, J   X
    L                 B             I                Y
    F / R             left / right trigger
    Z / C             white / black
    Enter or Esc      Start         Backspace or Tab Back
    arrow keys        d-pad         numpad 8/4/2/6   right stick
    Shift / middle click   left / right stick click
  The window now passes mouse buttons through. layout=classic keeps the old
  keys (Z/X/A/S face buttons, numpad left stick).

--- v30 ---
usb/ohci.c
  No controller input at all (pad, keyboard or mouse): the game only ever
  received ONE input report. The periodic list (where the pad's interrupt
  endpoint lives) and the control list were walked in the same tick, and each
  published its own done queue -- the control list's (the game sends rumble
  over it every frame) overwrote the periodic one, so the completion of the
  interrupt transfer was lost, the driver never queued the next one, and
  input stopped after enumeration. One done list per acknowledgement now;
  reports flow continuously. RECOMP_USB_DUMP=1 logs report counts.
input/xinput_device.c
  XInput is loaded at run time (xinput1_4, then 1_3, then 9_1_0) instead of
  being linked to xinput1_3.dll from the DirectX redistributable. Player 1 is
  the first connected XInput pad, whichever slot Windows gave it (an Xbox
  Series pad is often not slot 0); rescanned every 2 s, so a pad plugged in
  later is picked up. The log says which DLL and how many pads.
kernel/kernel_thread.c, src/twotowers_manual.c, src/twotowers_host.h (game)
  EXPERIMENTAL frame-rate modes, [Display] fps=30|60|unlocked:
  the game paces itself by waiting for 2 vblanks (gameplay) or 1 (menus)
  from its vblank callback, chosen by its flag at 0x4B75F1. fps=60 keeps that
  flag at 1-vblank pacing; fps=unlocked fills the vblank counter so the wait
  ends at once. Movies (Bink, time-based) play at normal speed at 60.
  Whether gameplay runs at normal speed depends on whether the game's
  simulation is time-based -- if it runs fast, use fps=30.
usb/usb_gamepad.c
  RECOMP_PAD_PRESS_AFTER=<ms> delays the synthetic-press probe.

--- v31 ---
input/xinput_device.c
  Keyboard/mouse did nothing on Windows while the pad worked: keys were only
  seen through the window's WM_KEYDOWN, which never arrives if the window
  does not get keyboard focus. Each key is now also read with
  GetAsyncKeyState while a window of this process is in front. The log says
  "[INPUT] keyboard/mouse input seen" on the first press, and [FBWIN] lines
  record focus/activation.
kernel/kernel_bridge.c (movie detection), src/twotowers_manual.c (game)
  fps=60 sped movies up 2x (Bink paces through the game's vblank wait). While
  a .bik file is open the game's own 30 fps pacing is kept.
kernel/kernel_bridge.c, kernel/kernel_thread.c, kernel/nv2a_pb_exec.c
  D3D callbacks the GPU reached waited for the next ~2 ms timer tick; the
  game waits on one every frame (0x000E012B). When a guest thread goes to
  sleep with a callback pending, the timer thread is woken at once (still
  >= 2 ms between two callbacks). Waking on queue instead froze loading:
  the callback then raced the D3D code still finishing the kick.
  (v32: made opt-in, RECOMP_CB_WAKE=1 -- it could still freeze a load.)
src/twotowers_host.h (game)
  An ini without [Input] layout (older build) is renamed .ini.old and
  rewritten from the current template with the user's values carried over.

--- v32 ---
kernel/kernel_file.c, kernel/kernel_bridge.c (NtClose)
  Saves "disappeared" / "Unable to load game": NtQueryDirectoryFile keeps a
  per-handle scan cursor keyed by the host HANDLE, and it was never dropped
  on NtClose. XAPI's save search stops at the first save it finds and closes
  the folder; Windows reuses the handle value for the next open, so the next
  scan of U:\ resumed at the second entry and never saw the save folder.
  The cursor is now released when the handle is closed.
kernel/kernel_bridge.c (NtFreeVirtualMemory, ordinal 199)
  Passed the addresses of the guest's 32-bit BaseAddress/RegionSize to the
  host VirtualFree as 64-bit pointers, so every call failed with
  STATUS_UNSUCCESSFUL. MEM_RELEASE now returns the block to the guest heap
  and MEM_DECOMMIT succeeds (the heap has no uncommitted pages).
kernel/kernel_bridge.c, kernel/kernel_thread.c
  The v31 "wake the timer thread for a GPU callback" change froze some loads
  in testing; it is now opt-in (RECOMP_CB_WAKE=1).
Developer aids (all off unless set):
  RECOMP_IO_TRACE=1    log every file/IO/crypto kernel call with its call
                       site, arguments, result, names opened and directory
                       entries returned.
  RECOMP_PAD_SCRIPT=f  scripted controller input; lines "<ms> <button>" or
                       "<file>+<ms> <button>" (ms after the guest first opens
                       a path containing <file>).
  RECOMP_FB_WINDOW_DUMP_EVERY=n with RECOMP_FB_DUMP=prefix  numbered dumps.

--- v33 ---
kernel/nv2a_d3d11_vp.inc (new), kernel/nv2a_d3d11.inc, kernel/nv2a_sw3d.inc
  NV2A vertex programs on the GPU. Each program is decoded once (VpIns),
  translated to an HLSL vertex shader and compiled on a background thread;
  once ready, a batch uploads only the attributes the program reads and the
  shader produces exactly what sw3d_transform did (window position * w,
  clamped D0/D1, fog, T0-T3). Programs that write constants, and batches
  whose shader is still compiling, use the CPU path. CPU cost of a replayed
  battle frame: 49 ms -> 16 ms (test machine). RECOMP_HW_VP=0 or ini
  [Display] vertex_programs=cpu turns it off; RECOMP_HW_VP_SYNC=1 compiles
  synchronously (testing). Log: [HWVP] lines every 10 s.
  CPU path: the program is decoded once per batch instead of per vertex per
  instruction (vp_run_fast; RECOMP_VP_SLOW=1 for the old interpreter), and
  big batches are transformed on worker threads (RECOMP_VTX_THREADS=n).
kernel/kernel_hal.c, kernel/nv2a_pb_exec.c, kernel/nv2a_sw3d.inc
  getenv cache is a hash table; per-method/per-batch getenv calls cached.
twotowers/postproc_apu.py (run by relift.sh / rebuild_full.sh / iterate.sh),
apu/apu_mmio_hook.c
  Constant-address APU register accesses in the generated code call the APU
  directly (xbox_apu_r32/w32) instead of page-faulting into the VEH decoder:
  DirectSound's per-voice register traffic was thousands of exceptions a
  second, under the dispatch lock (sound chugging with many enemies).
  RECOMP_APU_SITES=1 logs the accesses that still trap.
src/twotowers_manual.c, kernel/kernel_bridge.c
  Freeze in GPU flush waits (0x000E08D0 waits for its D3D callback to write
  2 to 0x1BB3BC; the per-frame callbacks write 0/1 to the same word and
  could overwrite the 2 before the waiter saw it). The 2 is held for 250 ms.
  New hook xbox_pb_callback_hook. DEVSTATE shows the flags and timer state.
kernel/kernel_thread.c
  High-resolution waits are bounded (a waitable timer that never fired left
  the timer thread -- vblank, sound IRQ, callbacks -- stopped for good).
  KeDelayExecutionThread(0) in a tight loop sleeps 0.25 ms after 200
  consecutive yields (RECOMP_SPIN_YIELD=1 = old behaviour); getenv cached.
kernel/kernel_hal.c
  [IRQLBUG] lines name the guest call site.

--- v34 ---
kernel/nv2a_d3d11.inc, video/fb_present.c, kernel/nv2a_d3d11_shaders.h
  Presentation: the swap chain follows the window's size (ResizeBuffers),
  flip model where available (RECOMP_BLT_MODEL=1 for the old one), the
  picture is fitted at its aspect with black bars (RECOMP_PRESENT_STRETCH=1
  fills), optional vsync (RECOMP_VSYNC=1). Borderless full screen toggled by
  Alt+Enter / F11 (RECOMP_FULLSCREEN=1 at start), window size
  RECOMP_WINDOW_SIZE=WxH, window title RECOMP_WINDOW_TITLE.
  Internal resolution RECOMP_RENDER_SCALE=1..8: render targets and depth
  buffers are allocated larger; viewports, scissors and surface copies are
  scaled; CPU-written pixels (movies) are scaled up on upload and read-backs
  scaled down (gpu_copy_scaled, ps_copy).
  Widescreen RECOMP_ASPECT=<w/h> with the game hook TT_ASPECT: render targets
  are also widened horizontally; a frame is shown wide only if it drew 3D
  after the game's camera was widened; 2D HUD pieces (pass-through vertex
  programs, small, not sampling a rendered frame) are drawn at 4:3
  proportions; RECOMP_HUD_STRETCH=1 stretches them instead.
  FXAA on the final picture (RECOMP_AA=fxaa, ps_fxaa).
  Mipmaps generated for swizzled textures (RECOMP_MIPMAPS=0 off) and used on
  stages whose MIN filter is a mipmap mode; anisotropic filtering
  RECOMP_ANISO=2..16.
  Texture shader dot products: DOTPRODUCT (0x11) and DOT_ST (9) stages, with
  SET_DOT_RGBMAPPING (0x1E74) and SET_SHADER_OTHER_STAGE_INPUT (0x1E78).
  Testing aids: RECOMP_PRESENT_DUMP=prefix (+ RECOMP_PRESENT_DUMP_EVERY=n),
  RECOMP_STAGE_MODES=1, RECOMP_BATCH_SHAPES=1.
src/twotowers_manual.c (game)
  0x0004E890 camera::SetPerspective wrapped: aspect * (TT_ASPECT / (4/3)),
  so the projection and the culling frustum both widen.
src/main.c (game)
  timeBeginPeriod(1) at start and Windows power throttling turned off for
  the process (EXECUTION_SPEED, IGNORE_TIMER_RESOLUTION).
kernel/kernel_thread.c
  The busy-wait sleep (v33) only engages while short sleeps really are
  short (running average of the measured sleep < 0.9 ms); on a coarse timer
  it falls back to yielding.
src/twotowers_host.h (game)
  ini template version 2 with the display options; older inis are
  rewritten keeping the user's values (old file kept as .ini.old).
input/xinput_device.c
  Alt+Enter is not Start.

--- v35 ---
video/gfx_menu.c, video/gfx_menu.h (new)
  The in-game Graphics Settings overlay:
  - Option state is read from the RECOMP_* / TT_FPS environment at start.
  - xbox_gfx_rev is bumped on every change; xbox_GfxGet / xbox_GfxAspect
    read the current values.
  - The title registers handlers: xbox_GfxSetFpsHandler and
    xbox_GfxSetSaveHandler (writes the ini).
  - The panel is drawn with GDI into a DIB at screen resolution
    (xbox_GfxMenuRender).
  - F10 arrives from the window (xbox_GfxMenuKey). Back+Start, navigation
    and closing come from player 1's controller state, keyboard stand-in
    included (xbox_GfxMenuPad).
  - While the panel is open, and until the closing button is released, the
    game sees a controller at rest.
video/fb_present.c
  - F10 is taken for the overlay (on both key-down and key-up), so Windows
    does not enter menu mode.
  - xbox_FramebufferSetFullscreen posts a message so the window thread does
    the switch; xbox_FramebufferIsFullscreen reports the current mode.
input/xinput_device.c
  xbox_InputGetState passes port 0's state through xbox_GfxMenuPad.
kernel/nv2a_d3d11.inc, nv2a_d3d11_vp.inc
  - gpu_draw_menu draws the panel, alpha-blended and centred, before Present.
  - gpu_apply_settings runs after Present when xbox_gfx_rev moves:
    - FXAA, vsync, stretch and vertex-program mode are runtime flags.
    - Samplers are rebuilt for an anisotropy change. Textures are rebuilt
      when mipmaps are switched on or off.
    - An internal resolution or aspect change frees every surface and
      recomputes g_rsx/g_rsy.
  - The HWVP compile thread is always set up, so the GPU vertex-program path
    can be switched on in game (g_hwvp_user).
  - Only frame-sized targets (>= 320x200, GS_SCALED) are scaled.
    Coordinates use each surface's own scale (SX/SY), and blits between
    surfaces of different scales go through vs_blit.
kernel/kernel_bridge.c, kernel/kernel_thread.c
  - The timer thread runs on a fixed 2 ms grid with xbox_precise_wait_until.
    That function learns the host sleep overshoot, sleeps short, then
    yields until the deadline.
  - The timer thread is time-critical and unpinned.
  - RECOMP_TIMER_SLEEP=1 restores the plain sleep.
kernel/kernel_rtl.c, kernel/kernel_hal.c
  - Critical-section shadows use a per-thread 32-entry cache in front of the
    SRW-locked table.
  - The statistics counters are per thread and batched, with no
    interlocked add per call.
src/twotowers_manual.c (game)
  - The camera hook reads the live aspect (xbox_GfxAspect).
  - The fps delay hook is always installed (no-op at 30), and tt_fps_set
    switches the mode at run time.
src/twotowers_host.h (game)
  Overlay changes are saved to [Display] in the ini.
src/setup_launcher.cpp (game)
  - "Graphics settings..." dialog with one drop-down per [Display] option;
    custom ini values are kept.
  - Started with --graphics, the launcher opens the dialog directly.

--- v36 ---
config/seed_functions.json (game)
  The upgrade screen's switch arms (jump tables 0x6EF40, 0x6EF50 and
  0x6EF60: 0x6EA84/8B/92/99, 0x6EC40/47/4E/55, 0x6ECCA/D1/D8/DF) are seeded as
  entries.
  - One copy of the screen's update chunk (sub_0006E9EC) has its indexed jmp
    unfolded: RECOMP_ITAIL to a mid-function address, which nothing resolved.
  - The game logged "[ICALL] Failed to resolve VA 0x0006EA99" and the screen
    went black.
  - Full pipeline re-run (disasm -> ... -> lift).
input/input_bind.c, input/input_bind.h (new)
  - 24 actions: the controller's buttons, plus each stick direction as a
    keyboard action. Each action has up to 3 keys or mouse buttons, and
    button actions have a pad source (pad remap with swap).
  - Key names round-trip through the ini (kb_<action>, pad_<action>).
  - The defaults are the old wasd and classic layouts.
  - xbox_BindSet / xbox_BindAssignKey / xbox_BindAssignPad /
    xbox_BindResetAll, with a save handler.
input/xinput_device.c
  - keyboard_state reads the bindings.
  - XInput buttons are translated through the pad bindings (triggers stay
    analog).
  - xbox_InputKeyDown is exported for the overlay's key capture.
  - Pad script: anchors work when the file opens before the first input
    poll; "CLEAR" stops untimed lines; "FLAGn" raises a named flag for test
    hooks (xbox_PadScriptFlag).
video/gfx_menu.c
  - A Controls page alongside Graphics (row 0 picks the page).
  - Key capture polls every virtual key: Esc cancels, Delete clears, F10
    leaves.
  - Left/Right cycles the pad source; "Reset all controls" is the last row.
kernel/nv2a_d3d11_ps.inc (new), nv2a_d3d11.inc, nv2a_d3d11_vp.inc
  - Specialized pixel shaders. The batch's combiner program (stages,
    register inputs/outputs, mappings, ops, mux, final combiner, texture
    stage modes/flags, dot-product mapping, fog mode, alpha-test function)
    is the key.
  - It is translated to straight-line HLSL that uses the same cbuffer, and
    compiled on the vertex-program thread. ps_main draws until it is ready.
  - Replays are bit-identical to ps_main (captures 0-5).
  - RECOMP_HW_PS=0 off, RECOMP_HW_PS_SYNC=1 compile at once.
  - [HWPS] statistics appear in the [FPS] block and at the end of a replay.
  - g_sh.cbps was 1120 bytes, but the PS constants have been 1152 bytes since
    v34 (sdot, sinp): the shadow copy overran into the following fields.
src/twotowers_manual.c (game)
  - 0x000E3AF0 (the developer switch lookup, empty on retail) can answer
    TT_TWEAKS="SKIPMAINMENU=1;HERO=aragorn;LEVEL=02GATE2": straight into a
    level, for testing.
  - TT_DEBUG_GOTO=<1-11>: once a pad script raises FLAG1, the front end
    switches to that screen (10 = end of level, 11 = upgrades). It runs from
    the main loop's 0x000E6080 call. With neither variable set, nothing
    changes.
src/twotowers_host.h (game)
  [Controls] is loaded into the bindings at start, and changes made in game
  are written back.
src/setup_launcher.cpp (game)
  - "Controls..." dialog: key boxes capture the next key or mouse button,
    pad drop-downs swap, "x" clears, and Defaults restores.
  - --controls opens it directly.

-- 1.1 ---------------------------------------------------------------------
kernel/nv2a_d3d11.inc
  - Shadows: the character shadow pass draws a 256x256 colour target, then
    uses the same memory as the zeta of the next pass and samples it as a
    texture (the depth it just wrote, read as A8R8G8B8). Colour and zeta
    surfaces at one address were separate D3D textures and the colour one
    was always sampled: shadows came out as stripes. A texture now samples
    whichever surface at its address was drawn into last (GSurf.wr).
  - RECOMP_SURF_LOG=1 (testing): render targets as they are created, and
    textures that are, or lie inside, one.
  - Picture adjustments on the way to the window: brightness (gamma),
    contrast-adaptive sharpening, colour saturation (cbuffer b3 of the
    present and FXAA shaders).
kernel/nv2a_d3d11_shaders.h
  post_sharp / post_grade in ps_present and ps_fxaa.
kernel/nv2a_sw3d.inc
  - xbox_tex_observer: the title's hook on every decoded texture, with its
    content hash (may change the texels).
  - Texture cache entries are re-decoded when xbox_tex_rev changes (texture
    mods switched on or off).
video/gfx_menu.c, gfx_menu.h
  Brightness, Sharpening, Colour and the two mod switches; xbox_GfxGetF.
video/fb_present.c
  - The mouse is captured while a button is held, so a release outside the
    window still arrives; WM_CAPTURECHANGED and WM_ACTIVATEAPP let go of
    held buttons and keys.
  - xbox_FramebufferKeyClear.
input/xinput_device.c
  - A key the window holds but the keyboard reports up for 250 ms is let
    go (once GetAsyncKeyState has been seen working). A lost release left W
    held: the hero ran on his own and the controller could not steer.
  - A pushed controller stick always wins over the keyboard's.
  - Pad scripts: LSU/LSD/LSL/LSR (left stick, testing).
  - xbox_pad_observer gets the port and sees every port.
src/main.c (game)
  - Only threads that start in the program are pinned to CPU 0. Library
    threads (XAudio2's mixer, the graphics driver's, XInput's) had to share
    CPU 0 with the game: at 60 fps / unlocked the sound crackled and the
    music dropped out.
  - abort() and unhandled exceptions are logged ([CRASH]).
src/e3hud.c, e3hud_*.inc, e3hud_layout.h (game, new)
  The ECTS 2002 demo HUD and orange health pickups (see README, Mods).
src/twotowers_manual.c (game)
  - 0x000CF450 (the HUD's draw) wrapped: the ECTS HUD hides the retail gauge
    frame, moves the rating text and lends its own text elements a free slot
    of the HUD list, so the game draws them in its own fonts.
  - 0x0008FB60 ("does the player need a power-up") wrapped:
    TT_FORCE_PICKUPS=1 (testing).
  - TT_POKE8="addr:value,..." (testing) holds guest bytes, e.g. the debug
    menu switch 0x1B0BFD "DEBUG/Drop Pickups".
src/twotowers_host.h (game)
  [Display] brightness / sharpening / colour, [Mods], [Developer]
  texture_dump.
input/xinput_device.c, video/fb_present.c (1.1, later)
  - Controller, keyboard and mouse reach the game only while its window is
    in front ([Input] background_input=1 lets the controller through).
  - The click that brings the window to the front is not passed on as the
    left mouse button's game button.
1.1, playtest fixes
  - The mods are renamed for where the footage is from: "ECTS 2002 HUD
    (experimental)" and "Orange health pickups (shown in pre-release &
    making-of videos)". Settings keys unchanged (e3_hud, e3_pickups).
    README explains what each mod changes and why.
  - Launcher: labels too long for the settings window wrap onto two lines
    instead of being cut off.
  - Orange health pickups: recolour hue moved from amber-gold to orange.
  - Orange health pickups: the health vial's texture (0x71C950C7, found from a
    playtest video) is built in; only its glass panes (x < 46) are
    recoloured, the coin beside them is left alone.
  - Level-select map at 16:9: the camera is widened only in gameplay
    (front-end screens 6 and 8). The map's 3D scene was widened while its
    2D highlights stayed 4:3, so the glows sat beside the level icons.
  - texture_dump=1 works in any section of the ini; the log names the
    folder. The raw (address-named) dumps went beside the program as
    texture_dumpNN_... files; they now go inside the folder too.
  - Diagnostics for silent exits: a closed game window logs [EXIT]; game
    threads keep 64 KB of stack back so a stack overflow still logs
    [CRASH]. (A movie freeze seen once on Amon Hen ended its log with
    neither; it did not reproduce here.)
src/e3hud_load.inc (game, new)
  The loading-screen tip about experience (texture 0x509D0703), redrawn in
  the ECTS style, with a second arrow and lines on the combo runes.

-- 1.1.1 -------------------------------------------------------------------
Found by a scripted run through every level, hero and frame-rate mode.

kernel/kernel_bridge.c
  - KeInsertQueueDpc is now thread-safe. Interrupt handlers queue DPCs
    from the timer thread while game threads queue their own; two at once
    could take the same queue slot and one DPC was lost. When it was D3D's
    (its interrupt handler masks the GPU interrupt and its DPC unmasks it),
    vblank was never delivered again and the game froze on its next frame
    wait -- the freezes during movies (Amon Hen, the prologue's opening).
    The prologue run went from 64 freeze reports to none.
  - A DPC already queued is not queued twice (KDPC.Inserted), as on the
    console.
  - Safety net: if the GPU interrupt stays masked for 2 s with nothing
    queued, it is unmasked as the DPC would have, and the log says so.
kernel/nv2a_d3d11.inc
  - A colour surface that has to grow keeps its contents. The lava's heat
    haze copies two patches of the frame into one buffer; the second,
    taller patch re-created the buffer and cleared the first: black boxes
    over the lava. A frame-pitch copy target is also made frame sized at
    once.
kernel/kernel_file.c
  - Read-only opens share reading and writing, and a briefly locked file
    is retried for up to half a second. Another program reading a game
    file at the same moment (an antivirus scan, a backup) made the open
    fail, which the game reports as a dirty disc.
input/xinput_device.c
  - Controller hot-plug scanning moved to its own thread. Polling empty
    XInput slots is slow on many PCs and ran on the game's thread every
    two seconds: a small regular hitch.
  - Stick dead zone, [Input] stick_deadzone (percent, default 10, 0 = off):
    a resting stick that drifts no longer walks the hero; the range is
    rescaled so full speed is still reached.
  - Rumble is sent only when it changes, stops while the game is in the
    background (resumes in front), and stops when the window closes.
src/twotowers_manual.c (game)
  - The GPU flush wait's "2" (0x1BB3BC) is now held until the game has
    presented two more frames, as well as for 250 ms. On a busy PC a sleep
    of the waiting thread could outlast the 250 ms; the next frame's
    callbacks then overwrote the 2 before it was seen and the game waited
    for ever -- a freeze while loading (seen loading Weathertop).
video/fb_present.c, src/main.c
  - A closed game window logs [EXIT]; game threads keep 64 KB of stack for
    the crash handler, so a stack overflow still logs [CRASH].

-- 1.1.2 -------------------------------------------------------------------
Found from a player's log: the game slowed down, lost input or crashed
about eight minutes into a session (it showed after an Amon Hen cutscene).

kernel/kernel_bridge.c
  - The kernel call counter was a signed 32-bit int. The game makes about
    four million kernel calls a second (one thread sleeps for zero time in
    a loop), so after roughly eight minutes it passed 2,147,483,647 and
    went negative. The "log the first 200 calls" check then passed for
    every call, and each one printed and flushed a line to the log:
    millions of disk writes a second, the frame rate dropped to around 40
    with long hitches, other threads (input, audio) were starved, and the
    log grew by about 100,000 lines a second. The counter is now 64-bit
    and unsigned; tested by starting it just below the old limit and
    playing Amon Hen past it -- no log flood.
  - KeDelayExecutionThread looked up RECOMP_DELAY_STATS with getenv() on
    every call (millions a second); it is now read once.
kernel/xbox_memory_layout.c
  - The [NV2A] DMA_PUT line, and a log flush, ran on every pushbuffer kick
    in normal play: the trace switch is also armed by RECOMP_PB_EXEC, which
    every run sets. They now need RECOMP_NV2A_TRACE.
kernel/nv2a_pb_exec.c
  - The "[GPU] draw #" heartbeat is every 100,000 draws (was every 200:
    thousands of log lines a second).

-- 1.1.3 -------------------------------------------------------------------
usb/ohci.c, usb/usb_gamepad.c, usb/usb_gamepad.h
  - Rumble: the game's output reports on the pad's interrupt OUT endpoint
    (report 0, length 6, left and right motor speeds as 16-bit values) were
    accepted and dropped, so the controller never vibrated. They now go to
    xbox_InputSetState (XInput), which sends only changes.
  - RECOMP_USB_OUTLOG=1 (testing): the first 40 OUT transfers to the pad.
apu/apu_xaudio2.c
  - Lost output recovers. XAudio2 stops for good when its device goes away
    (headphones unplugged, default device switched, a display asleep, a
    driver reset): the queue stays full and every submit is dropped, while
    the game plays on and its music stream keeps being read -- silence, as
    reported after an upgrade screen. A critical error (engine callback), a
    failed submit, or a queue full and not draining for 750 ms now rebuilds
    the engine on the default device (at most every 2 s) and logs it.
kernel/nv2a_d3d11.inc
  - xbox_FrameTextureList: last frame's texture hashes (for finding what a
    screen is made of).
src/e3hud*.c/.inc/.h (game, ECTS HUD mod)
  - The mission results screen (front-end screen 10) drew the thermometer,
    so the mod took it for play and drew its in-play gauge and portrait in
    their in-play places, over "Replay" and the hero's name. There it now
    draws its gauge over the retail one's place instead; the retail gauge's
    top (F7A501DB), frame and medallion (6EB4352F) and colour ring
    (ADE193F9) are cleared as they are decoded (in play they were already
    hidden by switching their HUD elements off).
  - The loading-screen tip about the Skill Meter (4F380BD7, Fangorn) gets
    the demo gauge and orb like the experience tip; its arrow is kept and
    run back to the orb.
  - Helm's Deep wall (17TOP1): the progress bar's portrait (BB82F059) is
    replaced by e3hud\level10.bmp when installed (the demo's picture).
  - TT_E3HUD_ELDUMP=1 (testing): each screen's textures, and the gauge
    elements, in the log.

-- 1.1.4 -------------------------------------------------------------------
Fixes a regression in 1.1.3: on some PCs no input worked at all (controller,
keyboard or mouse).

usb/usb_gamepad.c, input/xinput_device.c, input/xinput_xbox.h
  - 1.1.3 passed the game's rumble report to XInput from the USB
    emulation's thread. The game sends one ("motors off") while it is still
    connecting the pad, and that first XInput call loaded XInput and
    scanned all four slots (slow when they are empty) right there: the
    connection timed out, the game never saw a pad, and the keyboard and
    mouse -- which reach the game through that same pad -- went with it.
    The rumble is now only recorded there (xbox_InputSetVibrationDeferred)
    and sent by the next input poll.
  - The controller scan, including the first one, runs only on its own
    thread; until it answers (a few ms) the pad reads as absent and the
    keyboard covers it.
  - XInput is loaded once under INIT_ONCE; it used to mark itself loaded
    before loading, so a second thread could see no XInput meanwhile.

-- 1.1.5 -------------------------------------------------------------------
usb/ohci.c
  - The emulated pad was plugged in the moment the game's USB driver
    enabled root-hub interrupts. On a fast PC that can be while the
    driver's own bring-up scan is still running, which clears the connect
    change unseen: the log said "operational after 0 ms", two RHSC
    interrupts, and then no transfer ever -- no pad, and so no keyboard or
    mouse either (they reach the game through the same pad). The plug now
    waits 200 ms after the driver is listening (the frame clock keeps
    running meanwhile), and if the driver has not sent the device a SETUP
    within a second, the pad is presented again as if re-plugged (up to
    ten times, logged).
  - RECOMP_USB_MISS_FIRST=1 (testing): the first arrival is lost, to
    exercise the re-plug.

-- 1.1.6 -------------------------------------------------------------------
usb/ohci.c
  - Rumble, for real. XInputSetState sends rumble to this pad as a HID
    SET_REPORT control request (it has no OUT pipe open), not on the
    interrupt OUT endpoint 1.1.3 listened on. And no control request made
    after enumeration was ever serviced: the lists were walked one at a
    time, each publishing its own done list, and the next skipped while
    that was unacknowledged -- the pad's input report completes on the
    periodic list every tick, so the control list was never reached again.
    The game's first rumble request stayed pending, and as it sends the
    next only when the last completes, it never sent another. Periodic,
    bulk and control lists are now walked in one pass into one done list,
    published once; SET_REPORT's data stage (class/interface request 0x09)
    is passed to the controller.
src/twotowers_manual.c (game)
  - XInputSetState (0x00169845) wrapped: TT_RUMBLE_LOG=1 (testing) logs its
    first calls, result and the device fields it checks.
-- 1.2 -------------------------------------------------------------------
kernel/kernel_hal.c, kernel/kernel.h
  - xbox_CpuLockYield: lets go of the dispatch lock (all of this thread's
    holds) for a moment and takes it back.
  - xbox_DpcLockGuestCs(cs, max_ms): for a guest lock helper that skips its
    critical section at DISPATCH_LEVEL -- takes it anyway, yielding the
    dispatch lock while it waits; after max_ms it gives up and the caller
    goes ahead unlocked, as on the console.
src/twotowers_manual.c (game)
  - Crash in Helm's Deep (17TOP1) at 60 fps / unlocked: an access violation
    reading 0xFFFFFFEC in XACT (0x00135821, a sound bank stopping its cues,
    called from the game's sound code). XACT's lock (0x00134940) takes its
    critical section only at PASSIVE_LEVEL: at DISPATCH_LEVEL it is a DPC,
    which on the console runs with every thread stopped. Here DPCs run on
    the timer thread beside the game thread, so the game walked a cue list
    the DPC was relinking and read a null link. More cues start and stop per
    second at a higher frame rate, so that is where it showed. The lock now
    takes the section at DISPATCH_LEVEL too (xbox_DpcLockGuestCs, 50 ms).
  - @IncVillagerRescue (0x000CC9C0) wrapped: logs the villager count.
src/e3hud*.c/.inc/.h (game, ECTS HUD mod)
  - Westfold (16ROHAN2): the villager bar (HUD list 11: a green bar and a
    portrait, 8 steps -- the count at 0x4A55BC starts at 8, one off per
    @IncVillagerRescue) is replaced by the demo's two rows of four villager
    couples, a red cross over each one lost, from e3hud\villager.bmp and
    villager_dead.bmp (crops of the ECTS footage) when installed; without
    them the retail bar stays. TT_E3HUD_VRTEST=n (testing) shows it with n
    left.
  - Helm's Deep wall: the level10.bmp picture is lowered 4 units (its HUD
    element, while drawn) so it is centred on the bar, not 4 units above.
  - TT_E3HUD_LISTDUMP=1 (testing): every element of the HUD lists that are
    on (and list 11) in the log.
input/xinput_device.c, usb/usb_gamepad.c, usb/ohci.c
  - Controls freezing in play with the last input held (Gimli aiming at the
    breach, Aragorn walking into a wall at Westfold; the level-select map
    then scrolled by itself). The USB emulation's thread built every pad
    report by calling XInputGetState, and since 1.1.6 also sent rumble with
    XInputSetState, right there; XInputSetState can block on the pad's
    driver (Bluetooth, Steam Input, virtual pads), and while it did no report
    went out, so the game kept the last one. XInput now runs only on a poll
    thread (every 2 ms, into a table the reports are read from) and a rumble
    thread; a pad whose poll stops answering reads as at rest after 250 ms
    instead of frozen. The log reports a slow XInputSetState and any stretch
    of more than 3 s with no pad report sent to the game.
src/e3hud.c, e3hud_tex.inc, e3hud_layout.h (game, ECTS HUD mod)
  - Westfold's villager couples are just the faces now, as in the demo
    (villager.bmp / villager_dead.bmp cut from the footage, background keyed
    out), in their own shape against the right edge of the retail art.
src/prompts.inc, src/e3hud.c (game), video/gfx_menu.c/.h, src/twotowers_host.h
  - PlayStation button prompts: [Input] prompts = auto / xbox / playstation
    (also "Button prompts" in the F10 menu). The game's button textures --
    A 13DF2C89, B 62764416, X 6BB46B89, Y 5E463DBF, right trigger 71E4228A,
    seen on the upgrade screen's combo lists and "Help" -- are redrawn as
    they are decoded: cross, circle, square, triangle (same places on the
    pad) and R2. "auto" uses them when player 1's pad is a PlayStation one.
apu/apu_xaudio2.c, kernel/nv2a_d3d11.inc, platform/d3dcompile_dyn.h,
platform/mf_dyn.h, d3d/*.c, audio/wma_decoder.c, video/video_player.c
  - Windows 7: the game imported XAudio2_8.dll, d3dcompiler_47.dll and
    Media Foundation, which a Windows 7 (and the N editions of any Windows)
    may not have -- and a missing import stops a program before it starts.
    All three are now loaded at run time: XAudio2 2.9 / 2.8 or else the
    waveOut output; the newest HLSL compiler present (47 down to 43, the
    DirectX redistributable's) or else the software renderer; Media
    Foundation where it is installed.
  - The Direct3D 11 device is asked for feature level 11_0 exactly (the
    shaders are shader model 5): a 10.x card, or a Windows 7 without the
    platform update, now gets the software renderer and a line in the log
    instead of a device whose every shader fails. The log names the card
    (vendor and device id).
apu/apu_xaudio2.c (Linux)
  - Sound on Linux, through SDL2's audio (48 kHz stereo, ~85 ms of queue,
    reopened if the device goes away), the same contract as XAudio2.
src/linux_setup.cpp, linux/TwoTowers.sh (Linux)
  - twotowers-setup: checks and extracts the disc image (or uses an
    extracted folder), edits a few settings, adds a menu entry.
    TwoTowers.sh runs it on first start (with zenity dialogs when zenity is
    installed) and starts the game; it says how to install SDL2 if missing.
  - Built against glibc 2.27 (Ubuntu 18.04 and later, and the distributions
    of that age); SDL2 comes from the system. No OpenSSL needed.
platform/xbox_winnt.h (Windows builds)
  - The real cause of the controls freezing (the input thread change above
    was not enough: it went on happening). XBOX_THREAD_LOCAL was
    __declspec(thread) for every Windows compiler, but with MinGW that is
    __attribute__((thread)), which does not exist: the compiler warned and
    made each such variable an ordinary global. So the IRQL, the dispatch
    lock's hold count, the critical-section cache and the per-thread wait
    timers were shared by every thread in the Windows builds (Linux was
    right). One thread lowering its IRQL released the dispatch lock another
    thread held, and DPCs ran in the middle of the game thread's raised-IRQL
    sections; the USB driver then gave one transfer descriptor to the rumble
    request and the pad's input endpoint at once, and the pad's reports
    stopped for good with the last input held. Now __thread under GCC/clang,
    __declspec(thread) only under MSVC. ("KfLowerIrql(2) while at 0" in the
    log was this too, and is gone.)
usb/ohci.c
  - An endpoint's head pointer is moved past a transfer descriptor with an
    atomic compare-and-swap before the transfer is done, and not at all if
    the driver changed it meanwhile; a descriptor with no valid NextTD is
    left alone. (Before, a stale head was written back over the driver's.)
  - The stall report (no pad report for 3 s) now lists the last 512 things
    that happened to the endpoints and controller registers, and the TDs.
kernel/kernel_hal.c
  - [IRQLBUG] lines come with the thread's last IRQL changes.
kernel/nv2a_sw3d.inc
  - RECOMP_TEX_DUMP_ALL=1: the texture dump includes the large textures
    (loading pictures) too.
input/xinput_device.c
  - xbox_InputPlayerPadPlayStationModel / xbox_InputAnyPlayStationModel:
    which PlayStation pad (3, 4 or 5) a player holds / was last connected.
src/prompts.inc, src/prompts_sig.h, prompts\*.bmp (game)
  - With PlayStation prompts, the loading screens' controls pictures (the
    first levels': UI\loadl2..4 -- "Parry", "Fierce attack" / "Fire", and
    the full layout) show a DualShock 3, DualShock 4 or DualSense, whichever
    player 1 holds (else the last PlayStation pad connected, else a
    DualShock 4; [Input] ps_pad = auto / ps3 / ps4 / ps5). The pads are
    drawn for this (no picture of a real pad is used), with their face
    buttons where the Xbox pad's were, so the game's own leader lines and
    labels still point at them; the left stick's line is re-routed, Start
    and the black button become OPTIONS/START and L1 insets, the triggers
    L2/R2. The "pressed" pictures flashed over the buttons follow. They are
    recognised by their look (a grid of mean colours), not by hash.
src/e3hud villager.bmp (game, ECTS HUD mod)
  - The left villager's mouth was cut off by the mask: the head shapes
    were widened and the mask's holes filled.
platform/win32_compat.c (Linux)
  - Crash entering Balin's Tomb (04BALIN1) on Linux: a loader thread waited
    on an event handle before its creator had stored it, and the Linux
    Win32 layer took the garbage value for an object and locked it
    (pthread_mutex_lock on a wild pointer). Live objects are now kept in a
    table; a handle that is not one is refused (ERROR_INVALID_HANDLE), as
    Windows does, in every call that takes one.
CMake / toolchain (Windows)
  - The Windows build links against msvcrt.dll (llvm-mingw's msvcrt
    toolchain) instead of the Universal C Runtime, so Windows 7 and 8.1 no
    longer need KB2999226 or a Visual C++ redistributable.
src/heroes.c, kernel/kernel_path.c (1.2, highly experimental, off by default)
  - Extra heroes mod ([Mods] extra_heroes=1, off by default; a choice in the
    launcher's settings window and in the Linux setup menu). Once a save has
    finished Hornburg Courtyard and the Tower of Orthanc (the game's own test
    for Isildur), the character select has eight places: Aragorn, Legolas,
    Gimli, Isildur, Boromir, Gandalf, Frodo and Lurtz, on one turning ring.
    The new four use the game's own models and animations (taken from Balin's
    Tomb and Amon Hen, copied into a private copy of UI\mainmenu.bff under
    heroes\), stand in the menu stance and carry their own name and level
    label. A guest plays as hero 4 with its own skin in the level (a private
    copy of the level file), and has its own experience, scores and upgrades,
    kept in heroes\records.dat; the save itself keeps Isildur's.
  - Re-rigging: a new hero's model has its bone tables ({skeleton bone,
    model bone} per model part) pointed at the matching bones of the
    heroes' skeleton (Aragorn's, shared by Isildur), so the hero's own
    animations drive it: every move, the sword and bow, the level's opening
    scene and the character select's poses. The bone tables were made by
    twotowers/tools/rig/chain.py (limbs matched along their chains, the rest
    following the nearest limb bone or the spine/head by height).
  - Unlock: a save that has finished Hornburg Courtyard and the Tower of
    Orthanc; extra_heroes=2 answers the game's two checks with "finished"
    while it runs (nothing is written to the save).
  - kernel_path.c: xbox_path_redirect, a hook that lets the game serve a
    file from another place on disk.
src/e3hud.c (ECTS HUD mod)
  - Westfold's villager couples showed on the results and upgrade screens
    after the level: those screens draw the experience tube too, which was
    taken for "in play". Play is now the health sword being drawn.
-- 1.3 -------------------------------------------------------------------
src/heroes.c (game, Extra heroes mod, highly experimental, off by default)
  - Unlocking one by one: each finish of the Tower of Orthanc (21ORTH2) as
    Isildur himself counts, per save (heroes\unlocks.txt, by save folder):
    2 unlock Boromir, 3 Gandalf, 4 Frodo, 5 Lurtz. A locked hero shows as a
    faint shadow on the select and is skipped by the cursor.
    extra_heroes=2 still shows all four on any save.
  - The guests play on their own skeletons with their own motions. Each
    level copy gets a composed animation set: the guest's skeleton (with
    the heroes' aiming blocks added to its "skel" chunk, so ranged attacks
    fire), and in each of the hero's slots one of the guest's motions
    carrying the hero's events and tail (strike, swoosh, combo windows,
    strike bone) re-timed to it. Walks and runs play at the hero's ground
    speed for the guest's stride; the guest's swing (its fastest hand
    moment) is warped to near the hero's strike event; attacks run no
    slower than about 1.15x the hero's.
  - Boromir's and Frodo's light, heavy, kick and ranged attacks are the
    hero's own, retargeted onto their skeletons at level build
    (retarget_rec: world rotations through the bind poses, root motion
    kept). The guest's weapon-hand bones (attach points 0 and 1) take the
    hero's hand rotations, not the bone the rig map gives them (Boromir's
    sword hand maps to the hero's wrist): before, the blade swept beside
    the hero's and heavy attacks found no one. Gandalf and Lurtz keep their
    own attacks. Walks, runs, blocks, hit reactions and deaths are the
    guests' own.
  - Strike reach: the melee hit test (sub_000BA110) samples the weapon from
    WEAPON_MIN_EXTENTS to WEAPON_MAX_EXTENTS along its local +Y through the
    weapon's world matrices (+0x60, last frame's +0xA0). The vector
    transform sub_000FF13D (stdcall: out, v, m) is wrapped: for the
    player's weapon (id 1) while a guest plays, the samples reach further
    along the blade (x1.35; Frodo x1.6 for Sting's short blade). Measured
    in Hornburg Courtyard, heavy-attack hits went from none to on a par
    with Aragorn's.
  - Weapons: the hero's records name two sword-hand models, 4586A62C and
    13F82514 (the one drawn in his hand as he fights); both, and the bow,
    become the guest's, in the level's weapon records and in the weapon
    script op's resource lookups. Boromir: his sword, and his shield built
    into his model on his left forearm (his texture made 256x512 to hold
    it; DXT1 codec). Gandalf: his staff in his sword hand at all times, an
    empty prop in the bow's. Frodo: Sting, with its second texture layer,
    its steel tinted a pale blue as it is copied in. Lurtz: his Uruk-hai
    sword and his own bow.
  - Gandalf's shots are a magic beam: a shot whose shooter (the bow-hand
    weapon object, model at +0x494; that model's key at +4) is his is
    always the magic bolt (projectile 15), and as it leaves a line of
    glowing particles runs from the staff's head (the staff object's
    world box) to the aim point. The projectile launch and impact
    (0xD9460 / 0xDA180) are wrapped for this.
  - Each guest's own idle pose on the character select (and his own pose
    when chosen and confirm move), his own figure on the pause upgrades
    screen and the end-of-level 3D model, his own HUD portrait, upgrade
    and results-screen pictures (film stills from the game's own
    UI\stills*.BFF; for Boromir a cameo from his face texture).
  - Model fixes: per-part palette remap, stale bone indices, torn
    stencil-shadow data blanked; Frodo on Gimli's level variant.
  - Fix: a crash after the intro (Boromir's 256x512 texture overran its
    buffer: mips not counted).
  - Fix: the heroes missing from the select after returning to the menu.
  - Weapons everywhere his model is drawn (1.3 update):
    - The character select: each guest's sword-hand weapon is added to
      the menu file (prop 1200 / texture 1250, keys 0x31-0x34; Sting
      tinted) and attached with the game's own call (sub_000CA540), as it
      does for Aragorn's sword. Before, his hands were empty.
    - Cutscenes: the hero's in-hand sword model (13F82514) becomes the
      guest's weapon in every record that names it, not only the player's,
      so the cutscene copies of him carry it too. Before, they held
      Aragorn's sword.
    - The pause screen's upgrade figure: drawn from his model as he plays
      (Boromir's with his shield), with his weapon hung from his hand
      (placed by the hand's attach point in the bind pose, turned with
      the lowered arm, blade down by his side, Gandalf's staff upright).
src/twotowers_manual.c (game)
  - Wrapped for the above: 0xD9460, 0xDA180, 0xFF13D (and, for testing
    logs only, 0xBA110 melee sweep results, 0x9E9D0 script callbacks,
    0x8E470 particle spawns, 0xB4220 LightGlowEffect).
kernel/nv2a_d3d11.inc, nv2a_d3d11_vp.inc, nv2a_pb_exec.c
  - xbox_gpu_cpu_lo/hi: the title can ask for the models whose vertex data
    lies in a range to be transformed on the CPU. Testing switches
    RECOMP_BIGTRI, RECOMP_HWVP_DENY.
src/e3hud.c, e3hud_tex.inc (ECTS HUD mod)
  - A guest's own portrait in the medallion. The HUD is drawn only in play.
Testing switches (heroes.c): TT_SWEEPLOG (melee sweep hits per weapon,
  kills), TT_SHOTLOG, TT_WDBDUMP (the weapon table), TT_WREACH,
  TT_NOWAXIS, TT_RT_NOHAND, TT_NOSWORD2, TT_NOTINT, TT_NOTEX2, TT_NOFEW
  (no weapon on the select), TT_NOFIGW (no weapon on the
  upgrade figure), TT_FIGWRAW, TT_FIGDUMP (the upgrade figures written to
  heroes\fig_<name>.ppm).

-- 1.3.1 -----------------------------------------------------------------
src/heroes.c (game, Extra heroes mod)
  - Boromir's and Frodo's heavy attacks, kicks and light attacks aim where
    they face. Their melee moves are Aragorn's, retargeted, and Aragorn's
    sword stance turns his body about 40 degrees at bone 1 (the root's
    child). The game allows for that turn on the hero but not on a guest,
    so their blows went that far to one side of the one they faced. Their
    retargeted melee moves are now turned back by the hero's stance (bone
    1's turn in his fighting stance, slot 34, at its start). Measured in
    Hornburg Courtyard with heavy attacks pressed throughout (the player's
    sword's hit tests, sub_000BA110, and their hits): Boromir from about 10%
    of hit tests landing to about 18%, Frodo from 1% to about 25%;
    Aragorn's own about 14%. Lurtz (his own moves) about 15%, unchanged.
  - The retarget's rig map put right where it skipped a joint the hero
    has: the guest's root and its child take the hero's own (the root
    keeps no rotation keys, as every hero's and guest's own moves have
    it), and a bone between two mapped ones takes the hero's bone between
    them (the pelvis the hero's pelvis, the collarbones his collarbones,
    not his lower spine and neck). World rotations were copied before as
    well; this moves the shoulders and hips to where the hero's are, so the
    hands and blade are about 30% closer to the hero's.
  - Boromir's skeleton gets what every other hero's has: the "skel"
    chunk's two aiming blocks (they could not go in before: his chunk has
    no last word to put them before; now they go at its end) and attach
    points 6 (the spine bones turned toward a target) and 7 (head, spine,
    hands, pelvis, knees, feet), his bones for the hero's.
src/twotowers_manual.c (game)
  - The melee sweep and HUD wrappers also call testing logs (TT_HEADLOG).
Testing switches (heroes.c): TT_HEADLOG (at each of the player's sword's
  hit tests: the blade tip's and the victim's bearings from its owner, and
  every frame its hand and tip in the owner's frame), TT_RTYAW=degrees
  (the retargeted moves turned by this), TT_RTNOTURN, TT_RT_OLDMAP,
  TT_NOAIM2, TT_WREACH may now be negative.
```
