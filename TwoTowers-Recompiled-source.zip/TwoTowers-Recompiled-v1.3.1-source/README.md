# The Two Towers Recompiled

An unofficial native Windows (x64) port of **The Lord of the Rings: The Two Towers** for the original Xbox (USA retail release). It was made by *static recompilation*: the game's own executable is translated into C and runs natively, with no emulator in between. It uses the [xboxrecomp](#credits) toolkit.

> [!IMPORTANT]
> **No game data is included anywhere: not in this repository and not in the release build.** To play, you need your own legally obtained copy of the original game: the USA Xbox disc, as an ISO image or as extracted files.

---

## Disclaimer

- **For educational and game-preservation purposes only.** This is a non-commercial, fan-made research project. Its purpose is to study how original Xbox software works and to keep a legally owned game playable on modern hardware.
- **Not affiliated with, endorsed by, or connected to** Middle-earth Enterprises, the Tolkien Estate, New Line Cinema, Warner Bros. Entertainment, Electronic Arts, Stormfront Studios, Microsoft, or any of their affiliates or licensors.
- *The Lord of the Rings*, *The Two Towers* and every related name, character, place, logo and image are trademarks and/or copyrighted material of their respective owners. Xbox is a trademark of Microsoft. **The authors of this project own no rights to any of them.** All rights remain with their owners.
- **What is and isn't included:**
  - **The source repository** contains no game data, no code generated from the game, and no cover art. Building from source translates the game's code on your own computer, from your own copy, with `generate.py`.
  - **The release build** (`TwoTowers-Recompiled-…-win64.zip`) contains no game data either: no movies, sounds, music, textures, models, levels, text or cover art. Its game program does include code that was mechanically translated from the original game's executable, as every static recompilation does. That translated code cannot run on its own: when the program starts, it loads the game's original executable and all of its data from your own copy.
  - **You must own the game.** The release is only for use with a legally obtained USA copy of *The Two Towers* that belongs to you. If you don't own the game, don't download or use the release.
- **Do not use this project for piracy.** Do not ask for, share or link to copies of the game or its files. The launcher only accepts the USA retail release, checked by its SHA-256 hash. Buy the game and make your own backup of your own disc.
- The software is provided "as is", without warranty of any kind (see [LICENSE](LICENSE)). Use it at your own risk.
- If you are a rights holder and have a concern, please open an issue and it will be addressed promptly.

---

## Contents

- [Requirements](#requirements)
- [Installing and playing](#installing-and-playing)
- [Linux](#linux)
- [Graphics settings](#graphics-settings)
- [Controls](#controls)
- [Settings file reference](#settings-file-reference-twotowers_recompini)
- [Saves, logs and troubleshooting](#saves-logs-and-troubleshooting)
- [Building from source](#building-from-source)
- [Project layout](#project-layout)
- [Status and known issues](#status-and-known-issues)
- [Credits and licences](#credits-and-licences)

---

## Requirements

- Windows 7 SP1, 8.1, 10 or 11, 64-bit — or Linux, 64-bit (see [Linux](#linux)).
- A Direct3D 11 (feature level 11_0) graphics card: NVIDIA GeForce 400 series or later, AMD Radeon HD 5000 or later, Intel HD Graphics 4000 or later. Any card from the last ten years works at 1x internal resolution. Without one the game still runs, drawn by the CPU (slower).
- Your own copy of *The Lord of the Rings: The Two Towers*, **USA Xbox release**, in either form:
  - an Xbox disc image (`.iso` / `.xiso`, the "redump"/XDVDFS format), or
  - the disc's extracted files: a folder containing `default.xbe` and the `FMV`, `SOUND`, `UI`, `Worlds`, … folders.

  Other regions and versions are not supported. Both the launcher and `generate.py` check the SHA-256 of `default.xbe`.
- On Windows 10 and 11, no other software: every DLL the program uses is part of Windows.
- On Windows 7 and 8.1:
  - the HLSL shader compiler: `d3dcompiler_47.dll` (KB4019990 on Windows 7) or the DirectX End-User Runtime's `d3dcompiler_43.dll`. Without either, the game uses the software renderer;
  - sound uses XAudio2 where Windows has it (8 and later) and the older waveOut otherwise.

## Installing and playing

1. Download the release build `TwoTowers-Recompiled-…-win64.zip`, or [build it yourself](#building-from-source). It contains two programs:
   - `The Two Towers Recompiled.exe`: the launcher;
   - `twotowers_recomp.exe`: the game.
2. Put both in **a new, empty folder of their own**, for example `C:\Games\TwoTowersRecompiled`. Don't put them inside another game's install folder. The program writes its settings, saves and log next to itself.
3. Run **`The Two Towers Recompiled.exe`** and choose one of:
   - **Install from ISO…**: pick your disc image. The launcher checks that it is the USA release and extracts the game files into a `game_files` folder beside the launcher. This takes a minute or two, and a progress bar shows how far it has got.
   - **Use extracted folder…**: pick the folder that contains `default.xbe`. Nothing is copied; the launcher remembers the folder.
4. When the status line says **"Game files ready"**, press **Play**.

Later you can start `twotowers_recomp.exe` directly, or keep using the launcher.

Two launcher options:
- **Show the game window**: leave this on.
- **Write a log file**: writes `twotowers_log.txt`. It is useful for bug reports.

## Linux

The Linux build is a separate download, `TwoTowers-Recompiled-…-linux-x86_64.tar.gz`. It runs on 64-bit distributions from 2018 on (glibc 2.27 or newer: Ubuntu 18.04+, Debian 10+, Fedora 28+, Mint 19+, Arch, the Steam Deck's desktop mode, …).

1. Install SDL2 if you don't have it (most desktops do): `sudo apt install libsdl2-2.0-0` (Ubuntu / Debian / Mint), `sudo dnf install SDL2` (Fedora), `sudo pacman -S sdl2` (Arch).
2. Unpack the archive into a new folder of its own.
3. Run **`TwoTowers.sh`** (double-click it, or `./TwoTowers.sh` in a terminal). The first time it asks for your disc image and extracts it into `game_files` — with a file dialog if `zenity` is installed, otherwise in the terminal — and offers to add the game to your applications menu.

`./twotowers-setup` does the same from a terminal: `install <iso>`, `folder <dir>` (an extracted disc), `desktop` (menu entry), or no argument for a small menu with a few settings. Everything else is in the game's F10 menu and in `twotowers_recomp.ini`, as on Windows.

The picture is drawn with OpenGL 3.3 (any graphics driver from the last ten years — Mesa for AMD and Intel, or NVIDIA's), sound goes through SDL (PulseAudio, PipeWire or ALSA), and controllers through SDL too: Xbox, PlayStation 3/4/5, Switch Pro and most others, with rumble. Saves and the log are next to the program, as on Windows.

## Graphics settings

You can change the graphics settings in two places. Both write to the same settings file.

### In the launcher

Press **Graphics settings…**. Each option has a drop-down list. **Defaults** restores the original settings, and **OK** saves.

### In game: the overlay menu

- Press **F10** on the keyboard, or **hold Back and press Start** on a controller.
- A panel appears over the game, and the game ignores your input while it is open.
- **Up/Down** chooses an option, and **Left/Right** (or **A** / **Enter**) changes it.
- **B**, **Esc** or **F10** closes the panel.
- Changes apply immediately and are saved automatically.
- The first line, **Page**, switches between the **Graphics** and **Controls** pages.

| Option | Choices | Notes |
|---|---|---|
| Frame rate | 30 (original), 60, Unlocked | 60 and Unlocked are **experimental**: some scenes can run faster than intended. Use 30 if something seems off. |
| Display mode | Windowed, Full screen | Borderless full screen. **Alt+Enter** or **F11** also switches at any time. |
| Window size | Automatic, 1280×720 … 5120×1440 | Launcher only. Sets the size of the window when not in full screen. |
| Aspect ratio | 4:3 (original), 16:9, 16:10, 21:9, 32:9 | **Widescreen is experimental.** Gameplay shows more to the left and right. The HUD keeps its shape, and menus and movies stay 4:3. In game, the 3D view widens fully after the next level load. |
| Internal resolution | 1x (640×480) … 4x (2560×1920) | Sharper picture, at a higher graphics-card cost. Start with 2x. |
| Anisotropic filtering | Off, 2x, 4x, 8x, 16x | Sharper textures at an angle. |
| Mipmaps | On, Off | On means less shimmer on distant textures. |
| Anti-aliasing | Off, FXAA | Smooths edges on the final picture. |
| VSync | Off, On | On prevents tearing. |
| Picture | Keep shape, Stretch to fill | |
| Vertex programs | Graphics card, CPU | Leave this on Graphics card, which is much faster. CPU is the reference path, for troubleshooting. |
| Brightness | Darker … Brightest (5 steps) | Gamma on the final picture. Lifts the game's very dark areas. *(new in 1.1)* |
| Sharpening | Off, Low, Medium, High | Contrast-adaptive sharpening of the final picture. Best with a higher internal resolution. *(new in 1.1)* |
| Colour | Original, Vivid, Muted | Colour saturation. *(new in 1.1)* |
| Mod: ECTS 2002 HUD (experimental) | Off, On | Launcher only. See [Mods](#mods-new-in-11). |
| Mod: Orange health pickups (shown in pre-release & making-of videos) | Off, On | Launcher only. See [Mods](#mods-new-in-11). |
| Mod: Extra heroes | Off, On, On (unlocked for testing) | Launcher only. **Highly experimental.** See [Extra heroes](#extra-heroes-extra_heroes1-highly-experimental). |

## Mods (new in 1.1)

Two optional mods bring back how the game looked before it was finished, and a third (new in 1.2, much improved in 1.3, highly experimental) adds playable characters. All are off by default and leave the retail game untouched when off. Turn them on in the launcher (**Graphics settings…**) or in the `[Mods]` section of the settings file; they take effect when the game starts (they are deliberately not in the in-game F10 menu, so they cannot be switched half-way through a level).

### Why these mods exist

The Two Towers was shown before release — most visibly in the playable build at **ECTS 2002** (the European Computer Trade Show) and in pre-release trailers and making-of videos. That build differed from the retail game in a few visible ways: a different HUD, and orange health pickups instead of green ones. None of it shipped, and the footage is all that is left of it. The retail game still has a debug switch called *"DEBUG/Display EXP and Runes"*, but the code behind it was removed, so the old HUD cannot simply be switched back on.

These mods recreate that pre-release look from the footage, as a piece of preservation: a way to play the game as it was shown, not as an improvement on the retail design. They are reconstructions, not recovered code — measured frame by frame from the videos and drawn with the game's own textures and fonts where possible.

(Earlier builds of this project called them the "E3" HUD and "E3 power-ups". The footage is in fact from ECTS 2002, so they were renamed. The settings keys keep their old names — `e3_hud`, `e3_pickups` — so existing settings files still work.)

### ECTS 2002 HUD (`e3_hud=1`, experimental)

What changes, and why:

| Change | Retail game | ECTS 2002 HUD | Why |
|---|---|---|---|
| Portrait | none | the character's face in a round medallion at the health sword's grip | The demo showed who you were playing on the sword itself. |
| Sword cross-guard | straight bar | curved toward the blade, brighter steel | Matches the demo's sword. |
| Health bar | green | green (unchanged) | The demo's bar was the same colour, so it is left as retail. |
| Experience gauge | ornate tube with a silver medallion | plain rectangle, filling blue | The demo's simpler gauge. The retail fill is kept underneath, so it still shows your real experience. |
| Combo display | none | a **rune orb** under the gauge | The demo showed each combo as it was entered: the orb's quarters fill clockwise from the top right, one per attack — **A** (speed) blue, **Y** (fierce) green, **B** (knock back) red. |
| Combo name | none | **Speed**, **Fierce**, **Special** or **Mixed** beside the orb when a combo ends (Mixed turns the whole orb magenta) | As in the demo, in the game's own lettering, enlarged to match the footage. |
| Kill rating ("Good", "Excellent" …) | above the gauge | beside the gauge's top | Its place in the demo. |
| Experience readout | none | **EXP: current/needed** | The demo showed the numbers toward the next level. |
| Loading-screen tip about experience | the retail gauge | the new gauge and orb, with a second arrow and a short explanation of the combo runes | So the tip describes the HUD you actually see. |
| Loading-screen tip about the Skill Meter (Fangorn) | the retail gauge | the new gauge and orb, with the arrow to "Skill Meter" kept | The same tip for the same gauge. |
| Mission results screen | the retail gauge at the top right | the new gauge and orb in its place | The gauge looks the same everywhere it appears. |
| Helm's Deep wall: progress bar portrait | a hooded figure in a spiked medallion | the demo's framed picture of the figure, level with the bar | As in the demo footage. |
| Westfold: villager counter | a green bar with a portrait, shortening as villagers are lost | two rows of four villager couples; each pair lost is crossed out in red | The demo's counter. Same balance as retail: the bar had 8 steps, so 8 couples. |

It is marked **experimental** because it is drawn on top of a HUD the game was never designed to change: it has been tested through the levels played so far, but an odd frame (a menu, a cut-scene) could still show a piece of it out of place. Turn it off in the launcher if anything looks wrong.

The portraits are crops of the ECTS 2002 footage and are loaded from the `e3hud` folder beside the program (`aragorn.bmp`, `legolas.bmp`, `gimli.bmp`, 32-bit BMPs with transparency; for the Extra heroes mod also `boromir.bmp`, `frodo.bmp` and `lurtz.bmp`, made from the game's artwork), as are the Helm's Deep wall level's progress-bar picture (`level10.bmp`; without it that level keeps the retail portrait) and Westfold's villager couples (`villager.bmp`, `villager_dead.bmp`; without them Westfold keeps the retail bar). They are included in the release download but **not** in this source repository. Without them, Aragorn's, Legolas's and Gimli's portraits are made from the character models' own face textures. Isildur, who is not in the footage, always uses the picture from the game's upgrade screen.

### Orange health pickups (`e3_pickups=1`)

In pre-release and making-of videos the health pickups glow orange; in the retail game they are green vials. This mod recolours the vial's glass to orange as the game loads the texture (hash `71C950C7`, recognised out of the box). Only the glass panes change; the metal frame and everything else stay as they were, and nothing in your game files is modified.

If some other green pickup should turn orange too, its texture can be added:

1. Set `texture_dump=1` in the settings file (any section; `[Developer]` is where the template has it).
2. Play until the item is on screen, then quit. The log says where the dump went (`[TEXDUMP] saving textures to ...`).
3. The `texture_dump` folder beside the program now holds every texture drawn, named `HASH_WxH_fFMT.bmp`. Add the item's hash to `[Mods] e3_pickup_textures=` (several hashes can be given, separated by commas).
4. Set `texture_dump=0` again (dumping is slow).

### Extra heroes (`extra_heroes=1`, highly experimental)

> ⚠ **Highly experimental.** Much better in 1.3, but still a mod built on a game that was never made for it: expect the odd visual glitch, and possibly crashes. It is **off by default**; turn it off again (launcher, or `extra_heroes=0`) if anything goes wrong. Your saves are not changed by it.

Adds four more playable characters to the character select, made from the game's own models: **Boromir, Gandalf, Frodo and Lurtz**, for eight in all.

- **Unlocking (new in 1.3):** one at a time, by finishing the Tower of Orthanc as Isildur on that save. The 2nd finish unlocks Boromir, the 3rd Gandalf, the 4th Frodo and the 5th Lurtz. A hero still locked shows as a faint shadow on the select and is skipped. `extra_heroes=2` ("On, unlocked for testing" in the launcher) shows all four on any save. That only changes what the game sees while it runs and writes nothing to the save.
- **How they play:** each one takes the fourth hero's place (Isildur's) in the level, with his own experience, scores and upgrades. Those are kept in the `heroes` folder beside the program (`heroes/records.dat`, and the unlocks in `heroes/unlocks.txt`); the save keeps Isildur's.
- **Their own bodies and moves (new in 1.3):** they play on their own skeletons, with their own walk, run, block, hit reactions and death. Boromir and Frodo fight with the heroes' light and heavy attacks, fitted to their bodies; Gandalf and Lurtz fight with their own. Heavy attacks hit as the heroes' do, and (1.3.1) Boromir's and Frodo's blows and kicks go where they face.
- **Their own weapons (new in 1.3):**
  - Boromir: his sword, and his shield on his other arm.
  - Gandalf: his staff, always in hand. His ranged attack is a beam of light from the staff's head instead of arrows.
  - Frodo: Sting, its blade glowing a pale blue.
  - Lurtz: his Uruk-hai sword and his own bow.
  - They carry them wherever they appear as the hero: in play, in the cutscenes, on the character select and in the pause screen's upgrade figure.
- **Their own pictures (new in 1.3):** each has his own idle pose on the character select, his own figure on the pause screen's upgrades and the end-of-level model, and his own HUD portrait (also in the ECTS HUD mod), upgrade and results-screen pictures.
- **The `heroes` folder** also holds the mod's private copies of the game files it changes (the menu and the levels you play with a new hero). Deleting the folder resets the new heroes' progress and unlocks and rebuilds the copies.

Known problems:

- They have no voices of their own.
- Sting's glow is a tint of the blade, not a light that shines on its surroundings.
- Breaking enemy shields with heavy attacks has not been measured for them as closely as plain hits; reports are welcome.

Bug reports with `twotowers_log.txt` (its `[HEROES]` lines) are welcome.

## Controls

An Xbox / XInput controller (Xbox 360, One, Series, or anything that acts like one) works out of the box. The keyboard and mouse act as controller 1.

**PlayStation controllers** (DualShock 3, DualShock 4, DualSense / DualSense Edge), Switch Pro and other pads work too, with rumble, over USB or Bluetooth:
- on Windows, put **`SDL2.dll`** (64-bit, from the SDL2 release, or the one included with this download) beside `twotowers_recomp.exe`. It is only loaded if it is there; Xbox pads keep going through XInput either way. Steam's controller support can also present a PlayStation pad as an Xbox one, if you prefer;
- on Linux, nothing to add.

The DualShock 4 / DualSense touch pad click is Back, and their light bar turns green, like player 1's light on an Xbox pad.

**Button prompts.** With a PlayStation pad as player 1, the game's button prompts (the upgrade screen's combo lists, "Help", …) show the cross, circle, square and triangle in place of A, B, X and Y, and R2 for the right trigger. Choose it in the F10 menu ("Button prompts": Automatic / Xbox / PlayStation) or in the settings file (`[Input] prompts=auto|xbox|playstation`). The loading screens' controller pictures then show a PlayStation pad too — a DualShock 3, DualShock 4 or DualSense, whichever is plugged in as player 1 (a DualShock 4 if none is; `[Input] ps_pad=auto|ps3|ps4|ps5` picks one). Those pictures are the `prompts` folder beside the game; without it the Xbox pad stays.

### Default keyboard and mouse layout

| Controller | Keyboard / mouse |
|---|---|
| Left stick (move) | W A S D |
| Right stick | Numpad 8 / 4 / 2 / 6 |
| A | K, Left mouse button, Space |
| B | L |
| X | J, Right mouse button |
| Y | I |
| Black / White | C / Z |
| Left / Right trigger | F / R |
| Start | Enter, Esc |
| Back | Backspace, Tab |
| D-pad | Arrow keys |
| Left / right stick click | Shift / Middle mouse button |

There is also a "classic" layout: set `layout=classic` under `[Input]` in the settings file.

### Remapping

You can change every action, for both keyboard/mouse and controller.

**In the launcher:** press **Controls…**.
- Click an action's key box, then press any key or mouse button. Esc cancels.
- **×** clears an action's keys.
- The drop-down list on the right chooses which button on your own controller performs the action.
- **Defaults** restores the original layout. **OK** saves.

**In game:** press **F10**, then on the **Page** line press **Right** to reach **Controls**.
- Press **A** or **Enter** on an action, then press the new key or mouse button. **Esc** cancels and **Delete** clears it.
- **Left/Right** changes the controller button for that action.
- The last line resets every binding to its default.

How bindings behave:
- Each action can have up to three keys or mouse buttons.
- A key you assign is removed from any other action that used it.
- Choosing a controller button that another action already uses swaps the two, so nothing is lost.

## Settings file reference (`twotowers_recomp.ini`)

The program creates `twotowers_recomp.ini` next to itself on first run, and the comments inside it explain each option. The launcher and the in-game menu edit this file for you. The main keys:

```ini
[Paths]
game_dir=            ; extracted game folder; empty = game_files beside the exe
[Display]
window=1
fps=30               ; 30 | 60 | unlocked
fullscreen=0
window_size=         ; e.g. 1920x1080; empty = automatic
aspect=4:3           ; 4:3 | 16:9 | 16:10 | 21:9 | 32:9 | a number such as 2.37
render_scale=1       ; 1-4
anisotropic=1        ; 1 (off), 2, 4, 8, 16
mipmaps=1
antialiasing=off     ; off | fxaa
vsync=0
stretch=0
vertex_programs=gpu  ; gpu | cpu
renderer=d3d11       ; d3d11 | software
brightness=1         ; 0.85 | 1 | 1.15 | 1.3 | 1.45
sharpening=0         ; 0 | 0.4 | 0.7 | 1
colour=1             ; 1 | 1.25 (vivid) | 0.8 (muted)
[Mods]
e3_hud=0             ; 1 = the ECTS 2002 demo's HUD (experimental)
e3_pickups=0         ; 1 = orange health pickups
e3_pickup_textures=  ; vial texture hashes (hex, comma separated)
extra_heroes=0       ; 1 = Boromir, Gandalf, Frodo, Lurtz (highly experimental); 2 = the same, unlocked on any save
[Input]
keyboard=1
layout=wasd          ; wasd | classic
background_input=0   ; 1 = the controller also works while another window is in front
stick_deadzone=10    ; stick dead zone in percent (stops a drifting stick walking the hero); 0 = off
[Controls]
kb_a=K, Mouse Left, Space    ; written by the Controls pages
pad_a=A
[Audio]
output=1             ; 0 = no sound (for PCs without an audio device)
[Compat]
single_cpu=1         ; the game's own threads share one CPU, as on the Xbox
[Developer]
logging=1
texture_dump=0       ; 1 = save every texture drawn to texture_dump\ (slow)
```

If the settings file comes from an older build, the program rewrites it on start. It keeps your values and saves the previous file as `twotowers_recomp.ini.old`.

## Saves, logs and troubleshooting

- **Saves** go in `game_files\UDATA\` (or in your extracted folder's `UDATA`). Back that folder up to keep your progress.
- **Log**: `twotowers_log.txt`, next to the exe. Attach it to any bug report.
  - It lists the renderer, the frame rate (`[FPS]`) and, if the game ever stalls, where each part of the program was (`[HANG]`).
  - Please check that it contains nothing you'd rather not share before posting it.
- **Black window or "no Direct3D 11 device"**: update your graphics driver. `renderer=software` is a slow fallback.
- **Low frame rate**: lower **Internal resolution** first, then anisotropic filtering, and turn FXAA off. Make sure **Vertex programs** is set to **Graphics card**.
- **Keyboard does nothing**: click the game window so it has focus, and check that `[Input] keyboard=1`.
- **Controller does nothing**: the game only reads it while its window is in front (so it never reacts while you use another program). Click the game window, or set `[Input] background_input=1`.
- **Game runs too fast**: set **Frame rate** back to **30**.

## Building from source

The C code for the game is not in this repository. You generate it from your own `default.xbe`, then compile it together with the runtime.

### Tools

- **Python 3.10+**, for the recompiler (no extra packages).
- **CMake 3.20+** and **Ninja**.
- A compiler:
  - **[llvm-mingw](https://github.com/mstorsjo/llvm-mingw)**: tested. Use it natively on Windows, or cross-compile from Linux or WSL.
  - **MSVC**: may work, but has not been tested.

### Steps

```sh
# 1. Translate YOUR copy of the game (default.xbe or the extracted disc folder).
#    It checks the SHA-256 and takes several minutes; nothing leaves your machine.
python generate.py "path/to/extracted/game"

# 2a. Configure on Windows, with llvm-mingw's bin folder on PATH:
cmake -S twotowers -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++

# 2b. ...or configure from Linux/WSL, cross-compiling with llvm-mingw on PATH:
cmake -S twotowers -B build -G Ninja -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_TOOLCHAIN_FILE=$PWD/xboxrecomp-0.12.0/cmake/mingw-w64-x86_64.cmake

# 3. Build.
cmake --build build
```

Route 2b, cross-compiling, is how the release builds are made. Route 2a uses the same compiler natively.

The build produces `build/twotowers_recomp.exe` and `build/The Two Towers Recompiled.exe`. Copy both into an empty folder and follow [Installing and playing](#installing-and-playing).

### Optional

- **Your own icon and launcher art**: put `twotowers.ico` and/or `cover.bmp` (369×385) in `twotowers/resources/local/` before configuring. That folder is ignored by git. The launcher also shows a `cover.bmp` placed beside it.
- **Builds are reproducible and contain no paths from your machine**: source paths are remapped (`-ffile-prefix-map`) and the link timestamp is omitted.

### Developer switches

These are environment variables, used for testing:

| Variable | Effect |
|---|---|
| `RECOMP_HW_VP=0` | Run the game's vertex programs on the CPU. |
| `RECOMP_HW_PS=0` | Use the general pixel shader instead of per-effect shaders. |
| `RECOMP_PAD_SCRIPT=file` | Scripted controller input (`<ms> <BUTTON>` or `<file>+<ms> <BUTTON>` lines). |
| `TT_TWEAKS="SKIPMAINMENU=1;HERO=aragorn;LEVEL=02GATE2"` | The game's built-in developer switches: start straight in a level. |
| `TT_DEBUG_GOTO=<1-11>` | With the pad-script `FLAG1`, jump the front end to a screen (10 = end of level, 11 = upgrades). |

## Project layout

```
generate.py                 xbe -> C, using the pipeline below
twotowers/                  the game project
  CMakeLists.txt
  config/seed_functions.json  extra function entry points found while bringing the game up
  postproc_apu.py           post-pass on the generated code (direct sound-chip register access)
  src/main.c, twotowers_host.h      startup, settings file, paths, logging
  src/twotowers_manual.c    hand-written replacements and hooks for specific game functions
  src/setup_launcher.cpp    the launcher (ISO extraction, settings, controls)
  src/heroes.c              the Extra heroes mod (character select, re-rigged models, records)
  src/e3hud.c               the ECTS 2002 HUD and orange-pickup mods
  tools/rig/                how heroes.c's bone tables were made (chain.py)
  src/recomp/gen/           GENERATED by generate.py -- not in git
  resources/                neutral icon, manifest
xboxrecomp-0.12.0/          the recompiler and Xbox runtime, with the changes made for this game
  tools/                    xbe_parser, disasm, func_id, abi_analysis, recomp, ...
  src/                      kernel, NV2A GPU (Direct3D 11 back end), APU audio, input, video
CHANGES.md                  everything changed in xboxrecomp for this port
```

## Status and known issues

**Work in progress.** The game is playable, and more updates and bug fixes are coming. Play at **30 fps** (the frame rate it was made for), and if the game crashes or freezes, restart it: the same spot usually works on the next try.

- Tested in 1.1.1 by a scripted run of every level, rotating heroes (Aragorn, Legolas, Gimli, and Isildur in the prologue) and 30 / 60 / unlocked fps: the prologue, Weathertop, Caradhras, Balin's Tomb, Amon Hen, the three Rohan levels, the three Helm's Deep levels and both Orthanc levels all load, play their movies and reach gameplay with no crash and no freeze. Fangorn was not part of that run.
- Tested in 1.3: every level again on Windows without the mod (all 14 load, 30 / 60 / unlocked fps, no crash); the Extra heroes mod's four heroes on the Plains of Rohan and in Hornburg Courtyard (moves, weapons, Gandalf's beam, heavy-attack hits measured against Aragorn's); on Linux, a level with Boromir (built, opening scene).
- New in 1.3, **highly experimental**: the [Extra heroes](#extra-heroes-extra_heroes1-highly-experimental) mod's heroes have their own bodies, moves, weapons and pictures, and unlock one by one.
- New in 1.3.1: in the Extra heroes mod, Boromir's and Frodo's heavy attacks and kicks go where they face (before, about 40 degrees to one side). Tested on Windows in Hornburg Courtyard (their hits measured against Aragorn's), and on Linux with Frodo (level built, opening scene).
- Tested in 1.2: every level again on Windows (all 14 load and reach gameplay, 30 / 60 / unlocked fps) and on Linux (all 14; a crash entering Balin's Tomb on Linux was found and fixed), and a start under Windows 7 compatibility.
- Known in 1.2: rarely (once in about 30 test runs, on a heavily loaded two-core machine) the game froze during the movie before Amon Hen; the next try was fine. On PlayStation prompts, the loading-screen and message text still names the Xbox buttons ("Press the A button"); the pictures and button icons change.
- Fixed in 1.2: controls freezing with the last input held (Windows builds); a crash in Helm's Deep at 60 fps / unlocked; with the ECTS HUD mod, Westfold's villager faces no longer show on the results and upgrade screens after the level.
- New in 1.2, **highly experimental**: the [Extra heroes](#extra-heroes-extra_heroes1-highly-experimental) mod (off by default).
- Fixed in 1.1.3: controller rumble now reaches the PC controller (it was received and dropped); sound now comes back by itself if the audio device stops (headphones, a default-device switch, a display going to sleep), which may be what silenced it after an upgrade screen; with the ECTS HUD mod, its gauge and portrait no longer appear over the mission results screen's "Replay" and title.
- Fixed in 1.1.2: after about eight minutes of play the game slowed right down, lost controller input or crashed (often noticed after a cutscene). A log counter overflowed and the game then wrote millions of log lines a second.
- Fixed in 1.1.1: a freeze during movies (Amon Hen, the prologue's opening), a freeze while loading on a busy PC, black boxes over the lava heat haze, and "disc is dirty" errors when another program reads a game file at the same moment.
- Character shadows: drawn as stripes until 1.1; they are now the game's soft shadows, and match the reference software renderer. Some scenes may still look off; reports with a screenshot are welcome.
- Audio: some crackling or music cutting out can still happen, mostly at 60 fps and unlocked.
- The 60 fps and unlocked modes are experimental. If a crash happens, the end of `twotowers_log.txt` says where (`[CRASH]`); please send it.
- Widescreen is experimental: a few full-screen effects may not line up at the edges.
- Bug reports are welcome. Please include `twotowers_log.txt`.

## Credits and licences

- **xboxrecomp** (the recompiler and Xbox runtime) is by sp00nz and is **MIT** licensed (`xboxrecomp-0.12.0/LICENSE`). This repository includes it with the changes described in `CHANGES.md`.
- Parts of the runtime are taken from **[xemu](https://github.com/xemu-project/xemu)**: the MCPX APU audio and the NV2A register definitions. They are **LGPL-2.1-or-later** and copyright of their authors (see `xboxrecomp-0.12.0/NOTICE` and `xboxrecomp-0.12.0/LICENSES/`). Their complete source is included here, so you can rebuild the program with modified versions of them, as the LGPL requires.
- The port-specific code (`twotowers/`, `generate.py`) is released under the **MIT** licence (see [LICENSE](LICENSE)).
- All game content belongs to its respective rights holders; see the [disclaimer](#disclaimer).
