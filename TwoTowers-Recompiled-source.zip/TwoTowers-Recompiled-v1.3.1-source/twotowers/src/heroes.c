/* heroes.c -- the Extra Heroes mod (v1.4): Boromir, Gandalf, Frodo and
 * Lurtz as playable characters, next to Aragorn, Legolas, Gimli and Isildur.
 *
 * twotowers_manual.c wraps a few retail functions with tt_hk(id, phase,
 * regs): phase 0 before the original (return nonzero to skip it; regs[0] is
 * then eax and regs[3] esp after the return), phase 1 after. TT_GAMELOG=1
 * (testing) logs the interesting ones.
 *
 * How it works
 * ------------
 * The game builds its hero from a placement record in the level file -- a
 * name ("aragornHero...") and resource keys: mesh (type 100), animation set
 * (150), texture (300) -- and loads the level variant of the chosen hero
 * (.bfa Aragorn, .bfl Legolas, .bfg Gimli, .bfi Isildur).
 *
 * - Character select: the carousel of 3D characters gets eight places once
 *   Isildur is unlocked (the final and the secret mission done): the four
 *   retail ones and the four extra heroes. Their models are added to the
 *   menu's file (ui\mainmenu.bff, rebuilt once into heroes\) and four more
 *   characters are created in the menu's character manager (0x49F440, room
 *   for eight); the carousel is drawn by layout() here for eight places, the
 *   same way the game draws three or four.
 * - An extra hero plays as hero 4 (Isildur's records: upgrades, experience,
 *   levels done -- kept per extra hero in heroes\records.dat and swapped in
 *   when one is chosen). In a level, hero 4 opens a rebuilt copy of
 *   Aragorn's variant with the hero's mesh, animations and texture copied in
 *   from the level that has them, and every reference to Aragorn's keys in
 *   the level image points at the hero's (skin_apply). The animation set has
 *   to be the character's own: the skeletons differ.
 *
 * [Mods] extra_heroes=1 turns it on (the launcher's "Extra heroes"). */
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/stat.h>

extern ptrdiff_t xbox_GetMemoryOffset(void);
extern void tt_dbg(const char *fmt, ...);
extern uint32_t tt_gcall(uint32_t va, uint32_t thisptr, int n, const uint32_t *args);
extern uint32_t tt_guest_esp(void);
#define G8(a)  (*(volatile uint8_t *)(xbox_GetMemoryOffset() + (uint32_t)(a)))
#define G16(a) (*(volatile uint16_t *)(xbox_GetMemoryOffset() + (uint32_t)(a)))
#define G32(a) (*(volatile uint32_t *)(xbox_GetMemoryOffset() + (uint32_t)(a)))
#define GF(a)  (*(volatile float *)(xbox_GetMemoryOffset() + (uint32_t)(a)))

static int log_on(void)
{
    static int on = -1;
    if (on < 0) on = getenv("TT_GAMELOG") != NULL;
    return on;
}

static uint32_t fbits(float f) { uint32_t u; memcpy(&u, &f, 4); return u; }

/* ===================================================================== */
/* the roster                                                             */
/* ===================================================================== */
/* guest skeleton bone -> Aragorn/Isildur skeleton bone (51 bones), made by
 * tools/rig/chain.py: limbs matched along their chains, the rest following
 * the nearest limb bone above them, or the spine/head by height */
static const uint8_t s_map_boromir[50] = { 2, 2, 2, 2, 5, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 12, 13, 14, 9, 10, 11, 15, 16, 16, 16, 21, 22, 24, 25, 24, 24, 24, 28, 30, 31, 33, 34, 33, 33, 33, 37, 40, 40, 40, 40, 40, 40, 40 };
static const uint8_t s_map_gandalf[66] = { 2, 2, 2, 2, 2, 2, 2, 2, 4, 5, 2, 2, 2, 2, 9, 10, 9, 9, 9, 9, 11, 12, 13, 12, 12, 12, 12, 14, 2, 15, 2, 2, 16, 16, 16, 21, 22, 21, 24, 22, 22, 25, 24, 24, 24, 28, 30, 31, 30, 33, 31, 31, 34, 33, 33, 33, 37, 39, 40, 39, 40, 39, 39, 39, 39, 40 };
/* Frodo onto Gimli's skeleton (43 bones; tools/rig/gimlimap.py): he plays
 * with Gimli's moves, which suit his height */
static const uint8_t s_map_frodo_g[58] = { 3, 3, 3, 3, 13, 14, 16, 16, 16, 13, 13, 13, 3, 3, 3, 13, 3, 3, 3, 13, 3, 3, 3, 17, 18, 19, 20, 19, 19, 19, 19, 20, 24, 25, 26, 27, 30, 27, 27, 27, 27, 30, 31, 33, 33, 33, 4, 5, 3, 3, 7, 8, 8, 9, 10, 11, 11, 12 };
static const uint8_t s_map_frodo[58] = { 2, 2, 2, 2, 15, 16, 16, 16, 15, 15, 15, 2, 2, 2, 2, 2, 2, 2, 2, 15, 2, 2, 2, 21, 22, 24, 25, 24, 24, 24, 24, 25, 28, 30, 31, 33, 34, 33, 33, 33, 33, 34, 37, 40, 40, 39, 4, 5, 2, 2, 9, 10, 10, 11, 12, 13, 13, 14 };
static const uint8_t s_map_lurtz[78] = { 2, 2, 2, 2, 4, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 9, 10, 11, 12, 13, 14, 15, 16, 16, 16, 21, 22, 24, 24, 24, 25, 24, 28, 24, 24, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 39, 39, 39, 39, 39, 39, 39, 39, 39, 30, 31, 33, 34, 33, 33, 33, 33, 33, 37 };

/* A guest's model is re-rigged onto the heroes' skeleton (Aragorn's, which
 * Isildur shares): the model's bone tables (per part, {skeleton bone, model
 * bone}) are pointed at the matching hero bones, so the guest moves with
 * the hero's own animations -- every move, the weapons in hand, the
 * character select's poses. */
typedef struct {
    const char *name;          /* lower case, file names */
    const char *title;         /* as the game shows it (7 letters at most) */
    const char *src;           /* level file that has the resources */
    uint32_t mesh, anim, tex;  /* anim: the guest's own (its skeleton) */
    const uint8_t *map; int nmap;   /* guest bone -> hero bone */
    /* his own weapon, in place of the hero's in that hand (script weapon
     * slot: 0 the bow's hand, 1 the sword's); 0 for none */
    const char *wsrc; uint32_t wmesh, wtex; int wslot;
    /* the level variant he plays (NULL Aragorn's .bfa; ".bfg" Gimli's,
     * moves and all) and his bones for that variant's skeleton */
    const char *lvar; const uint8_t *lmap; int nlmap;
    /* a second weapon of his own, for the sword's hand (slot 1) */
    const char *w2src; uint32_t w2mesh, w2tex;
    /* and a third, for another slot (Boromir's shield) */
    const char *xsrc; uint32_t xmesh, xtex; int xslot;
    /* nothing in the bow's hand (a prop with no triangles, EMPTY_PROP_KEY:
     * Gandalf shoots from his staff), and his shots a beam */
    int nobow, beam;
    int glow;   /* his sword-hand blade lit (Sting's pale blue: its texture tinted) */
} Skin;
#define EMPTY_PROP_KEY 0x6E0B0E00u
#define W(x) "\\Device\\CdRom0\\worlds\\" x
#define MAP(m) m, (int)sizeof m
static Skin s_skins[] = {
    /* Boromir: his sword, and his shield on his other arm (the bow's hand) */
    { "boromir", "Boromir", W("04BALIN1.bfa"), 0xA6841986u, 0xF9C62B16u, 0xFD8B0956u, MAP(s_map_boromir), NULL, 0, 0, 0,
      NULL, NULL, 0, W("04BALIN1.bfa"), 0xC0F2C17Cu, 0xB798D03Au },   /* his shield: part of his model (shield_mesh, made from the disc) --
      * a weapon in script slot 2 or 3 is drawn in cutscenes alone, and the bow's hand only while he shoots */
    /* Gandalf: his staff (as in Balin's Tomb) in his sword's hand at all
     * times, nothing in the bow's; his shots a beam from the staff */
    { "gandalf", "Gandalf", W("04BALIN1.bfa"), 0x3E74698Au, 0xDDAEA31Cu, 0xF2BE2DCCu, MAP(s_map_gandalf), W("04BALIN1.bfa"), 0x9556E30Cu, 0xE6C4CFA9u, 1,
      NULL, NULL, 0, NULL, 0, 0, NULL, 0, 0, 0, 1, 1 },
    /* Frodo: Sting (his own, Balin's Tomb) */
    { "frodo",   "Frodo",   W("04BALIN1.bfa"), 0xD7848F26u, 0x4346DB86u, 0xD4263554u, MAP(s_map_frodo), NULL, 0, 0, 0, ".bfg", MAP(s_map_frodo_g),
      W("04BALIN1.bfa"), 0x69DAC4B8u, 0xBD9E230Bu, NULL, 0, 0, 0, 0, 0, 1 },
    /* Lurtz: his own bow (the Amon Hen boss fight) */
    { "lurtz",   "Lurtz",   W("13AMON1.bfa"),  0x282C7492u, 0xBC42B3A8u, 0x2D8D24C0u, MAP(s_map_lurtz), W("13AMON1.bfa"), 0xFC3884ACu, 0xB5E9F80Au, 0,
      NULL, NULL, 0, W("13AMON1.bfa"), 0xF7C09988u, 0xA2399431u },   /* and his sword (the bow-to-sword cutscene's) */
    { "custom",  "Custom",  NULL, 0, 0, 0, NULL, 0, NULL, 0, 0, 0 },   /* testing: TT_PLAYAS=MESH,ANIM,TEX,LEVEL */
};
#define MENU_ANIM_KEY 1u
#define MENU_SWORD_KEY 2u      /* Aragorn's sword in the character select (types 1200/1250) */       /* the character select's Aragorn: the guests' moves there */
#define N_EXTRA 4              /* in the carousel */
#define N_SKINS ((int)(sizeof s_skins / sizeof s_skins[0]))
#define FE_KEY(g) (0x21u + (uint32_t)(g))   /* their models' keys in the menu file */
#define FE_WKEY(g) (0x31u + (uint32_t)(g))  /* their sword-hand weapons there (prop 1200, texture 1250) */
#define PROP_MAGIC 0x62787270u               /* "prxb" */
#define HERO_BYTE 0x4AB69Du
#define HEROES_BUILD 50u     /* bump when the level rebuild changes */

/* skin sk's own weapon for script weapon slot (0 bow's hand, 1 sword's), or 0 */
static int skin_weapon(int sk, int slot, const char **src, uint32_t *mesh, uint32_t *tex)
{
    if (sk < 0 || getenv("TT_NOWEAPON")) return 0;
    if (slot == 0 && s_skins[sk].nobow && s_skins[sk].wmesh && !getenv("TT_BOW")) { *src = s_skins[sk].wsrc; *mesh = EMPTY_PROP_KEY; *tex = s_skins[sk].wtex; return 1; }
    if (s_skins[sk].wmesh && (getenv("TT_WSLOT") ? atoi(getenv("TT_WSLOT")) : s_skins[sk].wslot) == slot) { *src = s_skins[sk].wsrc; *mesh = s_skins[sk].wmesh; *tex = s_skins[sk].wtex; return 1; }
    if (slot == 1 && getenv("TT_W2")) {   /* testing: LEVEL,MESH,TEX */
        static char lv[64], path[128]; static uint32_t m2, t2;
        if (!m2) { sscanf(getenv("TT_W2"), "%63[^,],%x,%x", lv, &m2, &t2); snprintf(path, sizeof path, "\\Device\\CdRom0\\worlds\\%s", lv); }
        *src = path; *mesh = m2; *tex = t2; return 1;
    }
    if (s_skins[sk].w2mesh && slot == 1) { *src = s_skins[sk].w2src; *mesh = s_skins[sk].w2mesh; *tex = s_skins[sk].w2tex; return 1; }
    return 0;
}
/* a weapon's second texture (the weapon op looks up two for some: Sting's
 * glow, as Frodo carries it in Balin's Tomb), or 0 */
static uint32_t weapon_tex2(uint32_t mesh) { return mesh == 0x69DAC4B8u ? 0xDB3B3452u : 0; }
static char s_ini[600], s_dir[600];
static int s_on = -1;
static int s_test_unlock;   /* [Mods] extra_heroes=2 */
static int s_guest = -1;       /* the extra hero hero 4 is, or -1 (Isildur) */
static int s_playas = -2;      /* testing: TT_PLAYAS skins hero 1 */
static char s_custom_src[96];

static void paths(void)
{
    char *sl;
    if (s_dir[0]) return;
    GetModuleFileNameA(NULL, s_dir, sizeof s_dir);
    sl = strrchr(s_dir, '\\'); if (!sl) sl = strrchr(s_dir, '/');
    if (sl) *sl = 0;
    snprintf(s_ini, sizeof s_ini, "%s/twotowers_recomp.ini", s_dir);
}

int tt_heroes_on(void)
{
    if (s_on < 0) {
        const char *e = getenv("TT_HEROES");
        paths();
        s_on = GetPrivateProfileIntA("Mods", "extra_heroes", 0, s_ini);
        if (e) s_on = atoi(e);
        /* 2: unlocked for testing (only in memory; the save is not changed) */
        if (s_on == 2 || getenv("TT_HEROES_UNLOCK")) s_test_unlock = 1;
        s_on = s_on != 0;
        tt_dbg("[HEROES] extra heroes %s\n", s_on ? "on" : "off");
    }
    return s_on;
}

static int skin_by_name(const char *e)
{
    int i;
    for (i = 0; e && i < N_SKINS; i++)
        if (!_stricmp(e, s_skins[i].name)) return i;
    return -1;
}
static int playas(void)
{
    if (s_playas == -2) {
        const char *e = getenv("TT_PLAYAS");
        unsigned m, a, t;
        char lv[32];
        if (e && sscanf(e, "%x,%x,%x,%31s", &m, &a, &t, lv) == 4) {
            Skin *c = &s_skins[N_SKINS - 1];
            c->mesh = m; c->anim = a; c->tex = t;
            snprintf(s_custom_src, sizeof s_custom_src, "\\Device\\CdRom0\\worlds\\%s", lv);
            c->src = s_custom_src;
            s_playas = N_SKINS - 1;
            tt_dbg("[HEROES] testing: playing as %08X %08X %08X from %s\n", m, a, t, s_custom_src);
        } else s_playas = skin_by_name(e);
    }
    return s_playas;
}
/* the skin of the hero being played, or -1 */
static int active_skin(void)
{
    if (G8(HERO_BYTE) == 4 && s_guest >= 0) return s_guest;
    if (G8(HERO_BYTE) == 1 && playas() >= 0) return s_playas;
    return -1;
}

/* Isildur (and with him the extra heroes) unlocked: the final mission
 * (level 11) and the secret one (13) done, by any hero -- the game's own
 * test (0x00073960 and the checks around it) */
static int unlocked(void)
{
    int h, a = 0, b = 0;
    if (tt_heroes_on() && s_test_unlock) return 1;
    for (h = 1; h <= 3; h++) {
        if (G8(0x4AB68Fu + h * 15 + 0xB) == 1) a = 1;
        if (G8(0x4AB68Fu + h * 15 + 0xD) == 1) b = 1;
    }
    return a && b;
}

/* ===================================================================== */
/* files                                                                  */
/* ===================================================================== */
#include "../../xboxrecomp-0.12.0/src/kernel/kernel.h"
extern const char *(*xbox_path_redirect)(const char *xbox_path);

static unsigned char *read_all(const char *path, size_t *n)
{
    FILE *f = fopen(path, "rb");
    unsigned char *b;
    long sz;
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); sz = ftell(f); fseek(f, 0, SEEK_SET);
    b = (unsigned char *)malloc((size_t)sz + 1);
    if (b && fread(b, 1, (size_t)sz, f) != (size_t)sz) { free(b); b = NULL; }
    fclose(f);
    if (b) *n = (size_t)sz;
    return b;
}
static uint32_t rd32(const unsigned char *b, size_t o) { return (uint32_t)b[o] | (uint32_t)b[o + 1] << 8 | (uint32_t)b[o + 2] << 16 | (uint32_t)b[o + 3] << 24; }
static uint32_t rd16(const unsigned char *b, size_t o) { return (uint32_t)b[o] | (uint32_t)b[o + 1] << 8; }
static void wr16(unsigned char *b, size_t o, uint16_t v) { b[o] = (unsigned char)v; b[o + 1] = (unsigned char)(v >> 8); }
static void wr32(unsigned char *b, size_t o, uint32_t v) { b[o] = (unsigned char)v; b[o + 1] = (unsigned char)(v >> 8); b[o + 2] = (unsigned char)(v >> 16); b[o + 3] = (unsigned char)(v >> 24); }

/* the host path of an Xbox path, as the game would open it */
static int host_path(const char *xpath, char *out, size_t n)
{
    xbox_host_char h[600];
    const char *(*save)(const char *) = xbox_path_redirect;
    BOOL ok;
    xbox_path_redirect = NULL;
    ok = xbox_translate_path(xpath, h, 600);
    xbox_path_redirect = save;
    if (!ok) return 0;
#ifdef _WIN32
    WideCharToMultiByte(CP_UTF8, 0, h, -1, out, (int)n, NULL, NULL);
#else
    snprintf(out, n, "%s", h);
#endif
    return 1;
}

/* level/UI file: [0] version 9, [4] n = offset of the directory; at n:
 * u32 count, then count x {type, offset, key} -- file offsets */
static int res_find(const unsigned char *b, size_t len, uint32_t key, int type, uint32_t *off, uint32_t *end, uint32_t *typ)
{
    uint32_t n = rd32(b, 4), cnt, i, best;
    int found = 0;
    if (n + 4 > len) return 0;
    cnt = rd32(b, n);
    if (n + 4 + (size_t)cnt * 12 > len) return 0;
    best = n;
    for (i = 0; i < cnt; i++)
        if (rd32(b, n + 4 + 12 * i + 8) == key && (type < 0 || rd32(b, n + 4 + 12 * i) == (uint32_t)type)) {
            *typ = rd32(b, n + 4 + 12 * i); *off = rd32(b, n + 4 + 12 * i + 4); found = 1;
        }
    if (!found) return 0;
    for (i = 0; i < cnt; i++) {
        uint32_t o = rd32(b, n + 4 + 12 * i + 4);
        if (o > *off && o < best) best = o;
    }
    *end = best;
    return 1;
}

/* copy resource src_key of level file src (an Xbox path) in as {type, key} */
typedef struct { const char *src; uint32_t src_key; uint32_t type, key; const uint8_t *map; int nmap; int compose; int empty; int tint; } Add;

/* After re-rigging, several of a part's bone slots hold the same hero
 * bone. The part's vertices (48 bytes: position, normal, uv, then two
 * {slot * 3, weight} floats; the first at +4 from the part's vertex offset
 * [part+8], [part+0] of them) are pointed at the first slot of each bone,
 * and the duplicates load the same matrix into that slot -- so the model
 * uses only as many of the GPU's matrix constants as it has distinct bones
 * (Gandalf's 56 slots spilled into constants Fangorn's scenery uses). */
/* The unused index of single-bone vertices holds leftovers from the
 * exporter (or the slot from before merging): made the vertex's own other
 * index, so no address the vertex program forms can reach past the palette. */
static void sanitize_zero_w(unsigned char *m, uint32_t vo, uint32_t vc)
{
    uint32_t i;
    for (i = 0; i < vc; i++) {
        float f0, w0, f1, w1, z = 0;
        unsigned char *v = m + vo + 4 + i * 48 + 32;
        memcpy(&f0, v, 4); memcpy(&w0, v + 4, 4); memcpy(&f1, v + 8, 4); memcpy(&w1, v + 12, 4);
        if (w1 <= 0 && w0 > 0) { memcpy(v + 8, &f0, 4); memcpy(v + 12, &z, 4); }
        else if (w0 <= 0 && w1 > 0) { memcpy(v, &f1, 4); memcpy(v + 4, &z, 4); }
        else if (w0 <= 0 && w1 <= 0) { memcpy(v, &z, 4); memcpy(v + 8, &z, 4); }
    }
}

/* The parts share one vertex stream (the first part's): each vertex's
 * palette indices are into the table of the part whose indices use it
 * (own[v], from the parts' strips). */
static uint32_t merge_slots(unsigned char *m, size_t len, uint32_t p, uint32_t c,
                            uint32_t vo, uint32_t vc, const unsigned char *own, unsigned part, uint32_t reserve)
{
    uint32_t i, k, used = reserve;
    unsigned char first[256], newi[256];
    if (c == 0 || c > 255 || vo + 4 + (size_t)vc * 48 > len) return c;
    /* only for the layout described: every weighted index a slot * 3 */
    for (i = 0; i < vc; i++) {
        if (own[i] != part) continue;
        for (k = 0; k < 2; k++) {
            float f, w;
            memcpy(&f, m + vo + 4 + i * 48 + 32 + 8 * k, 4);
            memcpy(&w, m + vo + 4 + i * 48 + 36 + 8 * k, 4);
            if (w > 0 && (f < 0 || f != (float)(int)f || (int)f % 3 || (uint32_t)f / 3 >= c)) return c;
        }
    }
    memset(first, 0xFF, sizeof first);
    for (i = 0; i < c; i++) {
        unsigned char b = m[p + 0x24 + 2 * i];
        if (first[b] == 0xFF) first[b] = (unsigned char)used++;
        newi[i] = first[b];
    }
    if (used >= c) {   /* nothing to gain: as it is */
        for (i = 0; i < vc; i++) if (own[i] == part) sanitize_zero_w(m, vo + i * 48, 1);
        return c;
    }
    for (i = 0; i < vc; i++) {
        if (own[i] != part) continue;
        for (k = 0; k < 2; k++) {
            float f, w;
            memcpy(&f, m + vo + 4 + i * 48 + 32 + 8 * k, 4);
            memcpy(&w, m + vo + 4 + i * 48 + 36 + 8 * k, 4);
            if (w > 0) { f = (float)(newi[(uint32_t)f / 3] * 3); memcpy(m + vo + 4 + i * 48 + 32 + 8 * k, &f, 4); }
        }
        sanitize_zero_w(m, vo + i * 48, 1);
    }
    /* the table itself: one entry per bone (the game's reflection pass, at
     * least, will not draw a model of more than some 50 slots) */
    {
        unsigned char tab[512];
        uint32_t u = 0;
        /* the first slots stay for the later parts: their own (shorter)
         * palettes are loaded over these, while their strips also use the
         * first part's (the hat's tip on Gandalf's second part) */
        for (; u < reserve; u++) { tab[2 * u] = m[p + 0x24]; tab[2 * u + 1] = (unsigned char)u; }
        for (i = 0; i < c; i++)
            if (newi[i] == u) { tab[2 * u] = m[p + 0x24 + 2 * i]; tab[2 * u + 1] = (unsigned char)u; u++; }
        memcpy(m + p + 0x24, tab, 2 * used);
    }
    tt_dbg("[HEROES]   part %u: %u bone slots merged into %u\n", part, c, used);
    return used;
}

/* a model's bone tables: [0x2C] parts; from 0x30 each part has 0x20 bytes,
 * u32 count, count x {skeleton bone, model bone}, padded to 4 */
static int s_native;   /* the level's guest is on his own skeleton */
static uint8_t s_idmap[256];   /* the identity: a guest on his own bones */
static int s_remap_noshadow;   /* set by the caller: blank the shadow data anyway */
static void remap_bones(unsigned char *m, size_t len, const uint8_t *map, int nmap)
{
    uint32_t parts, p = 0x30, k, i, c, n = 0;
    if (len < 0x60 || memcmp(m, " XBG", 4)) return;
    if (getenv("TT_MSCALE")) {   /* testing: scale part 1's positions */
        float sc = (float)atof(getenv("TT_MSCALE"));
        uint32_t pp = 0x30, vc = rd32(m, pp), vo = rd32(m, pp + 8), j, a;
        for (j = 0; j < vc && vo + 4 + j * 48 + 12 <= len; j++)
            for (a = 0; a < 3; a++) { float f; memcpy(&f, m + vo + 4 + j * 48 + 4 * a, 4); f *= sc; memcpy(m + vo + 4 + j * 48 + 4 * a, &f, 4); }
    }
    if (getenv("TT_MFLAG")) wr32(m, 0x14, (uint32_t)atoi(getenv("TT_MFLAG")));   /* testing */
    parts = rd32(m, 0x2C);
    if (getenv("TT_ONEPART") && parts > 1) { wr32(m, 0x2C, 1); parts = 1; }   /* testing */
    {
        /* the parts' headers and tables are packed one after the other:
         * rebuilt into a copy, shorter where slots merged */
        unsigned char out[0x2000];
        uint32_t q = 0, start = p, end;
        /* the vertices (48 bytes each, shared by the parts) start 0x34 bytes
         * after a part's vertex offset, the strip indices 0x4C after its
         * index offset (the push-buffer objects' headers come first) */
        uint32_t vc0 = rd32(m, 0x30), vo0 = rd32(m, 0x38) + 0x30;
        unsigned char *own = (unsigned char *)calloc(vc0 ? vc0 : 1, 1);
        if (!own) return;
        memset(own, 0xFF, vc0);
        /* every vertex's palette indices are into the first part's table
         * (the second part's strips use the same vertices and numbering) */
        memset(own, 0, vc0);
        for (k = 0; k < parts && k < 16; k++) {
            uint32_t nc;
            c = rd32(m, p + 0x20);
            if (c > 255 || p + 0x24 + 2 * c > len) { free(own); return; }
            for (i = 0; i < c; i++) {
                unsigned char *b = m + p + 0x24 + 2 * i;
                if (*b < nmap) { *b = map[*b]; n++; }
                if (getenv("TT_BONEKEEP")) {   /* testing: hero bones not listed become the pelvis (2) */
                    char t[8]; snprintf(t, sizeof t, ",%d,", *b);
                    if (!strstr(getenv("TT_BONEKEEP"), t)) *b = 2;
                }
                if (getenv("TT_BONEX")) {   /* testing: TT_BONEX=from,to */
                    int f0 = -1, t0 = -1; sscanf(getenv("TT_BONEX"), "%d,%d", &f0, &t0);
                    if (*b == f0) *b = (unsigned char)t0;
                }
            }
            {   /* the later parts' palette sizes */
                uint32_t pp = (p + 0x24 + 2 * c + 3) & ~3u, kk, rsv = 0;
                for (kk = k + 1; kk < parts && kk < 16; kk++) {
                    uint32_t cc = rd32(m, pp + 0x20);
                    if (cc > 255) break;
                    if (cc > rsv) rsv = cc;
                    pp = (pp + 0x24 + 2 * cc + 3) & ~3u;
                }
                /* a model of several parts keeps its palette as it is: the
                 * later parts' strips use the first part's slots as they
                 * stand (Gandalf's hat tip) */
                nc = (getenv("TT_NOMERGE") || (parts > 1 && !getenv("TT_MERGE2"))) ? c : merge_slots(m, len, p, c, vo0, vc0, own, k, 0);
                if (nc == c) {   /* the unused second index made safe all the same */
                    uint32_t j;
                    if (k == 0) for (j = 0; j < vc0; j++) sanitize_zero_w(m, vo0 + j * 48, 1);
                }
                (void)rsv;
            }
            if (q + 0x24 + 2 * nc + 4 > sizeof out) { free(own); return; }
            memcpy(out + q, m + p, 0x24 + 2 * nc);
            wr32(out, q + 0x20, nc);
            q = (q + 0x24 + 2 * nc + 3) & ~3u;
            p = (p + 0x24 + 2 * c + 3) & ~3u;
        }
        end = p;
        free(own);
        if (q < end - start) {
            memset(out + q, 0, end - start - q);
            memcpy(m + start, out, end - start);
        }
        /* What follows the tables (up to the first part's indices) is the
         * shadow volume's data, laid out by the model's own skeleton: with
         * a skeleton much unlike the hero's (Gandalf, Lurtz: over 50 bones
         * in use) the volumes come out torn and the stencil shadow smears
         * wedges over the scene, so theirs is blanked (no stencil shadow). */
        if ((n > 50 && map != s_idmap) || s_remap_noshadow || getenv("TT_NOSHADOW")) {
            uint32_t io = rd32(m, 0x30 + 0x1C);
            if (io > end && io <= len) memset(m + end, 0, io - end);
        }
    }
    tt_dbg("[HEROES] model re-rigged: %u bone slots in %u part(s)\n", n, parts);
}

/* ===================================================================== */
/* the guest's own animations as the hero's moves                         */
/* ===================================================================== */
/* An animation set ("aniz"): +6 u16 slot count, +0xC size, +0x10 the slot
 * table (u32 record offsets, 0 none); the skeleton ("hier", with its
 * "skel" chunk of attach points and hit volumes) from +0x40 to the first
 * record. A record ("anim"): 16 header words -- [2] length in ms, [4]
 * flags, [5] size, [6] events, [7] the events (offsets from their start,
 * then each: u32 time in ms, ...), [8] the bones' table (u32 offsets of
 * their key data, which starts at +0x40), [9] a time or 0xFFFF, [10] the
 * tail (combo windows: [12] u16 time pairs from [13], then a block from
 * [14]) -- the hero's game logic runs on the events and the tail.
 *
 * The guest plays as himself, on his own skeleton: a set with his
 * skeleton whose every slot the hero has holds one of the guest's own
 * motions, with the hero's events and tail for that slot (their times
 * scaled to the guest's motion). Which motion: his own for that slot, else
 * one from his attacks for the hero's (speed, fierce, ranged, ...). */
enum { AC_IDLE, AC_MOVE, AC_SPEED, AC_FIERCE, AC_PARRY, AC_RANGED, AC_HIT, AC_KNOCK, AC_DEATH, AC_KICK, AC_N };
static int anim_class(int s)
{
    switch (s) {
    case 152: case 153: case 154: case 155: case 196: case 197: case 41: case 42: case 44: case 47:
    case 57: case 59: case 191: case 193: case 81: case 82: case 83: case 86: case 87: case 88: case 90:
        return AC_SPEED;
    case 45: case 46: case 43: case 48: case 54: case 58: case 60: case 104: case 194: case 133: case 134:
        return AC_FIERCE;
    case 50: case 105: return AC_KICK;
    case 55: case 56: return AC_PARRY;
    case 40: case 144: case 145: case 146: case 147: case 148: case 149: return AC_RANGED;
    case 20: case 21: return AC_HIT;
    case 27: case 28: case 29: case 30: return AC_KNOCK;
    case 24: return AC_DEATH;
    case 2: case 3: case 4: case 5: case 9: case 10: case 11: case 15: return AC_MOVE;
    default: return AC_IDLE;
    }
}
/* per guest: the motions for each kind, comma lists of his slots
 * (TT_ANIMS_<name>=speed:41,42;fierce:43 overrides, for testing) */
/* rtscale: his attacks (speed, fierce, kick, ranged) are the hero's own,
 * retargeted onto his skeleton (retarget_rec), the root's moves scaled by
 * it -- Boromir's and Frodo's own swings looked like falling back; the lunges kept the hero's full length, so heavy blows reach as his do */
typedef struct { const char *name; const char *pools[AC_N]; float rtscale; const char *rtcls; } AnimPools;
/* rtcls: which kinds are the hero's (s speed, f fierce, k kick, r ranged);
 * Gandalf and Lurtz keep their own swings */
static const AnimPools s_pools[] = {
    /*                idle  move  speed            fierce        parry  ranged  hit   knock death kick */
    { "boromir", { "0", "9", "69,41,20",          "43,41",      "21",  "21",   "20", "27", "30", "69" }, 1.0f, "sfkr" },
    { "gandalf", { "0", "9", "41,43,55",          "57,55",      "56",  "35",   "20", "27", "30", "43" }, 0, "" },
    { "frodo",   { "0", "9", "173,175,21",        "43,41",      "176", "20",   "20", "27", "30", "175" }, 1.0f, "sfkr" },
    { "lurtz",   { "0", "9", "42,45,104,138,41",  "43,69,74,189", "111", "187", "20", "25", "24", "188" }, 0, "" },
};
static int pool_pick(const char *list, int n, const uint32_t *gtab, uint32_t gns)
{
    int v[32], c = 0;
    const char *p = list;
    while (p && *p && c < 32) {
        int x = atoi(p);
        if (x >= 0 && (uint32_t)x < gns && gtab[x]) v[c++] = x;
        p = strchr(p, ','); if (p) p++;
    }
    return c ? v[n % c] : -1;
}
static const char *pool_list(int g, int cls)
{
    static char buf[AC_N][128];
    static const char *key[AC_N] = { "idle", "move", "speed", "fierce", "parry", "ranged", "hit", "knock", "death", "kick" };
    char ev[64];
    const char *e, *q;
    snprintf(ev, sizeof ev, "TT_ANIMS_%s", s_pools[g].name);
    if ((e = getenv(ev)) && (q = strstr(e, key[cls])) && q[strlen(key[cls])] == ':') {
        size_t i;
        q += strlen(key[cls]) + 1;
        for (i = 0; i < sizeof buf[cls] - 1 && q[i] && q[i] != ';'; i++) buf[cls][i] = q[i];
        buf[cls][i] = 0;
        return buf[cls];
    }
    return s_pools[g].pools[cls];
}
static uint32_t s_cyc[64][3], s_ncyc, s_comp_size;
static int s_compose_menu;
static int s_fe_native;   /* the character select's guests on their own skeletons */
static const char *s_menu_moves[N_EXTRA][3] = {   /* stance, chosen pose, confirm */
    { "34,33", "27,41", "43,41" },          /* boromir */
    { "34,33", "36,35", "35,57" },          /* gandalf */
    { "34,33", "2,1", "41,43" },            /* frodo: looking about (30 was his fall), his blade raised */
    { "34,33", "187,113", "43,69" },        /* lurtz */
};
/* the composed set's settings, for the cache name */
static uint32_t anims_hash(int g)
{
    char ev[64]; const char *e; uint32_t h = 0;
    if (g < 0 || g >= N_EXTRA) return 0;
    snprintf(ev, sizeof ev, "TT_ANIMS_%s", s_pools[g].name);
    for (e = getenv(ev); e && *e; e++) h = h * 31u + (unsigned char)*e;
    if (getenv("TT_ANIMCYCLE") || getenv("TT_CYCSLOTS")) h ^= GetTickCount();
    {   /* his ready motions (heroes\<name>\anim_<slot>.bin): sizes and times */
        char pth[700]; int s; struct stat fa;
        paths();
        for (s = 0; s < 256; s++) {
            snprintf(pth, sizeof pth, "%s/heroes/%s/anim_%d.bin", s_dir, s_pools[g].name, s);
            if (!stat(pth, &fa))
                h = h * 31u + (uint32_t)s * 7919u + (uint32_t)fa.st_size + (uint32_t)fa.st_mtime;
        }
    }
    if (getenv("TT_XSLOT")) h += 101u * (uint32_t)atoi(getenv("TT_XSLOT"));
    if (getenv("TT_SHBONE")) h += 107u * (uint32_t)atoi(getenv("TT_SHBONE"));
    if (getenv("TT_SHSKIN")) h += 109u * (uint32_t)atoi(getenv("TT_SHSKIN"));
    if (getenv("TT_XENT")) h += 103u * (uint32_t)atoi(getenv("TT_XENT"));
    if (getenv("TT_NOHITBONE")) h += 0x5151u;
    { const char *rc = getenv("TT_RTCLASSES"); for (; rc && *rc; rc++) h = h * 37u + (unsigned char)*rc; }
    if (getenv("TT_RT_NOROOT")) h += 0x2929u;
    if (getenv("TT_NORETARGET")) h += 0x7373u;
    if (getenv("TT_RT_NOHAND")) h += 0x4141u;
    if (getenv("TT_RT_OLDMAP")) h += 0x3131u;
    if (getenv("TT_NOAIM2")) h += 0x3737u;
    { const char *ry = getenv("TT_RTYAW"); for (; ry && *ry; ry++) h = h * 41u + (unsigned char)*ry; }
    if (getenv("TT_RTNOTURN")) h += 0x5353u;
    if (getenv("TT_NOAIM")) h += 0x3939u;
    { const char *w2 = getenv("TT_W2"); for (; w2 && *w2; w2++) h = h * 41u + (unsigned char)*w2; }
    if (getenv("TT_HITBONE")) h += 113u * (uint32_t)atoi(getenv("TT_HITBONE"));
    return h;
}
/* ---- retargeting: the hero's motion onto a guest's skeleton ----
 * Quaternions (w,x,y,z). A set's skeleton ("hier" at +0x40): bone count
 * +8, 128-byte matrices at +0xC (the second 4x4, row vectors: the bind
 * pose's world transform), parents (+1) at +0x10. A record's rotation keys
 * {u16 time, 3 x i16 = x,y,z * 32767} turn the bind's local rotation:
 * local = bind_local * key. Each guest bone takes the world turn of the
 * hero bone it maps to (s_map_<name>): world = turn * own bind world. */
typedef struct { float w, x, y, z; } Quat;
static Quat qmulq(Quat a, Quat b)
{
    Quat r = { a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z, a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
               a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x, a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w };
    return r;
}
static Quat qconj(Quat a) { Quat r = { a.w, -a.x, -a.y, -a.z }; return r; }
static Quat qnormq(Quat a)
{
    float n = sqrtf(a.w * a.w + a.x * a.x + a.y * a.y + a.z * a.z);
    if (n > 0) { a.w /= n; a.x /= n; a.y /= n; a.z /= n; }
    return a;
}
static void qrotv(Quat q, const float *v, float *r)
{
    Quat p = { 0, v[0], v[1], v[2] }, t = qmulq(qmulq(q, p), qconj(q));
    r[0] = t.x; r[1] = t.y; r[2] = t.z;
}
/* the bind pose's world rotations and local ones */
static int rt_binds(const unsigned char *S, size_t len, int *par, Quat *W, Quat *BL)
{
    uint32_t h = 0x40, nb = rd32(S, h + 8), mo = h + rd32(S, h + 0xC), po = h + rd32(S, h + 0x10), i;
    if (nb == 0 || nb > 128 || mo + nb * 128 > len || po + nb > len) return 0;
    for (i = 0; i < nb; i++) {
        float m[3][3], t, sq;   /* m = R transposed (column convention) */
        int r, c;
        Quat q;
        for (r = 0; r < 3; r++) for (c = 0; c < 3; c++) { uint32_t v = rd32(S, mo + i * 128 + 64 + (uint32_t)(r * 4 + c) * 4); memcpy(&m[c][r], &v, 4); }
        t = m[0][0] + m[1][1] + m[2][2];
        if (t > 0) { sq = sqrtf(t + 1) * 2; q.w = sq / 4; q.x = (m[2][1] - m[1][2]) / sq; q.y = (m[0][2] - m[2][0]) / sq; q.z = (m[1][0] - m[0][1]) / sq; }
        else if (m[0][0] > m[1][1] && m[0][0] > m[2][2]) { sq = sqrtf(1 + m[0][0] - m[1][1] - m[2][2]) * 2; q.w = (m[2][1] - m[1][2]) / sq; q.x = sq / 4; q.y = (m[0][1] + m[1][0]) / sq; q.z = (m[0][2] + m[2][0]) / sq; }
        else if (m[1][1] > m[2][2]) { sq = sqrtf(1 + m[1][1] - m[0][0] - m[2][2]) * 2; q.w = (m[0][2] - m[2][0]) / sq; q.x = (m[0][1] + m[1][0]) / sq; q.y = sq / 4; q.z = (m[1][2] + m[2][1]) / sq; }
        else { sq = sqrtf(1 + m[2][2] - m[0][0] - m[1][1]) * 2; q.w = (m[1][0] - m[0][1]) / sq; q.x = (m[0][2] + m[2][0]) / sq; q.y = (m[1][2] + m[2][1]) / sq; q.z = sq / 4; }
        if (q.w < 0) { q.w = -q.w; q.x = -q.x; q.y = -q.y; q.z = -q.z; }
        W[i] = q;
        par[i] = (int)S[po + i] - 1;
    }
    for (i = 0; i < nb; i++) BL[i] = par[i] < 0 || par[i] >= (int)nb ? W[i] : qnormq(qmulq(qconj(W[par[i]]), W[i]));
    return (int)nb;
}
/* a key list's value at time t (linear in the stored x, y, z) */
static int rt_sample(const unsigned char *k, int n, float t, float *v)
{
    int i;
    if (n <= 0) return 0;
    if (t <= rd16(k, 0)) { for (i = 0; i < 3; i++) v[i] = (float)(int16_t)rd16(k, 2 + 2 * i); return 1; }
    for (i = 0; i + 1 < n; i++) {
        float t0 = rd16(k, 8 * i), t1 = rd16(k, 8 * (i + 1));
        if (t0 <= t && t <= t1) {
            float f = t1 > t0 ? (t - t0) / (t1 - t0) : 0; int c;
            for (c = 0; c < 3; c++) { float a = (float)(int16_t)rd16(k, 8 * i + 2 + 2 * c), b = (float)(int16_t)rd16(k, 8 * (i + 1) + 2 + 2 * c); v[c] = a + (b - a) * f; }
            return 1;
        }
    }
    for (i = 0; i < 3; i++) v[i] = (float)(int16_t)rd16(k, 8 * (n - 1) + 2 + 2 * i);
    return 1;
}
/* the rig map (guest bone -> hero bone), put right where it skips a joint
 * the hero has: see retarget_rec */
static void rig_map_fix(const int *hpar, int hn, const int *gpar, int gn, const uint8_t *map, int nmap, int *rm)
{
    int b;
    for (b = 0; b < gn; b++) {
        int h = b < nmap ? map[b] : 0, c;
        if (h >= hn) h = 0;
        rm[b] = h;
        if (getenv("TT_RT_OLDMAP")) continue;
        if (b <= 1 && b < hn && gpar[b] == hpar[b]) { rm[b] = b; continue; }
        if (gpar[b] < 0) continue;
        for (c = b + 1; c < gn; c++) {
            int hc, cand;
            if (gpar[c] != b) continue;
            hc = c < nmap ? map[c] : 0;
            if (hc >= hn) continue;
            cand = hpar[hc];
            if (cand >= 0 && cand < hn && hpar[cand] == rm[gpar[b]] && cand != rm[b]) { rm[b] = cand; break; }
        }
    }
}
/* hero slot hs of set A as a record for guest set G (bones mapped by map);
 * malloc'd, its size in *len */
static uint32_t skel_point_bone(const unsigned char *S, size_t len, int k);
static unsigned char *retarget_rec(const unsigned char *A, size_t alen, uint32_t hs, const unsigned char *G, size_t glen,
                                   const uint8_t *map, int nmap, float scale, size_t *len)
{
    static int hpar[128], gpar[128];
    static Quat hW[128], hBL[128], gW[128], gBL[128], Q[128], Wg[128];
    static int16_t keys[128][96][3];
    int hn = rt_binds(A, alen, hpar, hW, hBL), gn = rt_binds(G, glen, gpar, gW, gBL), b, nt, i;
    uint32_t atab = rd32(A, 0x10), rec, dur, bt, gtab = rd32(G, 0x10), donor;
    const unsigned char *hb[128];
    int hnr[128], hnp[128];
    unsigned char *o; size_t p;
    uint32_t offs[128];
    uint32_t hp[2], gp[2];
    int rm[128];
    Quat turn = { 1, 0, 0, 0 };
    if (!hn || !gn || hs >= rd16(A, 6) || !(rec = rd32(A, atab + 4 * hs)) || !(donor = rd32(G, gtab))) return NULL;
    /* the rig map, put right where it skips a joint the hero has: the
     * map gives his root, his root's child and his pelvis the hero's lower
     * spine (2), and his collarbones the hero's neck (16). His root (0) and
     * its child (1) take the hero's own -- the hero's root never turns (no
     * rotation keys: the game moves the actor by it), his child carries the
     * stance's turn -- and a bone between two mapped ones takes the hero's
     * bone between them (his pelvis the hero's, his collarbones the
     * hero's). World rotations are copied either way; what changes is where
     * his joints sit: his shoulders, so his hands and blade, his hips, so
     * his feet, are where the hero's are. */
    rig_map_fix(hpar, hn, gpar, gn, map, nmap, rm);
    hp[0] = skel_point_bone(A, alen, 0); hp[1] = skel_point_bone(A, alen, 1);
    gp[0] = skel_point_bone(G, glen, 0); gp[1] = skel_point_bone(G, glen, 1);
    dur = rd32(A, rec + 8); bt = rec + rd32(A, rec + 0x20);
    if (bt + 4u * (uint32_t)hn > alen || donor + 0x40 > glen) return NULL;
    for (b = 0; b < hn; b++) {
        uint32_t bo = rd32(A, bt + 4 * b);
        hb[b] = NULL; hnr[b] = hnp[b] = 0;
        if (bo && rec + bo + 4 <= alen) { hb[b] = A + rec + bo; hnr[b] = hb[b][0]; hnp[b] = hb[b][1]; }
    }
    nt = (int)(dur / 33) + 1; if (nt < 2) nt = 2; if (nt > 96) nt = 96;
    {   /* His melee moves turned back by the hero's stance (the turn his
         * root's child, bone 1, holds in his fighting stance: about 40
         * degrees for Aragorn's sword stance). On the hero the game allows
         * for it; on a guest it does not, and his blows went that far
         * beside the one he faced (measured in Hornburg Courtyard: his
         * blade's bearing at each hit test, his hits). */
        int cls = anim_class((int)hs);
        float an = 0;
        if (getenv("TT_RTYAW")) an = (float)atof(getenv("TT_RTYAW")) * 0.0174533f;   /* testing: this turn */
        else if ((cls == AC_SPEED || cls == AC_FIERCE || cls == AC_KICK) && hn > 1 && hpar[1] == 0 && !getenv("TT_RTNOTURN")) {
            /* the stance: his fighting stance's (slot 34), as it starts */
            uint32_t st = rd16(A, 6) > 34 ? rd32(A, atab + 4 * 34) : 0, sbt, sbo;
            Quat lq = hBL[1], d; float v[3], x[3] = { 1, 0, 0 }, r[3];
            if (st && (sbt = st + rd32(A, st + 0x20)) + 8 <= alen && (sbo = rd32(A, sbt + 4)) && st + sbo + 4 <= alen
                && rt_sample(A + st + sbo + 4, A[st + sbo], 0, v)) {
                float qx = v[0] / 32767.0f, qy = v[1] / 32767.0f, qz = v[2] / 32767.0f, ww = 1 - qx * qx - qy * qy - qz * qz;
                d.w = sqrtf(ww > 0 ? ww : 0); d.x = qx; d.y = qy; d.z = qz;
                lq = qmulq(lq, d);
            }
            if (hpar[0] < 0) lq = qmulq(hBL[0], lq);   /* (bone 0 carries no turn of its own) */
            qrotv(qmulq(lq, qconj(hW[1])), x, r);
            an = -atan2f(r[1], r[0]);
        }
        turn.w = cosf(an * 0.5f); turn.x = 0; turn.y = 0; turn.z = sinf(an * 0.5f);
        if (an != 0 && log_on()) tt_dbg("[HEROES]   slot %u: turned %.0f degrees\n", hs, an * 57.29578f);
    }
    for (i = 0; i < nt; i++) {
        float t = (float)dur * i / (nt - 1);
        for (b = 0; b < hn; b++) {   /* the hero's pose: world rotations */
            Quat lq = hBL[b]; float v[3];
            if (hb[b] && rt_sample(hb[b] + 4, hnr[b], t, v)) {
                Quat d; float x = v[0] / 32767.0f, y = v[1] / 32767.0f, z = v[2] / 32767.0f, ww = 1 - x * x - y * y - z * z;
                d.w = sqrtf(ww > 0 ? ww : 0); d.x = x; d.y = y; d.z = z;
                lq = qmulq(lq, d);
            }
            Q[b] = hpar[b] < 0 ? lq : qnormq(qmulq(Q[hpar[b]], lq));
        }
        for (b = 0; b < gn; b++) {
            int h = rm[b];
            /* his hands (the weapons' attach points) turn as the hero's
             * hands do, not as the bone the map gives them (Boromir's sword
             * hand maps to the hero's wrist): the blade then sweeps where
             * the hero's does, and the game's hit test (along the blade)
             * finds the enemies the hero's would */
            if (!getenv("TT_RT_NOHAND")) { if ((uint32_t)b == gp[0] && hp[0] < (uint32_t)hn) h = (int)hp[0]; else if ((uint32_t)b == gp[1] && hp[1] < (uint32_t)hn) h = (int)hp[1]; }
            if (h >= hn) h = 0;
            Wg[b] = qnormq(qmulq(qmulq(Q[h], qconj(hW[h])), gW[b]));
            if (b >= 1 && turn.w < 0.99999f) Wg[b] = qnormq(qmulq(turn, Wg[b]));
        }
        for (b = 0; b < gn; b++) {
            Quat L = gpar[b] < 0 ? Wg[b] : qmulq(qconj(Wg[gpar[b]]), Wg[b]), d = qnormq(qmulq(qconj(gBL[b]), L));
            if (d.w < 0) { d.w = -d.w; d.x = -d.x; d.y = -d.y; d.z = -d.z; }
            keys[b][i][0] = (int16_t)lroundf(d.x * 32767); keys[b][i][1] = (int16_t)lroundf(d.y * 32767); keys[b][i][2] = (int16_t)lroundf(d.z * 32767);
        }
    }
    o = (unsigned char *)calloc(1, 0x40 + (size_t)gn * (4 + 8 * (nt + 64)) + 4 * gn + 16);
    if (!o) return NULL;
    memcpy(o, G + donor, 0x40);
    p = 0x40;
    for (b = 0; b < gn; b++) {
        int nr = nt, np = 0, k, same = 1;
        const unsigned char *pk = NULL;
        for (k = 1; k < nt && same; k++)
            if (abs(keys[b][k][0] - keys[b][0][0]) >= 3 || abs(keys[b][k][1] - keys[b][0][1]) >= 3 || abs(keys[b][k][2] - keys[b][0][2]) >= 3) same = 0;
        if (same) nr = 1;
        if (b == 0 && rm[0] == 0 && (!hb[0] || !hnr[0]) && !getenv("TT_RT_OLDMAP")) nr = 0;   /* his root unturned, as the hero's */
        if (b <= 1 && b < hn && hb[b] && hnp[b] && hnp[b] <= 64 && !getenv("TT_RT_NOROOT")) { pk = hb[b] + 4 + 8 * hnr[b]; np = hnp[b]; }   /* the root's moves */
        offs[b] = (uint32_t)p;
        o[p] = (unsigned char)nr; o[p + 1] = (unsigned char)np; o[p + 2] = 0; o[p + 3] = 0; p += 4;
        for (k = 0; k < nr; k++) {
            wr16(o, p, (uint16_t)lroundf((float)dur * k / (nt - 1))); wr16(o, p + 2, (uint16_t)keys[b][k][0]); wr16(o, p + 4, (uint16_t)keys[b][k][1]); wr16(o, p + 6, (uint16_t)keys[b][k][2]); p += 8;
        }
        for (k = 0; k < np; k++) {
            int c;
            wr16(o, p, rd16(pk, 8 * k));
            for (c = 0; c < 3; c++) wr16(o, p + 2 + 2 * c, (uint16_t)(int16_t)lroundf((float)(int16_t)rd16(pk, 8 * k + 2 + 2 * c) * scale));
            p += 8;
        }
    }
    p = (p + 3) & ~(size_t)3;
    {
        size_t evo = p;
        for (b = 0; b < gn; b++) { wr32(o, p, offs[b]); p += 4; }
        wr32(o, 8, dur);
        wr32(o, 0x14, (uint32_t)p); wr32(o, 0x18, 0); wr32(o, 0x1C, (uint32_t)evo); wr32(o, 0x20, (uint32_t)evo);
        wr32(o, 0x24, 0xFFFF); wr32(o, 0x28, (uint32_t)p); wr32(o, 0x2C, 0);
        wr32(o, 0x30, 0); wr32(o, 0x34, 0); wr32(o, 0x38, 0);
    }
    *len = p;
    return o;
}
/* ---- a record's pose: the bones' positions (model space) at time t ----
 * local rotation = bind local * key; local offset = bind offset + position
 * key / 256 (as the game plays them) */
static int rt_pose(const unsigned char *S, size_t len, const unsigned char *rec, size_t rlen, float t, float (*P)[3])
{
    static int par[128]; static Quat W[128], BL[128], Q[128];
    static float BT[128][3], T[128][3];
    static const unsigned char *last; static size_t lastlen;
    int nb, b, c;
    uint32_t bt;
    if (S != last || len != lastlen) {   /* the skeleton's bind offsets, once per set */
        uint32_t mo;
        nb = rt_binds(S, len, par, W, BL);
        if (!nb) return 0;
        mo = 0x40 + rd32(S, 0x40 + 0xC);
        for (b = 0; b < nb; b++) for (c = 0; c < 3; c++) { uint32_t v = rd32(S, mo + (uint32_t)b * 128 + 64 + 48 + 4 * (uint32_t)c); memcpy(&T[b][c], &v, 4); }
        for (b = 0; b < nb; b++) {
            if (par[b] < 0) { for (c = 0; c < 3; c++) BT[b][c] = T[b][c]; continue; }
            { float d[3] = { T[b][0] - T[par[b]][0], T[b][1] - T[par[b]][1], T[b][2] - T[par[b]][2] }; qrotv(qconj(W[par[b]]), d, BT[b]); }
        }
        last = S; lastlen = len;
    }
    nb = (int)rd32(S, 0x40 + 8);
    if (nb <= 0 || nb > 128) return 0;
    bt = rd32(rec, 0x20);
    if (bt + 4u * (uint32_t)nb > rlen) return 0;
    for (b = 0; b < nb; b++) {
        uint32_t bo = rd32(rec, bt + 4 * (uint32_t)b);
        Quat lq = BL[b]; float lt[3] = { BT[b][0], BT[b][1], BT[b][2] }, v[3];
        if (bo && bo + 4 <= rlen) {
            int nr = rec[bo], np = rec[bo + 1];
            if (bo + 4 + 8u * (uint32_t)(nr + np) <= rlen) {
                if (rt_sample(rec + bo + 4, nr, t, v)) {
                    float x = v[0] / 32767.0f, y = v[1] / 32767.0f, z = v[2] / 32767.0f, ww = 1 - x * x - y * y - z * z;
                    Quat d = { sqrtf(ww > 0 ? ww : 0), x, y, z };
                    lq = qmulq(lq, d);
                }
                if (rt_sample(rec + bo + 4 + 8 * nr, np, t, v)) for (c = 0; c < 3; c++) lt[c] += v[c] / 256.0f;
            }
        }
        if (par[b] < 0 || par[b] >= nb) { Q[b] = lq; for (c = 0; c < 3; c++) P[b][c] = lt[c]; }
        else {
            float r[3];
            Q[b] = qnormq(qmulq(Q[par[b]], lq));
            qrotv(Q[par[b]], lt, r);
            for (c = 0; c < 3; c++) P[b][c] = P[par[b]][c] + r[c];
        }
    }
    return nb;
}
/* when a swing is at its fastest: the hand bone's speed relative to the
 * root, sampled every 33 ms; its time in ms, or -1 */
static int swing_peak(const unsigned char *S, size_t len, const unsigned char *rec, size_t rlen, int hand, uint32_t dur, float *speed)
{
    static float P[128][3], prev[3];
    float best = -1, t;
    if (speed) *speed = 0;
    if (hand < 0 || hand >= 128) return -1;
    int bt = -1, have = 0;
    for (t = 0; t <= (float)dur; t += 33.0f) {
        float h[3], sp;
        int c;
        if (rt_pose(S, len, rec, rlen, t, P) <= hand) return -1;
        for (c = 0; c < 3; c++) h[c] = P[hand][c] - P[0][c];
        if (have && t > dur * 0.12f && t < dur * 0.92f) {   /* (not the blends in and out) */
            sp = (h[0] - prev[0]) * (h[0] - prev[0]) + (h[1] - prev[1]) * (h[1] - prev[1]) + (h[2] - prev[2]) * (h[2] - prev[2]);
            if (sp > best) { best = sp; bt = (int)(t - 16.5f); }
        }
        for (c = 0; c < 3; c++) prev[c] = h[c];
        have = 1;
    }
    if (speed) *speed = best;
    return bt;
}
/* a foot's travel over a cycle (its longest extent in the ground plane):
 * a walk's or run's stride */
static float stride_len(const unsigned char *S, size_t len, const unsigned char *rec, size_t rlen, int foot, uint32_t dur)
{
    static float P[128][3];
    float lo[2] = { 1e9f, 1e9f }, hi[2] = { -1e9f, -1e9f }, t;
    int c;
    for (t = 0; t <= (float)dur; t += 33.0f) {
        if (rt_pose(S, len, rec, rlen, t, P) <= foot) return 0;
        for (c = 0; c < 2; c++) { float v = P[foot][c] - P[0][c]; if (v < lo[c]) lo[c] = v; if (v > hi[c]) hi[c] = v; }
    }
    return hi[0] - lo[0] > hi[1] - lo[1] ? hi[0] - lo[0] : hi[1] - lo[1];
}
/* a hero time (ms) in the composed move: scaled, or with the strike moved
 * (hero strike sh -> his sg; -1 none) */
static uint32_t strike_map(uint32_t t, float scale, int sh, int sg, uint32_t hdur, uint32_t target)
{
    float r;
    if (sh <= 0 || sg <= 0 || !hdur) return (uint32_t)(t * scale + 0.5f);
    if ((int)t <= sh) r = (float)t * (float)sg / (float)sh;
    else if (hdur > (uint32_t)sh) r = (float)sg + ((float)t - (float)sh) * ((float)target - (float)sg) / ((float)hdur - (float)sh);
    else r = (float)t * scale;
    return r < 0 ? 0u : (uint32_t)(r + 0.5f);
}
/* the first bone of a set's skeleton's attach point k ("skel" chunk:
 * offsets of bone lists {count, bones} from its table), or 0xFFFF */
static uint32_t skel_point_bone(const unsigned char *S, size_t len, int k)
{
    uint32_t gs = 0x40 + rd32(S, 0x40 + 0x14), t, o;
    if (gs + 0x40 > len || memcmp(S + gs, "skel", 4) || rd32(S, gs + 8) <= (uint32_t)k) return 0xFFFFu;
    t = gs + rd32(S, gs + 0xC);
    if (t + 4 * (uint32_t)k + 4 > len || !(o = rd32(S, t + 4 * (uint32_t)k)) || t + o + 8 > len || !rd32(S, t + o)) return 0xFFFFu;
    return rd32(S, t + o + 4);
}
/* a bone's place in the bind pose (set S) */
static void skel_bind_pos(const unsigned char *S, uint32_t b, float *p)
{
    uint32_t mo = 0x40 + rd32(S, 0x40 + 0xC) + b * 128 + 64 + 48, c;
    for (c = 0; c < 3; c++) { uint32_t v = rd32(S, mo + 4 * c); memcpy(&p[c], &v, 4); }
}
/* the guest's bone for the hero's bone h: the same attach point's, else the
 * nearest (in the bind pose, scaled to his height) of those the rig map
 * gives it, else the nearest of all */
static uint32_t guest_bone_for(const unsigned char *A, size_t alen, const unsigned char *G, size_t glen, int g, uint32_t h)
{
    static const int pts[] = { 0, 1, 2, 3, 4, 5, 8 };
    uint32_t nA = rd32(A, 0x40 + 8), nG = rd32(G, 0x40 + 8), b, best = 0, k;
    float hp[3], gp[3], hz = 0, gz = 0, sc, bd = 1e30f;
    int pass;
    static int hpar[128], gpar[128], rm[128]; static Quat W[128], BL[128];
    int hn = rt_binds(A, alen, hpar, W, BL), gn = rt_binds(G, glen, gpar, W, BL);
    if (g >= 0 && g < N_SKINS && s_skins[g].map && hn && gn) rig_map_fix(hpar, hn, gpar, gn, s_skins[g].map, s_skins[g].nmap, rm);
    else gn = 0;
    for (k = 0; k < sizeof pts / sizeof pts[0]; k++) {
        uint32_t hb = skel_point_bone(A, alen, pts[k]), gb = skel_point_bone(G, glen, pts[k]);
        if (hb == h && gb < nG) return gb;
    }
    if (h >= nA || !nG) return 0;
    for (b = 0; b < nA; b++) { skel_bind_pos(A, b, hp); if (hp[2] > hz) hz = hp[2]; }
    for (b = 0; b < nG; b++) { skel_bind_pos(G, b, gp); if (gp[2] > gz) gz = gp[2]; }
    sc = hz > 0 ? gz / hz : 1;
    skel_bind_pos(A, h, hp);
    for (k = 0; k < 3; k++) hp[k] *= sc;
    for (pass = 0; pass < 2 && bd >= 1e30f; pass++)
        for (b = 0; b < nG; b++) {
            float d;
            if (!pass && !((int)b < gn && rm[b] == (int)h)) continue;
            if (pass && b <= 1 && h > 1) continue;   /* (the root and its child sit where the pelvis does) */
            skel_bind_pos(G, b, gp);
            d = (gp[0] - hp[0]) * (gp[0] - hp[0]) + (gp[1] - hp[1]) * (gp[1] - hp[1]) + (gp[2] - hp[2]) * (gp[2] - hp[2]);
            if (d < bd) { bd = d; best = b; }
        }
    return best;
}
/* the composed set into out (cap bytes); its size, or 0 */
static size_t compose_anims(const unsigned char *A, size_t alen, const unsigned char *G, size_t glen, int g,
                            unsigned char *out, size_t cap)
{
    uint32_t ans = rd16(A, 6), gns = rd16(G, 6), atab = rd32(A, 0x10), gtab = rd32(G, 0x10), s, first = 0xFFFFFFFFu;
    uint32_t gt[256], at[256], nbG, pos, used[AC_N], hand[2], ghand[2], hfoot, gfoot;
    int sh, sg, sp;
    static unsigned char *ovr[256];
    if (memcmp(A, "aniz", 4) || memcmp(G, "aniz", 4) || ans > 256 || gns > 256 || atab + 4 * ans > alen || gtab + 4 * gns > glen) return 0;
    for (s = 0; s < gns; s++) { gt[s] = rd32(G, gtab + 4 * s); if (gt[s] && gt[s] < first) first = gt[s]; }
    for (s = 0; s < ans; s++) at[s] = rd32(A, atab + 4 * s);
    if (first == 0xFFFFFFFFu || first > glen || first > cap) return 0;
    nbG = rd32(G, 0x40 + 8);
    {   /* testing: heroes\<name>\anim_<slot>.bin -- a ready motion for a hero slot */
        char pth[700]; size_t l2;
        paths();
        for (s = 0; s < ans && s < 256; s++) {
            ovr[s] = NULL;
            snprintf(pth, sizeof pth, "%s/heroes/%s/anim_%u.bin", s_dir, s_pools[g].name, s);
            if ((ovr[s] = read_all(pth, &l2)) && (l2 < 0x40 || memcmp(ovr[s], "anim", 4))) { free(ovr[s]); ovr[s] = NULL; }
            if (!ovr[s] && s_pools[g].rtscale > 0 && !s_compose_menu && rd32(A, atab + 4 * s) && !getenv("TT_NORETARGET")) {
                int c = anim_class((int)s);
                const char *rc = getenv("TT_RTCLASSES") ? getenv("TT_RTCLASSES") : s_pools[g].rtcls;   /* testing: s f k r */
                if ((c == AC_SPEED && strchr(rc, 's')) || (c == AC_FIERCE && strchr(rc, 'f')) || (c == AC_KICK && strchr(rc, 'k')) || (c == AC_RANGED && strchr(rc, 'r'))) {
                    ovr[s] = retarget_rec(A, alen, s, G, glen, s_skins[g].map, s_skins[g].nmap, s_pools[g].rtscale, &l2);
                    if (!ovr[s]) tt_dbg("[HEROES]   slot %u: could not retarget\n", s);
                    else if (getenv("TT_RTDUMP")) {   /* testing */
                        FILE *df; snprintf(pth, sizeof pth, "%s/heroes/rt_%s_%u.bin", s_dir, s_pools[g].name, s);
                        if ((df = fopen(pth, "wb"))) { fwrite(ovr[s], 1, l2, df); fclose(df); }
                    }
                }
            }
        }
    }
    memcpy(out, G, first);           /* header and his skeleton */
    pos = first;
    {   /* The playable heroes' skeletons carry two more blocks in their
         * "skel" chunk (aiming limits: the bow's and the head's), the others
         * none -- without them the hero cannot aim, and his ranged attack
         * never fires. The hero's, the same for every hero, go in before the
         * chunk's last word. */
        uint32_t gs = 0x40 + rd32(G, 0x40 + 0x14), as = 0x40 + rd32(A, 0x40 + 0x14);
        if (!memcmp(G + gs, "skel", 4) && !memcmp(A + as, "skel", 4) && !rd32(G, gs + 0x1C) && rd32(A, as + 0x1C)
            && !getenv("TT_NOAIM")) {
            uint32_t ab = rd32(A, as + 0x1C), at2 = rd32(A, as + 0x3C), L = at2 - ab, gt2 = rd32(G, gs + 0x3C);
            uint32_t gend = gs + rd32(G, gs + 0x10);
            if (L && L < 0x100 && gt2 && gs + gt2 <= gend && first + L <= cap && gend <= first) {
                memcpy(out + gs + gt2 + L, G + gs + gt2, first - (gs + gt2));        /* the tail and what follows, moved up */
                memcpy(out + gs + gt2, A + as + ab, L);                               /* the blocks */
                wr32(out, gs + 0x1C, gt2);
                wr32(out, gs + 0x38, gt2 + (rd32(A, as + 0x38) - ab));
                wr32(out, gs + 0x3C, gt2 + L);
                wr32(out, gs + 0x10, rd32(G, gs + 0x10) + L);
                wr32(out, 0x40 + 0x18, rd32(G, 0x40 + 0x18) + L);
                pos = first + L;
            } else if (L && L < 0x100 && !gt2 && gend == first && rd32(G, gs + 8) > 7 && rd32(A, as + 8) > 7 && first + L + 4 + 2 * 68 <= cap
                       && !s_compose_menu && !getenv("TT_NOAIM2")) {
                /* Boromir's skeleton has neither the chunk's last word (the
                 * blocks go in before it) nor the attach points 6 (the bones
                 * the game turns toward his target: the spine's) and 7 (head,
                 * spine, hands, pelvis, knees, feet) that every playable
                 * hero's has, and the other guests' too. All go at the
                 * chunk's end (nothing follows it): the blocks, the hero's
                 * last word, and the hero's two lists, his bones for the
                 * hero's. */
                uint32_t sz = rd32(G, gs + 0x10), p0 = gs + sz, added, k, t = gs + rd32(G, gs + 0xC), ht = as + rd32(A, as + 0xC);
                memcpy(out + p0, A + as + ab, L);
                memcpy(out + p0 + L, A + as + at2, 4);
                wr32(out, gs + 0x1C, sz);
                wr32(out, gs + 0x38, sz + (rd32(A, as + 0x38) - ab));
                wr32(out, gs + 0x3C, sz + L);
                added = L + 4;
                for (k = 6; k <= 7; k++) {
                    uint32_t lo = rd32(A, ht + 4 * k), n, i, lp;
                    if (rd32(out, t + 4 * k) || !lo) continue;
                    n = rd32(A, ht + lo);
                    if (n > 16) continue;
                    lp = p0 + added;
                    wr32(out, lp, n);
                    for (i = 0; i < n; i++) wr32(out, lp + 4 + 4 * i, guest_bone_for(A, alen, G, glen, g, rd32(A, ht + lo + 4 + 4 * i)));
                    wr32(out, t + 4 * k, lp - t);
                    added += 4 + 4 * n;
                    tt_dbg("[HEROES]   attach point %u: %u bone(s), his %u...\n", k, n, rd32(out, lp + 4));
                }
                wr32(out, gs + 0x10, sz + added);
                wr32(out, 0x40 + 0x18, rd32(G, 0x40 + 0x18) + added);
                pos = first + added;
                tt_dbg("[HEROES]   the aiming blocks added at his skeleton's end (%u bytes)\n", added);
            }
        }
    }
    {   /* his third weapon: the weapon op puts script slot 2 on the skeleton's
         * attach point 8 (the head's) and slot 3 on point 12 (none in the
         * guests' skeletons) -- point 12 made the bow hand's (point 0's
         * bone list), so Boromir's shield is on his left arm */
        uint32_t gs = 0x40 + rd32(G, 0x40 + 0x14);
        int xs = getenv("TT_XSLOT") ? atoi(getenv("TT_XSLOT")) : (g >= 0 && g < N_SKINS && s_skins[g].xmesh ? s_skins[g].xslot : 0);
        if (xs == 3 && !memcmp(out + gs, "skel", 4) && rd32(out, gs + 8) > 12 && !s_compose_menu) {
            uint32_t t = gs + rd32(out, gs + 0xC);
            if (rd32(out, t) && t + 4 * 13 <= first) {
                tt_dbg("[HEROES]   attach point 12 (was %X) -> point 0's (bone %u)\n", rd32(out, t + 48), rd32(out, t + rd32(out, t) + 4));
                if (getenv("TT_XENT")) wr32(out, t + 48, rd32(out, t + 4 * (uint32_t)atoi(getenv("TT_XENT"))));   /* testing */
                else wr32(out, t + 48, rd32(out, t));
            }
        }
    }
    if (g >= 0 && g < N_SKINS && getenv("TT_ONEHAND") && !s_compose_menu) {   /* testing: the bow's attach point the sword hand's */
        /* his bow's attach point his sword hand's (point 1's bone list) */
        uint32_t gs = 0x40 + rd32(G, 0x40 + 0x14);
        if (!memcmp(out + gs, "skel", 4) && rd32(out, gs + 8) > 1) {
            uint32_t t = gs + rd32(out, gs + 0xC);
            if (rd32(out, t + 4)) { wr32(out, t, rd32(out, t + 4)); tt_dbg("[HEROES]   attach point 0 -> point 1's\n"); }
        }
    }
    /* the hands' bones (attach points 0 and 1), the hero's and his */
    hand[0] = skel_point_bone(A, alen, 0); hand[1] = skel_point_bone(A, alen, 1);
    ghand[0] = skel_point_bone(out, first, 0); ghand[1] = skel_point_bone(out, first, 1);
    hfoot = skel_point_bone(A, alen, 2); gfoot = skel_point_bone(out, first, 2);
    memset(used, 0, sizeof used);
    wr16(out, 6, (uint16_t)ans);
    for (s = 0; s < ans; s++) {
        const unsigned char *a, *gr;
        uint32_t src, a5, a7, a8, a10, g2, gev, k, nev, tail, newbt, newtail, n, target;
        float scale;
        int cls;
        if (!at[s]) continue;
        cls = anim_class((int)s);
        if (s_compose_menu && (s == 0x22 || s == 0x25 || s == 0x28)) {
            /* the character select: his stance, his pose when chosen, his move when confirmed */
            int pk = pool_pick(s_menu_moves[g][s == 0x22 ? 0 : s == 0x25 ? 1 : 2], 0, gt, gns);
            if (pk < 0) pk = pool_pick("34,33,0", 0, gt, gns);
            if (pk < 0) return 0;
            src = (uint32_t)pk;
        } else
        if (s < gns && gt[s] && cls != AC_SPEED && cls != AC_FIERCE && cls != AC_RANGED && cls != AC_KICK) src = s;
        else {
            int pk = pool_pick(pool_list(g, cls), (int)used[cls]++, gt, gns);
            if (pk < 0) pk = pool_pick("34,0,1", 0, gt, gns);
            if (pk < 0) return 0;
            src = (uint32_t)pk;
        }
        a = A + at[s]; gr = G + gt[src];
        if (ovr[s]) gr = ovr[s];   /* a motion made for this slot (retargeted) */
        a5 = rd32(a, 0x14); a7 = rd32(a, 0x1C); a8 = rd32(a, 0x20); a10 = rd32(a, 0x28);
        g2 = rd32(gr, 8); gev = rd32(gr, 0x1C);
        if (a10 > a5 || a7 > a8 || at[s] + a5 > alen || (!ovr[s] && gt[src] + gev > glen)) return 0;
        nev = rd32(a, 0x18);
        tail = a5 - a10;
        n = gev + (a8 - a7) + 4 * nbG + tail;
        pos = (pos + 15) & ~15u;
        if (pos + n > cap) return 0;
        {   /* a move of his for one of the hero's: played at near the hero's pace
             * (attacks no slower than a little over his: they must answer the
             * button as the hero's do) */
            uint32_t ad = rd32(a, 8), lo = ad * 9 / 10, hi = ad * 115 / 100 + 50;
            if ((cls == AC_SPEED || cls == AC_FIERCE || cls == AC_KICK || cls == AC_RANGED || cls == AC_PARRY) && ad && !getenv("TT_NOSTRETCH"))
                target = g2 < lo ? lo : g2 > hi ? hi : g2;
            else target = g2;
            if (cls == AC_MOVE && !ovr[s] && ad && g2 && !s_compose_menu && !getenv("TT_NOCADENCE")) {
                /* walks and runs: his steps' length over the hero's, so his
                 * feet keep pace with the ground (the game moves him at the
                 * hero's speed) */
                float lh = stride_len(A, alen, a, alen - at[s], (int)hfoot, ad), lg = stride_len(G, glen, gr, glen - gt[src], (int)gfoot, g2);
                if (lh > 0.3f && lg > 0.3f) {
                    float t2 = (float)ad * lg / lh;
                    if (t2 < g2 * 0.6f) t2 = g2 * 0.6f;
                    if (t2 > g2 * 1.6f) t2 = g2 * 1.6f;
                    target = (uint32_t)(t2 + 0.5f);
                    tt_dbg("[HEROES]   slot %u: stride %.2f (hero %.2f): %u ms (his %u, hero %u)\n", s, lg, lh, target, g2, ad);
                }
            }
        }
        scale = rd32(a, 8) ? (float)target / (float)rd32(a, 8) : 1.0f;
        /* his swing's strike at the hero's strike moment: the hero's events
         * (the strike, the swoosh, the next move's input window) timed by a
         * piecewise map that puts the hero's strike (its first strike event,
         * type 5) on his swing's fastest moment */
        sh = -1; sg = -1; sp = -1;
        if (!ovr[s] && (cls == AC_SPEED || cls == AC_FIERCE || cls == AC_KICK) && !s_compose_menu && !getenv("TT_NOALIGN")) {
            uint32_t k2;
            for (k2 = 0; k2 < nev && 4 * k2 < a8 - a7; k2++) {
                uint32_t eo2 = a7 + rd32(a, a7 + 4 * k2);
                if (eo2 + 16 <= a8 && rd32(a, eo2 + 12) == 5) { int t0 = (int)rd32(a, eo2); if (sh < 0 || t0 < sh) sh = t0; }
            }
            if (sh > 0 && (uint32_t)sh < rd32(a, 8)) {
                float s0, s1;
                int p0 = swing_peak(G, glen, gr, glen - gt[src], (int)ghand[0], g2, &s0), p1 = swing_peak(G, glen, gr, glen - gt[src], (int)ghand[1], g2, &s1);
                int pk2 = s1 > s0 ? p1 : p0;
                if (pk2 > 0 && g2) sp = (int)((float)pk2 * (float)target / (float)g2 + 0.5f);   /* his peak, in the new length */
                if (sp > 0 && sp < (int)target) {
                    /* the strike lands near the hero's moment (a little of his
                     * own wind-up kept): his motion warped to it, the events too */
                    int hs = (int)((float)sh * scale + 0.5f);
                    sg = sp > hs ? hs + (sp - hs) * 3 / 10 : sp;
                    if (sg < 1) sg = 1;
                    if (sg >= (int)target) sg = (int)target - 1;
                    tt_dbg("[HEROES]   slot %u (his %u): hero strike %d ms, his swing %d -> %d of %u\n", s, src, sh, sp, sg, target);
                } else sh = -1;
            } else sh = -1;
        }
        memcpy(out + pos, gr, gev);                                   /* his motion */
        if ((target != g2 || sh > 0) && g2) {   /* its keys' times (u16 first in each 8-byte key) to the new length (and his swing to the strike) */
            float ks = (float)target / (float)g2;
            uint32_t bi, bt0 = rd32(gr, 0x20);
            for (bi = 0; bi < nbG; bi++) {
                uint32_t bo = rd32(gr, bt0 + 4 * bi), nk, q;
                if (!bo || bo + 4 > gev) continue;
                nk = (uint32_t)gr[bo] + gr[bo + 1] + gr[bo + 2] + gr[bo + 3];
                for (q = 0; q < nk && bo + 4 + 8 * q + 2 <= gev; q++) {
                    uint32_t ko = bo + 4 + 8 * q;
                    float kt = rd16(gr, ko) * ks;
                    if (sh > 0 && sp > 0) kt = kt <= sp ? kt * (float)sg / (float)sp : (float)sg + (kt - sp) * ((float)target - sg) / ((float)target - sp);
                    wr16(out + pos, ko, (uint16_t)(kt + 0.5f));
                }
            }
        }
        memcpy(out + pos, a, 0x40);                                   /* the hero's header */
        memcpy(out + pos + gev, a + a7, a8 - a7);                     /* the hero's events */
        for (k = 0; k < nev && 4 * k < a8 - a7; k++) {
            uint32_t eo = gev + rd32(a, a7 + 4 * k);
            if (eo + 4 <= gev + (a8 - a7)) wr32(out + pos, eo, strike_map(rd32(out + pos, eo), scale, sh, sg, rd32(a, 8), target));
        }
        newbt = gev + (a8 - a7);
        memcpy(out + pos + newbt, gr + rd32(gr, 0x20), 4 * nbG);       /* his bones' table */
        newtail = newbt + 4 * nbG;
        memcpy(out + pos + newtail, a + a10, tail);                   /* the hero's tail */
        if (rd32(a, 0x30)) {
            uint32_t a13 = rd32(a, 0x34), j;
            for (j = 0; j < rd32(a, 0x30) && a13 + 4 * j + 4 <= a5; j++) {
                /* {time, bone}: a strike's window and the bone it hits
                 * from -- the hero's sword hand (36) is another bone on
                 * the guest's skeleton (Boromir's upper arm): his own */
                uint32_t o2 = newtail + (a13 - a10) + 4 * j, hbn = rd16(out + pos, o2 + 2), gbn = hbn;
                wr16(out + pos, o2, (uint16_t)strike_map(rd16(out + pos, o2), scale, sh, sg, rd32(a, 8), target));
                if (!getenv("TT_NOHITBONE")) {
                    if (getenv("TT_HITBONE")) gbn = (uint32_t)atoi(getenv("TT_HITBONE"));   /* testing */
                    else if (hbn == hand[0] && ghand[0] != 0xFFFFu) gbn = ghand[0];
                    else if (hbn == hand[1] && ghand[1] != 0xFFFFu) gbn = ghand[1];
                    else if (g >= 0 && g < N_SKINS && s_skins[g].map) {   /* the last of his bones the map gives it */
                        int q2;
                        for (q2 = s_skins[g].nmap - 1; q2 >= 0; q2--) if (s_skins[g].map[q2] == hbn) { gbn = (uint32_t)q2; break; }
                    }
                    if (gbn >= nbG) gbn = hbn < nbG ? hbn : 0;
                    wr16(out + pos, o2 + 2, (uint16_t)gbn);
                }
            }
            wr32(out + pos, 0x34, newtail + (a13 - a10));
            if (rd32(a, 0x38)) wr32(out + pos, 0x38, newtail + (rd32(a, 0x38) - a10));
        }
        if (rd32(a, 0x2C)) wr32(out + pos, 0x2C, newtail + (rd32(a, 0x2C) - a10));
        if (rd32(a, 0x24) != 0xFFFFu) wr32(out + pos, 0x24, strike_map(rd32(a, 0x24), scale, sh, sg, rd32(a, 8), target));
        wr32(out + pos, 8, target);
        wr32(out + pos, 0x14, n);
        wr32(out + pos, 0x1C, gev);
        wr32(out + pos, 0x20, newbt);
        wr32(out + pos, 0x28, newtail);
        at[s] = pos;
        pos += n;
    }
    if (getenv("TT_ANIMCYCLE")) {   /* testing: every motion of his in a free slot, to be shown in turn */
        uint32_t gs, e = 0;
        s_ncyc = 0;
        for (gs = 0; gs < gns && s_ncyc < 64; gs++) {
            uint32_t n = rd32(G + gt[gs], 0x14);
            if (!gt[gs]) continue;
            while (e < ans && at[e]) e++;
            if (e >= ans) break;
            pos = (pos + 15) & ~15u;
            if (pos + n > cap) break;
            memcpy(out + pos, G + gt[gs], n);
            at[e] = pos; s_cyc[s_ncyc][0] = gs; s_cyc[s_ncyc][1] = e; s_cyc[s_ncyc][2] = pos; s_ncyc++;
            pos += n;
        }
    }
    if (getenv("TT_CYCSLOTS")) {   /* testing: these composed slots, shown in turn */
        const char *q = getenv("TT_CYCSLOTS");
        s_ncyc = 0;
        while (*q && s_ncyc < 64) {
            uint32_t v = (uint32_t)atoi(q);
            if (v < ans && at[v]) { s_cyc[s_ncyc][0] = v; s_cyc[s_ncyc][1] = v; s_cyc[s_ncyc][2] = at[v]; s_ncyc++; }
            q = strchr(q, ','); if (!q) break; q++;
        }
    }
    pos = (pos + 15) & ~15u;
    if (pos + 4 * ans > cap) return 0;
    for (s = 0; s < ans; s++) wr32(out, pos + 4 * s, at[s]);
    wr32(out, 0x10, pos);
    pos += 4 * ans;
    wr32(out, 0xC, pos);
    s_comp_size = pos;
    return pos;
}
#define MAX_ADDS 32

/* target + resources -> out: each Add's data is appended; a directory
 * entry with its {type, key} is repointed at it, else one is added (unless
 * the target has that resource already). 1 on success. */
/* ---- Boromir's shield, part of his own model ----
 * A weapon in the bow's hand is drawn only while the hero shoots, and the
 * script's other slots in cutscenes only: so the shield (a prop: "prxb",
 * 32-byte vertices {pos, normal, uv} at +0x1000, a u16 strip at +0x1000 +
 * [+0x1F0], [+0x204] bytes of it) goes into his mesh, on his left forearm
 * (the hand has no palette slot), placed by the hand's bind pose as the
 * weapon op places props; and his texture becomes 256x512, his own above
 * and the shield's below (UVs remapped). DXT1 throughout. */
typedef struct { int skin; uint32_t mesh, tex, anim, prop, ptex; int bone, skinbone; } Shield;
/* his skeleton's sword hand is bone 40 (attach point 0 -- x < 0 is his
 * right); the shield goes on the other: placed by hand 32, on forearm 29 */
static const Shield s_shields[] = { { 0, 0xA6841986u, 0xFD8B0956u, 0xF9C62B16u, 0x0D473744u, 0xDEF52D38u, 32, 29 } };

static void dxt1a_decode(const unsigned char *d, int w, int h, unsigned char *rgba)
{
    int bx, by, i;
    for (by = 0; by < (h + 3) / 4; by++)
        for (bx = 0; bx < (w + 3) / 4; bx++, d += 8) {
            unsigned c0 = rd16(d, 0), c1 = rd16(d, 2); uint32_t bits = rd32(d, 4);
            unsigned char pal[4][4];
            for (i = 0; i < 2; i++) {
                unsigned c = i ? c1 : c0;
                pal[i][0] = (unsigned char)(((c >> 11) & 31) * 255 / 31); pal[i][1] = (unsigned char)(((c >> 5) & 63) * 255 / 63); pal[i][2] = (unsigned char)((c & 31) * 255 / 31); pal[i][3] = 255;
            }
            for (i = 0; i < 3; i++) {
                if (c0 > c1) { pal[2][i] = (unsigned char)((2 * pal[0][i] + pal[1][i]) / 3); pal[3][i] = (unsigned char)((pal[0][i] + 2 * pal[1][i]) / 3); }
                else { pal[2][i] = (unsigned char)((pal[0][i] + pal[1][i]) / 2); pal[3][i] = 0; }
            }
            pal[2][3] = 255; pal[3][3] = c0 > c1 ? 255 : 0;
            for (i = 0; i < 16; i++) {
                int x = bx * 4 + (i & 3), y = by * 4 + (i >> 2);
                if (x < w && y < h) memcpy(rgba + 4 * ((size_t)y * w + x), pal[(bits >> (2 * i)) & 3], 4);
            }
        }
}
static unsigned rgb565(const float *c)
{
    int r = (int)(c[0] * 31 / 255 + 0.5f), g = (int)(c[1] * 63 / 255 + 0.5f), b = (int)(c[2] * 31 / 255 + 0.5f);
    r = r < 0 ? 0 : r > 31 ? 31 : r; g = g < 0 ? 0 : g > 63 ? 63 : g; b = b < 0 ? 0 : b > 31 ? 31 : b;
    return (unsigned)(r << 11 | g << 5 | b);
}
/* one block: the colours' main axis (a few power steps), its ends */
static void dxt1_block(const unsigned char px[16][4], unsigned char *o)
{
    float mean[3] = { 0, 0, 0 }, cov[3][3] = { { 0 } }, ax[3] = { 1, 1, 1 }, lo = 1e9f, hi = -1e9f, e0[3], e1[3], pal[4][3];
    int i, j, k, n = 0, trans = 0;
    unsigned c0, c1; uint32_t bits = 0;
    for (i = 0; i < 16; i++) { if (px[i][3] < 128) { trans = 1; continue; } for (j = 0; j < 3; j++) mean[j] += px[i][j]; n++; }
    if (!n) { wr16(o, 0, 0); wr16(o, 2, 0xFFFF); wr32(o, 4, 0xFFFFFFFFu); return; }
    for (j = 0; j < 3; j++) mean[j] /= (float)n;
    for (i = 0; i < 16; i++) if (px[i][3] >= 128) for (j = 0; j < 3; j++) for (k = 0; k < 3; k++) cov[j][k] += (px[i][j] - mean[j]) * (px[i][k] - mean[k]);
    for (k = 0; k < 6; k++) {
        float t[3], m = 0;
        for (j = 0; j < 3; j++) t[j] = cov[j][0] * ax[0] + cov[j][1] * ax[1] + cov[j][2] * ax[2];
        for (j = 0; j < 3; j++) if (fabsf(t[j]) > m) m = fabsf(t[j]);
        if (m < 1e-6f) break;
        for (j = 0; j < 3; j++) ax[j] = t[j] / m;
    }
    for (i = 0; i < 16; i++) if (px[i][3] >= 128) {
        float d = (px[i][0] - mean[0]) * ax[0] + (px[i][1] - mean[1]) * ax[1] + (px[i][2] - mean[2]) * ax[2];
        if (d < lo) lo = d; if (d > hi) hi = d;
    }
    { float n2 = ax[0] * ax[0] + ax[1] * ax[1] + ax[2] * ax[2]; if (n2 < 1e-9f) n2 = 1; for (j = 0; j < 3; j++) { e0[j] = mean[j] + ax[j] * hi / n2; e1[j] = mean[j] + ax[j] * lo / n2; } }
    c0 = rgb565(e0); c1 = rgb565(e1);
    if (trans ? c0 > c1 : c0 < c1) { unsigned t = c0; c0 = c1; c1 = t; }
    if (!trans && c0 == c1) { wr16(o, 0, (uint16_t)c0); wr16(o, 2, (uint16_t)c1); wr32(o, 4, 0); return; }
    for (i = 0; i < 2; i++) { unsigned c = i ? c1 : c0; pal[i][0] = ((c >> 11) & 31) * 255.0f / 31; pal[i][1] = ((c >> 5) & 63) * 255.0f / 63; pal[i][2] = (c & 31) * 255.0f / 31; }
    for (j = 0; j < 3; j++) {
        if (!trans) { pal[2][j] = (2 * pal[0][j] + pal[1][j]) / 3; pal[3][j] = (pal[0][j] + 2 * pal[1][j]) / 3; }
        else { pal[2][j] = (pal[0][j] + pal[1][j]) / 2; pal[3][j] = -1e6f; }
    }
    for (i = 0; i < 16; i++) {
        int best = 0; float bd = 1e30f;
        if (trans && px[i][3] < 128) best = 3;
        else for (k = 0; k < (trans ? 3 : 4); k++) {
            float d = 0; for (j = 0; j < 3; j++) d += (px[i][j] - pal[k][j]) * (px[i][j] - pal[k][j]);
            if (d < bd) { bd = d; best = k; }
        }
        bits |= (uint32_t)best << (2 * i);
    }
    wr16(o, 0, (uint16_t)c0); wr16(o, 2, (uint16_t)c1); wr32(o, 4, bits);
}
static size_t dxt1a_encode(const unsigned char *rgba, int w, int h, unsigned char *o)
{
    int bx, by, i;
    size_t n = 0;
    for (by = 0; by < (h + 3) / 4; by++)
        for (bx = 0; bx < (w + 3) / 4; bx++) {
            unsigned char px[16][4];
            for (i = 0; i < 16; i++) {
                int x = bx * 4 + (i & 3), y = by * 4 + (i >> 2);
                if (x >= w) x = w - 1; if (y >= h) y = h - 1;
                memcpy(px[i], rgba + 4 * ((size_t)y * w + x), 4);
            }
            dxt1_block((const unsigned char (*)[4])px, o + n); n += 8;
        }
    return n;
}
static unsigned char *shield_mesh(const Shield *sh, const unsigned char *S, size_t sl, size_t *len)
{
    uint32_t ma, me, ty, pa, pe, aa, ae, vc, vo, ic, io, ib, np, i, nv = 0, pal, slot = 0xFFFFFFFFu, ioff, inb, newsize, end;
    static int par[128]; static Quat W[128], BL[128];
    unsigned char *m;
    float T[3], minv = 1e9f, fl;
    int nb;
    if (!res_find(S, sl, sh->mesh, 100, &ma, &me, &ty) || !res_find(S, sl, sh->prop, 200, &pa, &pe, &ty) || !res_find(S, sl, sh->anim, 150, &aa, &ae, &ty)) return NULL;
    if (memcmp(S + pa, "prxb", 4) || rd32(S, ma + 0x2C) != 1) return NULL;
    if (getenv("TT_SHBONE") || getenv("TT_SHSKIN")) {   /* testing: other bones */
        static Shield t; t = *sh;
        if (getenv("TT_SHBONE")) t.bone = atoi(getenv("TT_SHBONE"));
        if (getenv("TT_SHSKIN")) t.skinbone = atoi(getenv("TT_SHSKIN"));
        sh = &t;
    }
    nb = rt_binds(S + aa, ae - aa, par, W, BL);
    if (nb <= sh->bone) return NULL;
    { uint32_t mo = 0x40 + rd32(S + aa, 0x40 + 0xC) + (uint32_t)sh->bone * 128 + 64 + 48; int c; for (c = 0; c < 3; c++) { uint32_t v = rd32(S + aa, mo + 4 * c); memcpy(&T[c], &v, 4); } }
    ioff = 0x1000 + rd32(S, pa + 0x1F0); inb = rd32(S, pa + 0x204);
    if (pa + ioff + inb > pe || inb < 6) return NULL;
    for (i = 0; i < inb / 2; i++) if (rd16(S, pa + ioff + 2 * i) + 1u > nv) nv = rd16(S, pa + ioff + 2 * i) + 1u;
    if (pa + 0x1000 + nv * 32 > pa + ioff) return NULL;
    vc = rd32(S, ma + 0x30); vo = rd32(S, ma + 0x38); ic = rd32(S, ma + 0x48); io = rd32(S, ma + 0x4C); pal = rd32(S, ma + 0x50);
    for (i = 0; i < pal && i < 255; i++) if (S[ma + 0x54 + 2 * i] == sh->skinbone) slot = S[ma + 0x55 + 2 * i];
    ib = io + 0x4C; end = vo + 0x34 + 48 * vc;
    if (slot == 0xFFFFFFFFu || ic % 2 || ib + 2 * (ic + 2 + inb / 2) > vo || rd32(S, ma + 8) != me - ma || end > me - ma) return NULL;
    newsize = (end + 48 * nv + 0xFFF) & ~0xFFFu;
    if (newsize < me - ma) newsize = (me - ma + 0xFFF) & ~0xFFFu;
    m = (unsigned char *)calloc(1, newsize);
    if (!m) return NULL;
    memcpy(m, S + ma, me - ma);
    for (i = 0; i < vc; i++) { uint32_t a = vo + 0x34 + 48 * i + 28; memcpy(&fl, m + a, 4); fl *= 0.5f; memcpy(m + a, &fl, 4); }   /* his texture: the top half */
    for (i = 0; i < nv; i++) { float v; memcpy(&v, S + pa + 0x1000 + 32 * i + 28, 4); if (v < minv) minv = v; }
    minv = floorf(minv);
    fl = (float)(slot * 3);
    for (i = 0; i < nv; i++) {
        const unsigned char *v = S + pa + 0x1000 + 32 * i;
        float p[3], n[3], r[8], f[12]; int c;
        for (c = 0; c < 8; c++) memcpy(&r[c], v + 4 * c, 4);
        qrotv(W[sh->bone], r, p); qrotv(W[sh->bone], r + 3, n);
        for (c = 0; c < 3; c++) { f[c] = p[c] + T[c]; f[3 + c] = n[c]; }
        f[6] = r[6]; f[7] = 0.5f + 0.5f * (r[7] - minv);
        f[8] = fl; f[9] = 1; f[10] = fl; f[11] = 0;
        memcpy(m + end + 48 * i, f, 48);
    }
    wr32(m, 8, newsize);
    {   /* the strip continued: a degenerate join, the parity kept */
        uint32_t last = rd16(m, ib + 2 * (ic - 1)), k = ic;
        wr16(m, ib + 2 * k++, (uint16_t)last); wr16(m, ib + 2 * k++, (uint16_t)(rd16(S, pa + ioff) + vc));
        for (i = 0; i < inb / 2; i++) wr16(m, ib + 2 * k++, (uint16_t)(rd16(S, pa + ioff + 2 * i) + vc));
        wr32(m, 0x30, vc + nv); wr32(m, 0x48, k);
    }
    np = 0; (void)np;
    *len = newsize;
    tt_dbg("[HEROES] his shield in his model: %u vertices on bone %d\n", nv, sh->skinbone);
    return m;
}
static unsigned char *shield_tex(const Shield *sh, const unsigned char *S, size_t sl, size_t *len)
{
    uint32_t ta, te, sa, se, ty;
    int w, h, sw, shh, lv = 0, x, y;
    unsigned char *atl, *st, *o, *mip;
    size_t n = 0, ocap;
    if (!res_find(S, sl, sh->tex, 300, &ta, &te, &ty) || !res_find(S, sl, sh->ptex, 300, &sa, &se, &ty)) return NULL;
    w = (int)rd32(S, ta + 4); h = (int)rd32(S, ta + 8); sw = (int)rd32(S, sa + 4); shh = (int)rd32(S, sa + 8);
    if (rd32(S, ta + 12) != 0x11 || rd32(S, sa + 12) != 0x11 || w != h || w < 64 || w > 1024 || sw > 1024 || shh > 1024) return NULL;
    atl = (unsigned char *)malloc((size_t)w * h * 2 * 4); st = (unsigned char *)malloc((size_t)sw * shh * 4);
    /* DXT1, half a byte a texel: w x 2h is w*h bytes, its mips a third more;
     * twice that, page-rounded, is room for all with the padding */
    ocap = (0x80 + 2 * (size_t)w * h + 0x2000 + 0xFFF) & ~(size_t)0xFFF;
    o = (unsigned char *)calloc(1, ocap);
    mip = (unsigned char *)malloc((size_t)w * h * 2 * 4);
    if (!atl || !st || !o || !mip) { free(atl); free(st); free(o); free(mip); return NULL; }
    dxt1a_decode(S + ta + 0x80, w, h, atl);
    dxt1a_decode(S + sa + 0x80, sw, shh, st);
    for (y = 0; y < h; y++)   /* the shield's, scaled up (bilinear) */
        for (x = 0; x < w; x++) {
            float fx = (x + 0.5f) * sw / w - 0.5f, fy = (y + 0.5f) * shh / h - 0.5f;
            int x0 = (int)floorf(fx), y0 = (int)floorf(fy), c;
            float ax = fx - x0, ay = fy - y0;
            for (c = 0; c < 4; c++) {
                int xa = x0 < 0 ? 0 : x0, xb = x0 + 1 >= sw ? sw - 1 : x0 + 1, ya = y0 < 0 ? 0 : y0, yb = y0 + 1 >= shh ? shh - 1 : y0 + 1;
                float v = (1 - ax) * (1 - ay) * st[4 * (ya * sw + xa) + c] + ax * (1 - ay) * st[4 * (ya * sw + xb) + c]
                        + (1 - ax) * ay * st[4 * (yb * sw + xa) + c] + ax * ay * st[4 * (yb * sw + xb) + c];
                atl[4 * ((size_t)(h + y) * w + x) + c] = (unsigned char)(v + 0.5f);
            }
        }
    memcpy(o, S + ta, 0x80);
    {
        int cw = w, ch = 2 * h;
        memcpy(mip, atl, (size_t)w * h * 2 * 4);
        for (;;) {
            n += dxt1a_encode(mip, cw, ch, o + 0x80 + n); lv++;
            if (cw == 1 && ch == 1) break;
            {   /* the next level: 2x2 averages */
                int nw = cw > 1 ? cw / 2 : 1, nh = ch > 1 ? ch / 2 : 1, c;
                for (y = 0; y < nh; y++) for (x = 0; x < nw; x++) for (c = 0; c < 4; c++) {
                    int xa = cw > 1 ? 2 * x : x, ya = ch > 1 ? 2 * y : y, xb = cw > 1 ? xa + 1 : xa, yb = ch > 1 ? ya + 1 : ya;
                    mip[4 * (y * nw + x) + c] = (unsigned char)((mip[4 * (ya * cw + xa) + c] + mip[4 * (ya * cw + xb) + c] + mip[4 * (yb * cw + xa) + c] + mip[4 * (yb * cw + xb) + c] + 2) / 4);
                }
                cw = nw; ch = nh;
            }
        }
    }
    {   /* the header: 256 x 512 (the NV2A format word: levels, log2 sizes) */
        uint32_t f = rd32(o, 0x38), lw = 0, lh = 0;
        while ((1 << lw) < w) lw++; while ((1 << lh) < 2 * h) lh++;
        wr32(o, 8, (uint32_t)(2 * h)); wr32(o, 0x18, (uint32_t)lv);
        wr32(o, 0x38, (f & 0xFFFFu) | (uint32_t)lv << 16 | lw << 20 | lh << 24);
    }
    free(atl); free(st); free(mip);
    *len = (0x80 + n + 0xFFF) & ~(size_t)0xFFF;
    if (*len > ocap) { free(o); return NULL; }   /* (cannot happen: ocap holds it) */
    tt_dbg("[HEROES] his texture with his shield's: %dx%d, %d levels\n", w, 2 * h, lv);
    return o;
}
/* a resource made for a guest: Boromir's model with his shield, his
 * texture with the shield's; or (testing) heroes\<name>\res_<KEY>.bin */
static unsigned char *res_override(const unsigned char *S, size_t sl, uint32_t key, size_t *len)
{
    char pth[700]; int g; unsigned char *d;
    size_t i;
    if (getenv("TT_NORESOVR")) return NULL;
    paths();
    for (g = 0; g < N_SKINS; g++) {
        snprintf(pth, sizeof pth, "%s/heroes/%s/res_%08X.bin", s_dir, s_skins[g].name, key);
        if ((d = read_all(pth, len)) != NULL) return d;
    }
    if (getenv("TT_NOSHIELD")) return NULL;
    for (i = 0; i < sizeof s_shields / sizeof s_shields[0]; i++) {
        if (key == s_shields[i].mesh) return shield_mesh(&s_shields[i], S, sl, len);
        if (key == s_shields[i].tex) return shield_tex(&s_shields[i], S, sl, len);
    }
    return NULL;
}
static int build_file(const char *target, const Add *adds, int nadds, const char *out)
{
    size_t tl, cap, pos, sl[MAX_ADDS];
    unsigned char *t = read_all(target, &tl), *o = NULL, *s[MAX_ADDS], *ov[MAX_ADDS];
    uint32_t n, cnt, i, k, newoff[MAX_ADDS], extra = 0;
    size_t ovl[MAX_ADDS];
    int ok = 0, repoint[MAX_ADDS];
    FILE *f;
    memset(s, 0, sizeof s);
    memset(ov, 0, sizeof ov);
    if (!t || t[0] != 9 || nadds > MAX_ADDS) goto done;
    cap = tl + 0x10000;
    for (k = 0; k < (uint32_t)nadds; k++) {
        uint32_t a, e2, ty, j;
        char hp[600];
        for (j = 0; j < k; j++) if (!strcmp(adds[j].src, adds[k].src)) { s[k] = s[j]; sl[k] = sl[j]; break; }
        if (!s[k]) {
            if (!host_path(adds[k].src, hp, sizeof hp) || !(s[k] = read_all(hp, &sl[k])) || s[k][0] != 9) {
                tt_dbg("[HEROES] cannot read %s\n", adds[k].src); goto done;
            }
        }
        if (!res_find(s[k], sl[k], adds[k].src_key, -1, &a, &e2, &ty)) { tt_dbg("[HEROES] %08X not in %s\n", adds[k].src_key, adds[k].src); goto done; }
        ov[k] = res_override(s[k], sl[k], adds[k].src_key, &ovl[k]);
        cap += e2 - a + 0x2000 + (ov[k] ? ovl[k] : 0);
        if (adds[k].compose) cap += 0x200000;
    }
    o = (unsigned char *)calloc(1, cap);
    if (!o) goto done;
    n = rd32(t, 4); cnt = rd32(t, n);
    memcpy(o, t, n);
    pos = n;
    for (k = 0; k < (uint32_t)nadds; k++) {
        uint32_t a, e2, ty, d1, d2, d3;
        repoint[k] = 0; newoff[k] = 0;
        for (i = 0; i < cnt; i++)
            if (rd32(t, n + 4 + 12 * i) == adds[k].type && rd32(t, n + 4 + 12 * i + 8) == adds[k].key) repoint[k] = 1;
        if (ov[k] && res_find(t, tl, adds[k].key, (int)adds[k].type, &d1, &d2, &d3)) repoint[k] = 1;   /* ours over the level's own */
        if (!repoint[k] && res_find(t, tl, adds[k].key, (int)adds[k].type, &d1, &d2, &d3)) continue;   /* there already */
        res_find(s[k], sl[k], adds[k].src_key, -1, &a, &e2, &ty);
        /* same offset within a page as in the source: texture data starts
         * on a page boundary there, and the renderer watches those pages */
        pos = ((pos + 0xFFF) & ~(size_t)0xFFF) + (a & 0xFFF);
        if (adds[k].compose) {
            /* the hero's set in the target: Aragorn's */
            static const uint32_t hk[] = { 0xDE94124Au, 0xE39B82A6u, 0x44E6E72Au, 0x53DFD442u };
            uint32_t ha = 0, he = 0, ht, q;
            size_t got = 0;
            for (q = 0; q < 4 && !got; q++)
                if (adds[k].type == 1100 ? (q == 0 && res_find(t, tl, MENU_ANIM_KEY, 1100, &ha, &he, &ht)) : res_find(t, tl, hk[q], 150, &ha, &he, &ht))
                    got = compose_anims(t + ha, he - ha, s[k] + a, e2 - a, adds[k].compose - 1, o + pos, cap - pos - 0x10000);
            if (!got) { tt_dbg("[HEROES] could not compose the animations\n"); goto done; }
            tt_dbg("[HEROES] his own animations as the hero's: %u bytes\n", (unsigned)got);
            newoff[k] = (uint32_t)pos;
            pos += got;
            if (!repoint[k]) extra++;
            continue;
        }
        if (ov[k]) {   /* made for him (heroes\<name>\res_<key>.bin) */
            a = 0; e2 = (uint32_t)ovl[k];   /* at the source's offset in its page (a texture's data on a page start) */
            memcpy(o + pos, ov[k], ovl[k]);
            tt_dbg("[HEROES] %08X: his own version (%u bytes)\n", adds[k].src_key, (unsigned)ovl[k]);
        } else
        memcpy(o + pos, s[k] + a, e2 - a);
        if (adds[k].map) remap_bones(o + pos, e2 - a, adds[k].map, adds[k].nmap);
        if (adds[k].tint && (adds[k].type == 300 || adds[k].type == 1250) && e2 - a > 0x88 && (rd32(o + pos, 0xC) & 0xFF) == 0x11) {
            /* Sting lit: its bright metal (the blade) a pale, glowing blue
             * -- each DXT1 block's two end colours */
            size_t q;
            for (q = 0x80; q + 8 <= e2 - a; q += 8) {
                unsigned c0 = rd16(o + pos, q), c1 = rd16(o + pos, q + 2), nc[2];
                int e;
                for (e = 0; e < 2; e++) {
                    unsigned c = e ? c1 : c0, r = (c >> 11) & 31, g = (c >> 5) & 63, b = c & 31;
                    unsigned lum = r * 2 + g + b * 2;   /* about 0..250 */
                    int mx = (int)r, mn = (int)r;
                    if ((int)(g / 2) > mx) mx = (int)(g / 2); if ((int)(g / 2) < mn) mn = (int)(g / 2);
                    if ((int)b > mx) mx = (int)b; if ((int)b < mn) mn = (int)b;
                    nc[e] = c;
                    if (lum > 90 && mx - mn < 7) {   /* light, unsaturated: the steel */
                        unsigned nr = r * 2 / 3 + 6, ng = g * 7 / 8 + 20, nb = b + 14;
                        if (nr > 31) nr = 31; if (ng > 63) ng = 63; if (nb > 31) nb = 31;
                        nc[e] = (nr << 11) | (ng << 5) | nb;
                    }
                }
                if (c0 > c1) {   /* the four-colour mode kept: c0 still the greater */
                    if (nc[0] == nc[1]) { if (nc[1] & 31) nc[1]--; else nc[0]++; }
                    if (nc[0] < nc[1]) {   /* swapped: the indices too (0<->1, 2<->3) */
                        unsigned t = nc[0]; uint32_t ix = rd32(o + pos, q + 4);
                        nc[0] = nc[1]; nc[1] = t;
                        wr32(o + pos, q + 4, ix ^ 0x55555555u);
                    }
                } else if (nc[0] > nc[1]) {   /* the three-colour mode kept */
                    unsigned t = nc[0]; uint32_t ix = rd32(o + pos, q + 4), out = 0; int j;
                    nc[0] = nc[1]; nc[1] = t;
                    for (j = 0; j < 16; j++) { uint32_t v = (ix >> (2 * j)) & 3; if (v < 2) v ^= 1; out |= v << (2 * j); }
                    wr32(o + pos, q + 4, out);
                }
                wr16(o + pos, q, (uint16_t)nc[0]); wr16(o + pos, q + 2, (uint16_t)nc[1]);
            }
        }
        if (adds[k].empty && e2 - a >= 0x1000 && !memcmp(o + pos, "prxb", 4)) {
            /* a prop drawn as nothing: its strip all one index */
            uint32_t io2 = 0x1000 + rd32(o + pos, 0x1F0), nb2 = rd32(o + pos, 0x204);
            if (io2 + nb2 <= e2 - a) memset(o + pos + io2, 0, nb2);
        }

        else if (getenv("TT_IDMAP") && adds[k].type == 100) {   /* testing: the remap's other steps alone */
            static uint8_t idm[256]; int q; for (q = 0; q < 256; q++) idm[q] = (uint8_t)q;
            remap_bones(o + pos, e2 - a, idm, 256);
        }
        newoff[k] = (uint32_t)pos;
        pos += e2 - a;
        if (!repoint[k]) extra++;
    }
    pos = (pos + 0xF) & ~(size_t)0xF;
    wr32(o, 4, (uint32_t)pos);
    wr32(o, pos, cnt + extra);
    memcpy(o + pos + 4, t + n + 4, (size_t)cnt * 12);
    for (k = 0; k < (uint32_t)nadds; k++) {
        if (!newoff[k]) continue;
        if (repoint[k]) {
            for (i = 0; i < cnt; i++) {
                size_t e = pos + 4 + (size_t)i * 12;
                if (rd32(o, e) == adds[k].type && rd32(o, e + 8) == adds[k].key) wr32(o, e + 4, newoff[k]);
            }
        } else {
            size_t e = pos + 4 + (size_t)cnt * 12;
            wr32(o, e, adds[k].type); wr32(o, e + 4, newoff[k]); wr32(o, e + 8, adds[k].key);
            cnt++;
        }
    }
    f = fopen(out, "wb");
    if (f) {
        size_t total = pos + 4 + (size_t)cnt * 12;
        ok = fwrite(o, 1, total, f) == total;
        fclose(f);
        if (!ok) remove(out);
    }
done:
    for (k = 0; k < MAX_ADDS; k++) {
        uint32_t j, dup = 0;
        for (j = 0; j < k; j++) if (s[j] == s[k]) dup = 1;
        if (!dup) free(s[k]);
        free(ov[k]);
    }
    free(o); free(t);
    return ok;
}

static void mkdirs(const char *path)
{
    char p[600];
    size_t i;
    snprintf(p, sizeof p, "%s", path);
    for (i = 1; p[i]; i++)
        if (p[i] == '/' || p[i] == '\\') {
            char c = p[i]; p[i] = 0;
#ifdef _WIN32
            CreateDirectoryA(p, NULL);
#else
            { extern int mkdir(const char *, unsigned); mkdir(p, 0755); }
#endif
            p[i] = c;
        }
}

/* the rebuilt file heroes\<sub>\<outname> (built now if missing) or NULL */
static const char *cached(const char *sub, const char *xtarget, const char *outname, const Add *adds, int nadds)
{
    static char out[600];
    char tgt[600];
    FILE *f;
    paths();
    snprintf(out, sizeof out, "%s/heroes/%s/%s", s_dir, sub, outname);
    if ((f = fopen(out, "rb"))) { fclose(f); return out; }
    if (!host_path(xtarget, tgt, sizeof tgt)) return NULL;
    mkdirs(out);
    if (build_file(tgt, adds, nadds, out)) { tt_dbg("[HEROES] built %s\n", out); return out; }
    tt_dbg("[HEROES] could not build %s\n", out);
    return NULL;
}

static int ends_with(const char *s, const char *e)
{
    size_t a = strlen(s), b = strlen(e);
    return a >= b && !_stricmp(s + a - b, e);
}

/* ===================================================================== */
/* unlocking the guests one by one                                        */
/* ===================================================================== */
/* Each finish of the Tower of Orthanc (21ORTH2) as Isildur himself counts,
 * per save: 2 unlock Boromir, 3 Gandalf, 4 Frodo, 5 Lurtz. The counts are
 * kept in heroes/unlocks.txt by save folder (UDATA\45410010\<save>). */
static char s_save_key[16];                 /* the save in play */
static int s_isildur_wins = -1;             /* its count, -1 not read */
static int s_orth_pending;                  /* Isildur is playing 21ORTH2 */

static void wins_file(char *out, size_t n) { paths(); snprintf(out, n, "%s/heroes/unlocks.txt", s_dir); }

static int wins_read(const char *key)
{
    char fn[700], line[96], k[32];
    int v, best = 0;
    FILE *f;
    if (!key[0]) return 0;
    wins_file(fn, sizeof fn);
    if (!(f = fopen(fn, "r"))) return 0;
    while (fgets(line, sizeof line, f))
        if (sscanf(line, "%31s %d", k, &v) == 2 && !strcmp(k, key)) best = v;
    fclose(f);
    return best;
}

static void wins_write(const char *key, int v)
{
    char fn[700], tmp[720], line[96], k[32];
    int d;
    FILE *f, *o;
    if (!key[0]) return;
    wins_file(fn, sizeof fn);
    snprintf(tmp, sizeof tmp, "%s.new", fn);
    mkdirs(fn);
    if (!(o = fopen(tmp, "w"))) return;
    if ((f = fopen(fn, "r"))) {
        while (fgets(line, sizeof line, f))
            if (sscanf(line, "%31s %d", k, &d) == 2 && strcmp(k, key)) fprintf(o, "%s %d\n", k, d);
        fclose(f);
    }
    fprintf(o, "%s %d\n", key, v);
    fclose(o);
    remove(fn);
    rename(tmp, fn);
}

static int isildur_wins(void)
{
    if (s_isildur_wins < 0) s_isildur_wins = wins_read(s_save_key);
    return s_isildur_wins;
}

/* guest g's own unlock: Isildur's finishes of the secret level, g + 2 */
static int guest_unlocked(int g)
{
    if (s_test_unlock) return 1;
    return isildur_wins() >= g + 2;
}


/* ===================================================================== */
/* the guests' upgrade-screen pictures                                   */
/* ===================================================================== */
/* UI\upgbigi.BFF and UI\upgradei.BFF hold Isildur's picture (key 0, 512x256
 * DXT1) for the upgrade and results screens. A guest's copy has its left
 * part replaced: a film still from the game's own UI\stills*.BFF (Gandalf,
 * Frodo, Lurtz) or, for Boromir (no still of him), a cameo made from his
 * model's face texture, faded into the background, and the name. */
#include "heroes_names.inc"
typedef struct { const char *stills; uint32_t key; int x0, y0, x1, y1; } UpgSrc;
static const UpgSrc s_upg_src[N_EXTRA] = {
    { NULL, 0, 0, 0, 46, 84 },                           /* Boromir: his face texture */
    { "stills2.BFF", 6, 0, 30, 380, 448 },               /* Gandalf at Saruman's table */
    { "stills1.BFF", 2, 40, 0, 520, 448 },               /* Frodo */
    { "stills2.BFF", 5, 0, 0, 330, 448 },                /* Lurtz */
};
static const struct { const uint8_t *fill, *edge; int w, h; } s_name_img[N_EXTRA] = {
    { s_name_boromir_fill, s_name_boromir_edge, NAME_BOROMIR_W, NAME_BOROMIR_H },
    { s_name_gandalf_fill, s_name_gandalf_edge, NAME_GANDALF_W, NAME_GANDALF_H },
    { s_name_frodo_fill, s_name_frodo_edge, NAME_FRODO_W, NAME_FRODO_H },
    { s_name_lurtz_fill, s_name_lurtz_edge, NAME_LURTZ_W, NAME_LURTZ_H },
};

static void c565(uint16_t c, int *o) { o[0] = ((c >> 11) & 31) * 255 / 31; o[1] = ((c >> 5) & 63) * 255 / 63; o[2] = (c & 31) * 255 / 31; }
/* DXT1 -> 0xRRGGBB */
static void dxt1_decode(const unsigned char *d, int w, int h, uint32_t *out)
{
    int bx, by, i, k;
    for (by = 0; by < h; by += 4)
        for (bx = 0; bx < w; bx += 4, d += 8) {
            uint16_t a = (uint16_t)(d[0] | d[1] << 8), b = (uint16_t)(d[2] | d[3] << 8);
            uint32_t bits = rd32(d, 4), pal[4];
            int ca[3], cb[3], c[3];
            c565(a, ca); c565(b, cb);
            for (k = 0; k < 4; k++) {
                for (i = 0; i < 3; i++) {
                    if (k < 2) c[i] = k ? cb[i] : ca[i];
                    else if (a > b) c[i] = k == 2 ? (2 * ca[i] + cb[i]) / 3 : (ca[i] + 2 * cb[i]) / 3;
                    else c[i] = k == 2 ? (ca[i] + cb[i]) / 2 : 0;
                }
                pal[k] = (uint32_t)c[0] << 16 | (uint32_t)c[1] << 8 | (uint32_t)c[2];
            }
            for (i = 0; i < 16; i++) out[(by + i / 4) * w + bx + i % 4] = pal[(bits >> (2 * i)) & 3];
        }
}
static uint16_t to565(int r, int g, int b) { return (uint16_t)(((r * 31 + 127) / 255) << 11 | ((g * 63 + 127) / 255) << 5 | ((b * 31 + 127) / 255)); }
static void dxt1_encode(const uint32_t *in, int w, int h, unsigned char *d)
{
    int bx, by, i, k;
    for (by = 0; by < h; by += 4)
        for (bx = 0; bx < w; bx += 4, d += 8) {
            uint32_t px[16], bits = 0;
            int lo = 0, hi = 0, lmin = 1 << 30, lmax = -1, ca[3], cb[3], pal[4][3];
            uint16_t a, b;
            for (i = 0; i < 16; i++) {
                uint32_t c = px[i] = in[(by + i / 4) * w + bx + i % 4];
                int l = (int)((c >> 16) & 255) * 3 + (int)((c >> 8) & 255) * 6 + (int)(c & 255);
                if (l < lmin) { lmin = l; lo = i; }
                if (l > lmax) { lmax = l; hi = i; }
            }
            a = to565((px[hi] >> 16) & 255, (px[hi] >> 8) & 255, px[hi] & 255);
            b = to565((px[lo] >> 16) & 255, (px[lo] >> 8) & 255, px[lo] & 255);
            if (a < b) { uint16_t t = a; a = b; b = t; }
            if (a == b) { if (a) b = (uint16_t)(a - 1); else a = 1; }   /* keep the 4-colour mode */
            c565(a, ca); c565(b, cb);
            for (i = 0; i < 3; i++) { pal[0][i] = ca[i]; pal[1][i] = cb[i]; pal[2][i] = (2 * ca[i] + cb[i]) / 3; pal[3][i] = (ca[i] + 2 * cb[i]) / 3; }
            for (i = 0; i < 16; i++) {
                int best = 0, bd = 1 << 30;
                for (k = 0; k < 4; k++) {
                    int dr = (int)((px[i] >> 16) & 255) - pal[k][0], dg = (int)((px[i] >> 8) & 255) - pal[k][1], db = (int)(px[i] & 255) - pal[k][2];
                    int dd = dr * dr + dg * dg + db * db;
                    if (dd < bd) { bd = dd; best = k; }
                }
                bits |= (uint32_t)best << (2 * i);
            }
            d[0] = (unsigned char)a; d[1] = (unsigned char)(a >> 8); d[2] = (unsigned char)b; d[3] = (unsigned char)(b >> 8);
            wr32(d, 4, bits);
        }
}
static uint32_t bilerp(const uint32_t *p, int w, int h, float x, float y)
{
    int x0 = (int)floorf(x), y0 = (int)floorf(y), k, i;
    float fx = x - x0, fy = y - y0, acc[3] = { 0, 0, 0 };
    for (k = 0; k < 4; k++) {
        int xx = x0 + (k & 1), yy = y0 + (k >> 1);
        float wt = ((k & 1) ? fx : 1 - fx) * ((k >> 1) ? fy : 1 - fy);
        uint32_t c;
        if (xx < 0) xx = 0;
        if (yy < 0) yy = 0;
        if (xx >= w) xx = w - 1;
        if (yy >= h) yy = h - 1;
        c = p[yy * w + xx];
        for (i = 0; i < 3; i++) acc[i] += wt * (float)((c >> (16 - 8 * i)) & 255);
    }
    return (uint32_t)acc[0] << 16 | (uint32_t)acc[1] << 8 | (uint32_t)acc[2];
}

#define PIC_W 280
#define PIC_FADE 80
/* the left PIC_W x 256 picture for guest g, or 0 */
static int upg_picture(int g, const char *ui_dir, uint32_t *pic)
{
    const UpgSrc *u = &s_upg_src[g];
    char path[700], hp[700];
    unsigned char *f;
    size_t fl;
    uint32_t off, end, ty;
    int x, y;
    if (u->stills) {
        uint32_t *src;
        float sw = (float)(u->x1 - u->x0), sh = (float)(u->y1 - u->y0), r, ox;
        snprintf(path, sizeof path, "%s\\%s", ui_dir, u->stills);
        if (!host_path(path, hp, sizeof hp) || !(f = read_all(hp, &fl))) return 0;
        if (!res_find(f, fl, u->key, 350, &off, &end, &ty) || off + 0x80 + 640 * 448 * 4 > fl) { free(f); return 0; }
        src = (uint32_t *)malloc(640 * 448 * 4);
        if (!src) { free(f); return 0; }
        for (y = 0; y < 448; y++)
            for (x = 0; x < 640; x++) src[y * 640 + x] = rd32(f, off + 0x80 + (size_t)(y * 640 + x) * 4) & 0xFFFFFFu;
        free(f);
        /* cover: fill PIC_W x 256 from the crop, centred across */
        r = PIC_W / sw > 256.0f / sh ? PIC_W / sw : 256.0f / sh;
        ox = (sw * r - PIC_W) * 0.5f;
        for (y = 0; y < 256; y++)
            for (x = 0; x < PIC_W; x++)
                pic[y * PIC_W + x] = bilerp(src, 640, 448, u->x0 + (x + ox) / r, u->y0 + y / r);
        free(src);
        return 1;
    } else {
        /* Boromir: half a face against his texture's left edge; mirrored
         * into a round cameo on black */
        uint32_t *tex;
        if (!host_path(s_skins[g].src, hp, sizeof hp) || !(f = read_all(hp, &fl))) return 0;
        if (!res_find(f, fl, s_skins[g].tex, 300, &off, &end, &ty) || off + 0x80 + 0x8000 > fl) { free(f); return 0; }
        tex = (uint32_t *)malloc(256 * 256 * 4);
        if (!tex) { free(f); return 0; }
        dxt1_decode(f + off + 0x80, 256, 256, tex);
        free(f);
        for (y = 0; y < 256; y++)
            for (x = 0; x < PIC_W; x++) {
                float cx = 135.0f, cy = 141.0f, R = 82.0f, dx = x - cx, dy = y - cy, d = sqrtf(dx * dx + dy * dy);
                float a = (R - d) / 14.0f;
                uint32_t bgc = 0x0C0A09u, c;
                if (a <= 0) { pic[y * PIC_W + x] = bgc; continue; }
                if (a > 1) a = 1;
                c = bilerp(tex, 256, 256, fabsf(dx) / R * (float)u->x1, (float)u->y0 + (dy / R * 0.5f + 0.5f) * (float)(u->y1 - u->y0));
                pic[y * PIC_W + x] = (uint32_t)(((c >> 16) & 255) * a + 12 * (1 - a)) << 16 | (uint32_t)(((c >> 8) & 255) * a + 10 * (1 - a)) << 8 | (uint32_t)((c & 255) * a + 9 * (1 - a));
            }
        free(tex);
        return 1;
    }
}


/* ===================================================================== */
/* the guest's figure for the upgrade screens                             */
/* ===================================================================== */
/* upgradei.BFF / upgbigi.BFF keys 0x36 / 0x37: Isildur standing, 128 x 256
 * in two DXT5 halves. The guest's in his place: his model drawn here, in
 * its own pose with the arms lowered, lit from the front left. */
static void dxt5_encode(const uint32_t *in, int w, int h, unsigned char *d)
{
    int bx, by;
    for (by = 0; by < h; by += 4)
        for (bx = 0; bx < w; bx += 4, d += 16) {
            uint32_t px[16];
            int i, amin = 255, amax = 0;
            uint64_t bits = 0;
            for (i = 0; i < 16; i++) {
                int a;
                px[i] = in[(by + i / 4) * w + bx + i % 4];
                a = (int)(px[i] >> 24);
                if (a < amin) amin = a;
                if (a > amax) amax = a;
            }
            d[0] = (unsigned char)amax; d[1] = (unsigned char)amin;
            for (i = 0; i < 16; i++) {
                int a = (int)(px[i] >> 24), k, best = 0, bd = 1 << 30;
                for (k = 0; k < 8; k++) {
                    int v = k == 0 ? amax : k == 1 ? amin : (amax == amin ? amax : ((8 - k) * amax + (k - 1) * amin) / 7);
                    int dd = (v - a) * (v - a);
                    if (dd < bd) { bd = dd; best = k; }
                }
                bits |= (uint64_t)best << (3 * i);
            }
            for (i = 0; i < 6; i++) d[2 + i] = (unsigned char)(bits >> (8 * i));
            dxt1_encode(px, 4, 4, d + 8);
        }
}
/* triangles of one strip into img: X, Nv, UV per vertex (already turned) */
typedef struct { float mnx, mxx, mnz, sc, lx, ly, lz; int W, H; uint32_t *img; float *zb; } FigView;
static void fig_strip(const FigView *v, const unsigned char *idx, uint32_t n, uint32_t base, uint32_t nv,
                      const float *X, const float *Nv, const float *UV, const uint32_t *tex, int tw, int th)
{
    uint32_t j;
    int W = v->W, H = v->H;
    for (j = 2; j < n; j++) {
        uint32_t t[3], k;
        float sx[3], sy2[3], sz[3], sh[3], u[3], vv[3], den, minx, maxx, miny, maxy;
        int x, y;
        t[0] = rd16(idx, 2 * (j - 2)); t[1] = rd16(idx, 2 * (j - 1)); t[2] = rd16(idx, 2 * j);
        if (t[0] == t[1] || t[1] == t[2] || t[0] == t[2] || t[0] >= nv || t[1] >= nv || t[2] >= nv) continue;
        for (k = 0; k < 3; k++) {
            const float *p = X + 3 * (base + t[k]), *nn = Nv + 3 * (base + t[k]);
            float d = nn[0] * v->lx + nn[1] * v->ly + nn[2] * v->lz;
            sx[k] = (p[0] - (v->mnx + v->mxx) * 0.5f) * v->sc + W * 0.5f; sy2[k] = H - 4 - (p[2] - v->mnz) * v->sc; sz[k] = -p[1];
            sh[k] = 0.4f + 0.75f * (d > 0 ? d : 0);
            u[k] = UV[2 * (base + t[k])]; vv[k] = UV[2 * (base + t[k]) + 1];
        }
        den = (sy2[1] - sy2[2]) * (sx[0] - sx[2]) + (sx[2] - sx[1]) * (sy2[0] - sy2[2]);
        if (fabsf(den) < 1e-9f) continue;
        minx = fminf(sx[0], fminf(sx[1], sx[2])); maxx = fmaxf(sx[0], fmaxf(sx[1], sx[2]));
        miny = fminf(sy2[0], fminf(sy2[1], sy2[2])); maxy = fmaxf(sy2[0], fmaxf(sy2[1], sy2[2]));
        for (y = (int)fmaxf(0, floorf(miny)); y <= (int)fminf(H - 1, ceilf(maxy)); y++)
            for (x = (int)fmaxf(0, floorf(minx)); x <= (int)fminf(W - 1, ceilf(maxx)); x++) {
                float gx = x + 0.5f, gy = y + 0.5f, w0, w1, w2, z, uu, vq, l;
                uint32_t tc, r, gg, bb;
                w0 = ((sy2[1] - sy2[2]) * (gx - sx[2]) + (sx[2] - sx[1]) * (gy - sy2[2])) / den;
                w1 = ((sy2[2] - sy2[0]) * (gx - sx[2]) + (sx[0] - sx[2]) * (gy - sy2[2])) / den;
                w2 = 1 - w0 - w1;
                if (w0 < 0 || w1 < 0 || w2 < 0) continue;
                z = w0 * sz[0] + w1 * sz[1] + w2 * sz[2];
                if (z <= v->zb[y * W + x]) continue;
                uu = w0 * u[0] + w1 * u[1] + w2 * u[2]; vq = w0 * vv[0] + w1 * vv[1] + w2 * vv[2];
                uu -= floorf(uu); vq -= floorf(vq);
                tc = tex ? tex[((int)(vq * th) % th) * tw + ((int)(uu * tw) % tw)] : 0x909090u;
                l = w0 * sh[0] + w1 * sh[1] + w2 * sh[2];
                r = (uint32_t)fminf(255, ((tc >> 16) & 255) * l); gg = (uint32_t)fminf(255, ((tc >> 8) & 255) * l); bb = (uint32_t)fminf(255, (tc & 255) * l);
                v->zb[y * W + x] = z;
                v->img[y * W + x] = 0xFF000000u | r << 16 | gg << 8 | bb;
            }
    }
}
/* a DXT1 texture resource (header 0x80) decoded, its size in *w, *h; or NULL */
static uint32_t *fig_tex(const unsigned char *T, size_t tl, int *w, int *h)
{
    uint32_t *p;
    if (tl < 0x88) return NULL;
    *w = (int)rd32(T, 4); *h = (int)rd32(T, 8);
    if ((rd32(T, 0xC) & 0xFF) != 0x11 || *w < 4 || *h < 4 || *w > 1024 || *h > 1024 || 0x80 + (size_t)*w * *h / 2 > tl) return NULL;
    if ((p = (uint32_t *)malloc((size_t)*w * *h * 4)) != NULL) dxt1_decode(T + 0x80, *w, *h, p);
    return p;
}
/* vertices a..b-1 (and their normals) turned by an about the unit axis ax through G */
static void fig_turn(float *X, float *Nv, uint32_t a, uint32_t b, const float *G, const float *ax, float an)
{
    float cs = cosf(an), sn = sinf(an);
    uint32_t i;
    for (i = a; i < b; i++) {
        float *pp[2] = { X + 3 * i, Nv + 3 * i };
        int h2, k;
        for (h2 = 0; h2 < 2; h2++) {
            float v[3], cr[3], dt, *p = pp[h2];
            for (k = 0; k < 3; k++) v[k] = h2 ? p[k] : p[k] - G[k];
            cr[0] = ax[1] * v[2] - ax[2] * v[1]; cr[1] = ax[2] * v[0] - ax[0] * v[2]; cr[2] = ax[0] * v[1] - ax[1] * v[0];
            dt = ax[0] * v[0] + ax[1] * v[1] + ax[2] * v[2];
            for (k = 0; k < 3; k++) p[k] = v[k] * cs + cr[k] * sn + ax[k] * dt * (1 - cs) + (h2 ? 0 : G[k]);
        }
    }
}
static uint32_t *figure_render(int g)
{
    char hp[700];
    unsigned char *f, *wf = NULL, *mov = NULL, *tov = NULL;
    const unsigned char *M, *TX, *P = NULL;
    size_t fl, wl = 0, ml, txl, movl = 0, tovl = 0;
    uint32_t mo, me, ao, ae, to, te, ty, nb, mo2, po, vc, vo, ic, io, c, i, nw = 0, pioff = 0, pinb = 0, pa = 0, pe = 0;
    int W = 128, H = 256, tw = 0, th = 0, wtw = 0, wth = 0, hb = -1;
    uint32_t *img = NULL, *tex = NULL, *wtex = NULL;
    float *X = NULL, *zb = NULL, *Nv = NULL, *UV = NULL;
    float (*bp)[3] = NULL;
    int par[256], slot2bone[256];
    const char *ws; uint32_t wm, wt;
    if (!host_path(s_skins[g].src, hp, sizeof hp) || !(f = read_all(hp, &fl))) return NULL;
    if (!res_find(f, fl, s_skins[g].mesh, 100, &mo, &me, &ty) || !res_find(f, fl, s_skins[g].anim, 150, &ao, &ae, &ty)
        || !res_find(f, fl, s_skins[g].tex, 300, &to, &te, &ty)) { free(f); return NULL; }
    /* his model and texture as he plays (Boromir's with his shield) */
    M = f + mo; ml = me - mo; TX = f + to; txl = te - to;
    if ((mov = res_override(f, fl, s_skins[g].mesh, &movl)) != NULL) { M = mov; ml = movl; }
    if ((tov = res_override(f, fl, s_skins[g].tex, &tovl)) != NULL) { TX = tov; txl = tovl; }
    /* skeleton: parents and bind positions */
    nb = rd32(f, ao + 0x48); mo2 = rd32(f, ao + 0x4C); po = rd32(f, ao + 0x50);
    if (nb > 256) goto fail;
    bp = (float (*)[3])calloc(nb, sizeof *bp);
    for (i = 0; i < nb; i++) { par[i] = (int)f[ao + 0x40 + po + i] - 1; memcpy(bp[i], f + ao + 0x40 + mo2 + i * 128 + 28 * 4, 12); }
    /* the mesh's first part: palette, vertices (48 bytes from +0x34), strips (+0x4C) */
    vc = rd32(M, 0x30); vo = rd32(M, 0x38) + 0x34; ic = rd32(M, 0x48); io = rd32(M, 0x4C) + 0x4C; c = rd32(M, 0x50);
    for (i = 0; i < 256; i++) slot2bone[i] = -1;
    for (i = 0; i < c && i < 256; i++) slot2bone[M[0x54 + 2 * i + 1]] = M[0x54 + 2 * i];
    if (vo + vc * 48 > ml || io + ic * 2 > ml) goto fail;
    /* his sword-hand weapon: its prop ("prxb": 32-byte vertices from +0x1000,
     * a strip), at his hand's attach point in the bind pose */
    if (skin_weapon(g, 1, &ws, &wm, &wt) && wm != EMPTY_PROP_KEY && !getenv("TT_NOFIGW")) {
        if (!strcmp(ws, s_skins[g].src)) { wf = NULL; P = f; wl = fl; }
        else if (host_path(ws, hp, sizeof hp) && (wf = read_all(hp, &wl)) != NULL) P = wf;
        hb = (int)skel_point_bone(f + ao, ae - ao, 0);
        if (P && hb >= 0 && hb < (int)nb && res_find(P, wl, wm, 200, &pa, &pe, &ty) && !memcmp(P + pa, "prxb", 4)) {
            pioff = 0x1000 + rd32(P, pa + 0x1F0); pinb = rd32(P, pa + 0x204);
            if (pa + pioff + pinb <= pe && pinb >= 6) {
                for (i = 0; i < pinb / 2; i++) if (rd16(P, pa + pioff + 2 * i) + 1u > nw) nw = rd16(P, pa + pioff + 2 * i) + 1u;
                if (pa + 0x1000 + nw * 32 > pa + pioff) nw = 0;
            }
            if (nw) {
                uint32_t wo, we;
                if (res_find(P, wl, wt, 300, &wo, &we, &ty) && (wtex = fig_tex(P + wo, we - wo, &wtw, &wth)) != NULL && s_skins[g].glow && !getenv("TT_NOTINT"))
                    for (i = 0; i < (uint32_t)(wtw * wth); i++) {   /* Sting's pale blue, as the game's copy */
                        uint32_t q = wtex[i]; int r = (int)((q >> 16) & 255) * 2 / 3 + 6, gg = (int)((q >> 8) & 255) * 7 / 8 + 20, b = (int)(q & 255) + 14;
                        wtex[i] = (uint32_t)(r > 255 ? 255 : r) << 16 | (uint32_t)(gg > 255 ? 255 : gg) << 8 | (uint32_t)(b > 255 ? 255 : b);
                    }
            }
        }
    }
    X = (float *)malloc((vc + nw + 1) * 3 * sizeof(float)); Nv = (float *)malloc((vc + nw + 1) * 3 * sizeof(float)); UV = (float *)malloc((vc + nw + 1) * 2 * sizeof(float));
    img = (uint32_t *)calloc(W * H, 4); zb = (float *)malloc(W * H * sizeof(float));
    tex = fig_tex(TX, txl, &tw, &th);
    if (!X || !Nv || !UV || !tex || !img || !zb) goto fail;
    for (i = 0; i < vc; i++) { memcpy(X + 3 * i, M + vo + i * 48, 12); memcpy(Nv + 3 * i, M + vo + i * 48 + 12, 12); memcpy(UV + 2 * i, M + vo + i * 48 + 24, 8); }
    if (nw) {   /* the hand's bind matrix (rows; the last its place) */
        const unsigned char *B = f + ao + 0x40 + mo2 + (uint32_t)hb * 128 + 64;
        float m[4][3]; int r, k;
        for (r = 0; r < 4; r++) for (k = 0; k < 3; k++) memcpy(&m[r][k], B + (r * 4 + k) * 4, 4);
        for (i = 0; i < nw; i++) {
            float q[8];
            memcpy(q, P + pa + 0x1000 + 32 * i, 32);
            for (k = 0; k < 3; k++) {
                X[3 * (vc + i) + k] = q[0] * m[0][k] + q[1] * m[1][k] + q[2] * m[2][k] + m[3][k];
                Nv[3 * (vc + i) + k] = q[3] * m[0][k] + q[4] * m[1][k] + q[5] * m[2][k];
            }
            UV[2 * (vc + i)] = q[6]; UV[2 * (vc + i) + 1] = q[7];
        }
        for (k = 0; k < 3; k++) { X[3 * (vc + nw) + k] = m[3][k]; Nv[3 * (vc + nw) + k] = 0; }   /* and the grip, unseen */
        UV[2 * (vc + nw)] = UV[2 * (vc + nw) + 1] = 0;
    }
    {   /* the arms down: each arm (from the hand, the leaf farthest out on its
         * side, up to the bone nearest the middle) turned at its shoulder */
        int side;
        for (side = -1; side <= 1; side += 2) {
            int hand = -1, sh = -1, b;
            float best = 0, ang = 1.15f * side, cs = cosf(ang), sn = sinf(ang);
            unsigned char inarm[256];
            for (b = 0; b < (int)nb; b++) {
                int leaf = 1; uint32_t k;
                for (k = 0; k < nb; k++) if (par[k] == b) leaf = 0;
                if (leaf && bp[b][0] * side > best) { best = bp[b][0] * side; hand = b; }
            }
            if (hand < 0) continue;
            for (b = hand; b >= 0 && fabsf(bp[b][0]) >= 0.2f; b = par[b]) sh = b;
            if (sh < 0) continue;
            memset(inarm, 0, sizeof inarm);
            for (b = 0; b < (int)nb; b++) { int q = b; while (q >= 0 && q != sh) q = par[q]; if (q == sh) inarm[b] = 1; }
            for (i = 0; i < vc + (nw ? nw + 1 : 0); i++) {
                float w = 0, s0, w0, s1, w1, px, pz, nx, nz;
                if (i < vc) {
                    const unsigned char *v = M + vo + i * 48;
                    memcpy(&s0, v + 32, 4); memcpy(&w0, v + 36, 4); memcpy(&s1, v + 40, 4); memcpy(&w1, v + 44, 4);
                    if (w0 > 0 && s0 >= 0 && s0 < 768 && slot2bone[(int)s0 / 3] >= 0 && inarm[slot2bone[(int)s0 / 3]]) w += w0;
                    if (w1 > 0 && s1 >= 0 && s1 < 768 && slot2bone[(int)s1 / 3] >= 0 && inarm[slot2bone[(int)s1 / 3]]) w += w1;
                } else if (inarm[hb]) w = 1;   /* the weapon goes with its hand */
                if (w <= 0) continue;
                px = X[3 * i] - bp[sh][0]; pz = X[3 * i + 2] - bp[sh][2];
                X[3 * i] += w * (cs * px + sn * pz - px); X[3 * i + 2] += w * (-sn * px + cs * pz - pz);
                nx = Nv[3 * i]; nz = Nv[3 * i + 2];
                Nv[3 * i] += w * (cs * nx + sn * nz - nx); Nv[3 * i + 2] += w * (-sn * nx + cs * nz - nz);
            }
        }
    }
    if (nw && !getenv("TT_FIGWRAW")) {   /* the weapon hung from the hand: a blade's tip
         * down by his side, a staff upright (its far end turned to t) */
        const float *G = X + 3 * (vc + nw);
        float d[3] = { 0, 0, 0 }, best = -1, t[3], ax[3], cs, sn, an, l;
        int beam = s_skins[g].beam, k;
        for (i = vc; i < vc + nw; i++) {
            float e[3] = { X[3 * i] - G[0], X[3 * i + 1] - G[1], X[3 * i + 2] - G[2] }, q = e[0] * e[0] + e[1] * e[1] + e[2] * e[2];
            if (q > best) { best = q; d[0] = e[0]; d[1] = e[1]; d[2] = e[2]; }
        }
        t[0] = (G[0] > 0 ? 1 : -1) * (beam ? 0.05f : 0.45f); t[1] = beam ? 0.0f : -0.35f; t[2] = beam ? 1.0f : -1.0f;
        l = sqrtf(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]); if (l > 0) for (k = 0; k < 3; k++) d[k] /= l;
        l = sqrtf(t[0] * t[0] + t[1] * t[1] + t[2] * t[2]); for (k = 0; k < 3; k++) t[k] /= l;
        ax[0] = d[1] * t[2] - d[2] * t[1]; ax[1] = d[2] * t[0] - d[0] * t[2]; ax[2] = d[0] * t[1] - d[1] * t[0];
        sn = sqrtf(ax[0] * ax[0] + ax[1] * ax[1] + ax[2] * ax[2]); cs = d[0] * t[0] + d[1] * t[1] + d[2] * t[2];
        an = atan2f(sn, cs);
        if (sn > 1e-6f) { for (k = 0; k < 3; k++) ax[k] /= sn; fig_turn(X, Nv, vc, vc + nw, G, ax, an); }
        {   /* and about its length, the flat of the blade to the front */
            float u[3] = { 0, 0, 0 }, wv[3] = { cosf(0.35f), -sinf(0.35f), 0 }, dt, s2;
            best = -1;
            for (i = vc; i < vc + nw; i++) {
                float e[3] = { X[3 * i] - G[0], X[3 * i + 1] - G[1], X[3 * i + 2] - G[2] }, q;
                dt = e[0] * t[0] + e[1] * t[1] + e[2] * t[2];
                for (k = 0; k < 3; k++) e[k] -= dt * t[k];
                q = e[0] * e[0] + e[1] * e[1] + e[2] * e[2];
                if (q > best) { best = q; u[0] = e[0]; u[1] = e[1]; u[2] = e[2]; }
            }
            dt = wv[0] * t[0] + wv[1] * t[1] + wv[2] * t[2];
            for (k = 0; k < 3; k++) wv[k] -= dt * t[k];
            l = sqrtf(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]); s2 = sqrtf(wv[0] * wv[0] + wv[1] * wv[1] + wv[2] * wv[2]);
            if (l > 1e-6f && s2 > 1e-6f) {
                for (k = 0; k < 3; k++) { u[k] /= l; wv[k] /= s2; }
                if (u[0] * wv[0] + u[1] * wv[1] + u[2] * wv[2] < 0) for (k = 0; k < 3; k++) u[k] = -u[k];
                ax[0] = u[1] * wv[2] - u[2] * wv[1]; ax[1] = u[2] * wv[0] - u[0] * wv[2]; ax[2] = u[0] * wv[1] - u[1] * wv[0];
                sn = ax[0] * t[0] + ax[1] * t[1] + ax[2] * t[2]; cs = u[0] * wv[0] + u[1] * wv[1] + u[2] * wv[2];
                if (!beam) fig_turn(X, Nv, vc, vc + nw, G, t, atan2f(sn, cs));
            }
        }
    }
    {   /* a quarter turn to his left, fitted to the picture */
        float yaw = 0.35f, cy = cosf(yaw), sy = sinf(yaw), mxz = -1e9f, ln;
        FigView v;
        v.mnx = 1e9f; v.mxx = -1e9f; v.mnz = 1e9f; v.lx = 0.45f; v.ly = -0.65f; v.lz = 0.6f; v.W = W; v.H = H; v.img = img; v.zb = zb;
        ln = sqrtf(v.lx * v.lx + v.ly * v.ly + v.lz * v.lz);
        v.lx /= ln; v.ly /= ln; v.lz /= ln;
        for (i = 1; i < vc + nw; i++) {
            float x = X[3 * i], y = X[3 * i + 1];
            X[3 * i] = cy * x - sy * y; X[3 * i + 1] = sy * x + cy * y;
            x = Nv[3 * i]; y = Nv[3 * i + 1];
            Nv[3 * i] = cy * x - sy * y; Nv[3 * i + 1] = sy * x + cy * y;
            if (X[3 * i] < v.mnx) v.mnx = X[3 * i]; if (X[3 * i] > v.mxx) v.mxx = X[3 * i];
            if (X[3 * i + 2] < v.mnz) v.mnz = X[3 * i + 2]; if (X[3 * i + 2] > mxz) mxz = X[3 * i + 2];
        }
        v.sc = (W - 10) / (v.mxx - v.mnx); if ((H - 8) / (mxz - v.mnz) < v.sc) v.sc = (H - 8) / (mxz - v.mnz);
        for (i = 0; i < (uint32_t)(W * H); i++) zb[i] = -1e9f;
        fig_strip(&v, M + io, ic, 0, vc, X, Nv, UV, tex, tw, th);
        if (nw) fig_strip(&v, P + pa + pioff, pinb / 2, vc, nw, X, Nv, UV, wtex, wtw, wth);
    }
    tt_dbg("[HEROES] %s: his figure for the upgrades, %u vertices of weapon on bone %d\n", s_skins[g].name, nw, hb);
    free(X); free(Nv); free(UV); free(tex); free(wtex); free(zb); free(bp); free(wf); free(mov); free(tov); free(f);
    return img;
fail:
    free(X); free(Nv); free(UV); free(tex); free(wtex); free(zb); free(img); free(bp); free(wf); free(mov); free(tov); free(f);
    return NULL;
}
/* the figure into the file image t (keys 0x36 top, 0x37 bottom), if it has them */
static void figure_put(int g, unsigned char *t, size_t tl)
{
    uint32_t o[2], e, ty, *img;
    int h;
    if (!res_find(t, tl, 0x36, 350, &o[0], &e, &ty) || !res_find(t, tl, 0x37, 350, &o[1], &e, &ty)) return;
    for (h = 0; h < 2; h++) if (rd32(t, o[h] + 4) != 128 || rd32(t, o[h] + 8) != 128 || o[h] + 0x80 + 0x4000 > tl) return;
    if (!(img = figure_render(g))) return;
    for (h = 0; h < 2; h++) dxt5_encode(img + h * 128 * 128, 128, 128, t + o[h] + 0x80);
    free(img);
}

/* the guest's copy of an upgrade-picture file (target: host path) */
static int build_upg(int g, const char *target, const char *ui_dir, const char *out, uint32_t pkey)
{
    size_t tl;
    unsigned char *t = read_all(target, &tl);
    uint32_t off, end, ty, *img = NULL, *pic = NULL;
    int x, y, ok = 0;
    FILE *f;
    if (!t || !res_find(t, tl, pkey, 350, &off, &end, &ty) || off + 0x80 + 0x10000 > tl || rd32(t, off + 4) != 512 || rd32(t, off + 8) != 256) goto done;
    img = (uint32_t *)malloc(512 * 256 * 4);
    pic = (uint32_t *)malloc(PIC_W * 256 * 4);
    if (!img || !pic) goto done;
    dxt1_decode(t + off + 0x80, 512, 256, img);
    if (!upg_picture(g, ui_dir, pic)) goto done;
    for (y = 0; y < 256; y++)
        for (x = 0; x < PIC_W; x++) {
            float a = x < PIC_W - PIC_FADE ? 1.0f : (float)(PIC_W - x) / PIC_FADE, dk;
            uint32_t b = img[y * 512 + x], c = pic[y * PIC_W + x], o = 0;
            int k;
            a = a * a * (3 - 2 * a);
            dk = 0.25f + 0.75f * (1 - a);   /* Isildur behind the fade: darkened */
            for (k = 0; k < 3; k++) {
                float v = (float)((c >> (16 - 8 * k)) & 255) * a + (float)((b >> (16 - 8 * k)) & 255) * dk * (1 - a);
                o |= (uint32_t)(v > 255 ? 255 : v) << (16 - 8 * k);
            }
            img[y * 512 + x] = o;
        }
    {   /* the name: cream letters with a dark edge, where Isildur's was */
        int nw = s_name_img[g].w, nh = s_name_img[g].h, X0 = 32, Y0 = 0;
        for (y = 0; y < nh && Y0 + y < 256; y++)
            for (x = 0; x < nw && X0 + x < 512; x++) {
                uint32_t *p = &img[(Y0 + y) * 512 + X0 + x];
                float e = s_name_img[g].edge[y * nw + x] / 255.0f, fl = s_name_img[g].fill[y * nw + x] / 255.0f;
                int k;
                uint32_t o = 0;
                static const int dark[3] = { 20, 12, 6 }, cream[3] = { 238, 228, 200 };
                for (k = 0; k < 3; k++) {
                    float v = (float)((*p >> (16 - 8 * k)) & 255);
                    v = v * (1 - e) + dark[k] * e;
                    v = v * (1 - fl) + cream[k] * fl;
                    o |= (uint32_t)v << (16 - 8 * k);
                }
                *p = o;
            }
    }
    dxt1_encode(img, 512, 256, t + off + 0x80);
    if (!getenv("TT_NOFIG")) figure_put(g, t, tl);
    mkdirs(out);
    if ((f = fopen(out, "wb"))) { ok = fwrite(t, 1, tl, f) == tl; fclose(f); if (!ok) remove(out); }
done:
    free(img); free(pic); free(t);
    return ok;
}

/* The guest's copies of the pictures that name hero 4: the upgrade screens
 * (upgbigi.BFF, upgradei.BFF: picture key 0) and the mission results
 * (endlvl.BFF: key 3, Isildur's of the four). upgbigi.BFF also has the 3D
 * figure that shows the moves (Isildur's: mesh 1050 / texture 1150 key 9,
 * on the heroes' skeleton): his model, re-rigged, in its place. */
#define UPG_FIG_KEY 9u
static const char *upg_redirect(const char *xp, const char *base)
{
    static char out[700];
    char tgt[700], dir[600], tmp[720];
    const char *sl;
    FILE *f;
    int g = s_guest, end = !_stricmp(base, "endlvl.BFF"), fig = !_stricmp(base, "upgbigi.BFF");
    if (g < 0 || g >= N_EXTRA || (G8(HERO_BYTE) != 4 && !getenv("TT_UPG_SELFTEST"))) return NULL;
    paths();
    snprintf(out, sizeof out, "%s/heroes/%s/upg%u/%s", s_dir, s_skins[g].name, HEROES_BUILD, base);
    if ((f = fopen(out, "rb"))) { fclose(f); return out; }
    if (!host_path(xp, tgt, sizeof tgt)) return NULL;
    sl = strrchr(xp, '\\');
    snprintf(dir, sizeof dir, "%.*s", (int)(sl ? sl - xp : 0), xp);
    snprintf(tmp, sizeof tmp, "%s.tmp", out);
    if (!build_upg(g, tgt, dir, fig ? tmp : out, end ? 3u : 0u)) { tt_dbg("[HEROES] could not build %s\n", out); return NULL; }
    if (fig && !getenv("TT_NOUPGFIG")) {
        Add a[4];
        int na = 2;
        const char *ws; uint32_t wm, wt;
        memset(a, 0, sizeof a);
        a[0].src = s_skins[g].src; a[0].src_key = s_skins[g].mesh; a[0].type = 1050; a[0].key = UPG_FIG_KEY;
        a[0].map = s_skins[g].map; a[0].nmap = s_skins[g].nmap;
        a[1].src = s_skins[g].src; a[1].src_key = s_skins[g].tex; a[1].type = 1150; a[1].key = UPG_FIG_KEY;
        if (skin_weapon(g, 1, &ws, &wm, &wt) && wm != EMPTY_PROP_KEY && !getenv("TT_NOMENUWEAPON")) {   /* his weapon in the figure's hand (Isildur's sword, key 10) */
            a[2].src = ws; a[2].src_key = wm; a[2].type = 1200; a[2].key = UPG_FIG_KEY + 1;
            a[3].src = ws; a[3].src_key = wt; a[3].type = 1250; a[3].key = UPG_FIG_KEY + 1; a[3].tint = s_skins[g].glow && !getenv("TT_NOTINT");
            na = 4;
        }
        s_remap_noshadow = 1;
        f = NULL;
        if (!build_file(tmp, a, na, out)) { s_remap_noshadow = 0; remove(tmp); tt_dbg("[HEROES] could not build %s\n", out); return NULL; }
        s_remap_noshadow = 0;
        remove(tmp);
    } else if (fig) rename(tmp, out);
    tt_dbg("[HEROES] built %s\n", out);
    return out;
}

static void tt_ct_arm(const char *xp);
static const char *redirect(const char *xp)
{
    tt_ct_arm(xp);
    char x[600], base[128];
    const char *b;
    int sk, g;
    b = strrchr(xp, '\\'); b = b ? b + 1 : xp;
    snprintf(base, sizeof base, "%s", b);
    /* the save being loaded or written: ...\UDATA\45410010\<save>\game.xsv */
    if (!_stricmp(base, "game.xsv")) {
        const char *u = strstr(xp, "45410010\\");
        if (u) {
            char key[16];
            size_t i;
            u += 9;
            for (i = 0; i < sizeof key - 1 && u[i] && u[i] != '\\'; i++) key[i] = u[i];
            key[i] = 0;
            if (strcmp(key, s_save_key)) {
                snprintf(s_save_key, sizeof s_save_key, "%s", key);
                s_isildur_wins = -1;
                tt_dbg("[HEROES] save %s: Isildur has finished the Tower of Orthanc %d time(s)\n", s_save_key, isildur_wins());
            }
        }
        return NULL;
    }
    /* the character select: the extra heroes' models, keys 0x21.. as
     * mesh 1050, animations 1100, texture 1150 (the menu's own types) */
    if (ends_with(xp, "\\mainmenu.bff") && tt_heroes_on()) {
        /* each on his own skeleton with his own stance, pose and move
         * (TT_REMAP=1: re-rigged, with Aragorn's) */
        const int nat = !getenv("TT_REMAP");
        Add a[5 * N_EXTRA];
        const char *r;
        int na = 0;
        memset(a, 0, sizeof a);
        for (g = 0; g < N_EXTRA; g++) {
            a[na].src = s_skins[g].src; a[na].src_key = s_skins[g].mesh; a[na].type = 1050; a[na].key = FE_KEY(g);
            if (!nat) { a[na].map = s_skins[g].map; a[na].nmap = s_skins[g].nmap; }
            else { a[na].map = s_idmap; a[na].nmap = 256; }   /* his own bones: only the leftover indices made safe */
            na++;
            a[na].src = s_skins[g].src; a[na].src_key = s_skins[g].tex;  a[na].type = 1150; a[na].key = FE_KEY(g); na++;
            if (nat) { a[na].src = s_skins[g].src; a[na].src_key = s_skins[g].anim; a[na].type = 1100; a[na].key = FE_KEY(g); a[na].compose = getenv("TT_MENU_PLAIN") ? 0 : g + 1; na++; }
        }
        for (g = 0; g < N_EXTRA; g++) {   /* and his weapon, for his hand there too (after the models) */
            const char *ws; uint32_t wm, wt;
            if (getenv("TT_MENUWMASK") && !((atoi(getenv("TT_MENUWMASK")) >> g) & 1)) continue;   /* testing */
            if (skin_weapon(g, 1, &ws, &wm, &wt) && wm != EMPTY_PROP_KEY && !getenv("TT_NOMENUWEAPON")) {
                a[na].src = ws; a[na].src_key = wm; a[na].type = 1200; a[na].key = FE_WKEY(g); na++;
                a[na].src = ws; a[na].src_key = wt; a[na].type = 1250; a[na].key = FE_WKEY(g); a[na].tint = s_skins[g].glow && !getenv("TT_NOTINT"); na++;
            }
        }
        s_compose_menu = 1;
        {   /* named by this rebuild's version (the guests' models and moves in it) */
            char sub[32];
            snprintf(sub, sizeof sub, "%s%u%s%s", nat ? (getenv("TT_MENU_PLAIN") ? "menup" : "menu") : "menur", HEROES_BUILD, getenv("TT_MENUWMASK") ? "m" : "", getenv("TT_MENUWMASK") ? getenv("TT_MENUWMASK") : "");
            r = cached(sub, xp, "mainmenu.BFF", a, na);
        }
        s_compose_menu = 0;
        s_fe_native = nat;
        return r;
    }
    if (tt_heroes_on() && (!_stricmp(base, "upgbigi.BFF") || !_stricmp(base, "upgradei.BFF") || !_stricmp(base, "endlvl.BFF"))) return upg_redirect(xp, base);
    if (!strstr(xp, "orlds\\") && !strstr(xp, "ORLDS\\")) return NULL;
    sk = -1;
    if (ends_with(xp, ".bfi") && G8(HERO_BYTE) == 4) sk = s_guest;
    else if (ends_with(xp, ".bfa") && G8(HERO_BYTE) == 1) sk = playas();
    if (sk < 0) return NULL;
    {
        /* re-rigged guests keep the hero's animations; others bring theirs */
        /* the guest plays on his own skeleton with his own motions (see
         * compose_anims); TT_REMAP=1: on the hero's, with the hero's */
        const int nat = sk == s_guest && sk < N_EXTRA && !getenv("TT_REMAP");
        const int gv = !nat && sk == s_guest && s_skins[sk].lvar != NULL;   /* another hero's variant */
        s_native = nat;
        Add a[12] = { { s_skins[sk].src, s_skins[sk].mesh, 100, s_skins[sk].mesh, gv ? s_skins[sk].lmap : s_skins[sk].map, gv ? s_skins[sk].nlmap : s_skins[sk].nmap },
                     { s_skins[sk].src, s_skins[sk].tex,  300, s_skins[sk].tex, NULL, 0 },
                     { s_skins[sk].src, s_skins[sk].anim, 150, s_skins[sk].anim, NULL, 0 } };
        char sub[64];
        int na = (s_skins[sk].map && !nat && !getenv("TT_ADDANIM")) ? 2 : 3;
        if (nat) { a[0].map = s_idmap; a[0].nmap = 256; a[2].compose = sk + 1; }
        {   /* his weapons: model (a prop) and texture */
            int sl;
            for (sl = 0; sl < 3; sl++) {
                const char *ws; uint32_t wm, wt;
                if (sl == 2) { if (!s_skins[sk].xmesh || getenv("TT_NOWEAPON")) continue; ws = s_skins[sk].xsrc; wm = s_skins[sk].xmesh; wt = s_skins[sk].xtex; }
                else if (!skin_weapon(sk, sl, &ws, &wm, &wt)) continue;
                a[na].src = ws; a[na].src_key = a[na].key = wm; a[na].type = 200; a[na].map = NULL; a[na].nmap = 0; a[na].empty = 0;
                if (wm == EMPTY_PROP_KEY) { a[na].src_key = s_skins[sk].wmesh; a[na].empty = 1; }
                na++;
                {   /* one weapon for both hands (Gandalf's staff): once */
                    int q, dup = 0;
                    for (q = 3; q < na - 1; q++) if (a[q].type == 200 && a[q].key == wm) dup = 1;
                    if (dup) { na--; continue; }
                }
                {   /* a texture once */
                    int q, dup = 0;
                    for (q = 3; q < na; q++) if (a[q].type == 300 && a[q].key == wt) dup = 1;
                    if (dup) continue;
                }
                a[na].src = ws; a[na].src_key = a[na].key = wt; a[na].type = 300; a[na].map = NULL; a[na].nmap = 0; a[na].empty = 0;
                a[na].tint = sl == 1 && s_skins[sk].glow && !getenv("TT_NOTINT"); na++;
                if (weapon_tex2(wm)) { a[na].src = ws; a[na].src_key = a[na].key = weapon_tex2(wm); a[na].type = 300; a[na].map = NULL; a[na].nmap = 0; a[na].empty = 0; na++; }
            }
        }
        snprintf(x, sizeof x, "%.*s%s", (int)(strlen(xp) - 4), xp, gv ? s_skins[sk].lvar : ".bfa");
        s_remap_noshadow = gv;   /* (torn volumes on Gimli's skeleton too) */   /* Aragorn's variant (or Gimli's) */
        base[strlen(base) - 4] = 0;
        strcat(base, ends_with(xp, ".bfi") ? ".bfi" : ".bfa");
        /* the cache folder names what went into the file, so a changed
         * skin (or this rebuild's version) never picks up a stale one */
        if (s_skins[sk].map)
            snprintf(sub, sizeof sub, "%s%s_%08X", s_skins[sk].name, nat ? "_own" : "",
                     (s_skins[sk].mesh ^ s_skins[sk].tex * 3u ^ s_skins[sk].wmesh * 5u ^ s_skins[sk].wtex * 7u ^ s_skins[sk].w2mesh * 17u ^ s_skins[sk].xmesh * 23u ^ (uint32_t)na * 11u ^ (uint32_t)gv * 13u ^ (uint32_t)nat * 19u) + HEROES_BUILD + anims_hash(sk));
        else snprintf(sub, sizeof sub, "%s", s_skins[sk].name);
        return cached(sub, x, base, a, na);
    }
}

/* ===================================================================== */
/* the hero's name in the game's text                                    */
/* ===================================================================== */
/* startup.BFF's names, UTF-16: "Aragorn", "Legolas", "Gimli", then 12 bytes
 * on "Isildur" -- the fourth hero's, shown on the character select, the
 * mission map and the upgrade screen. Found once, rewritten as hero 4
 * changes hands. */
static uint32_t s_name_at[8];
static int s_nname = -1;
static char s_name_cur[8] = "Isildur";   /* what the tables say now */
static int u16_is(uint32_t va, const char *t, int term)
{
    int i;
    for (i = 0; t[i]; i++) if (G16(va + 2 * i) != (uint16_t)t[i]) return 0;
    return !term || G16(va + 2 * i) == 0;
}
static void name_find(void)
{
    uint32_t va;
    s_nname = 0;
    /* after "Gimli": "Isildur" (the hero lists) or "Play as Isildur" (the
     * level map's line for Isildur's level) -- only the name is changed */
    const volatile uint16_t *m = (const volatile uint16_t *)xbox_GetMemoryOffset();
    for (va = 0x10000u; va < 0x84000000u - 64 && s_nname < 8; va += 2) {
        if (va == 0x03FF0000u) va = 0x80000000u;
        if (m[va / 2] != 'G' || m[va / 2 + 1] != 'i' || !u16_is(va, "Gimli", 1)) continue;
        if (u16_is(va + 12, "Isildur", 1) || u16_is(va + 12, s_name_cur, 1)) s_name_at[s_nname++] = va + 12;
        else if (u16_is(va + 12, "Play as ", 0) && (u16_is(va + 28, "Isildur", 1) || u16_is(va + 28, s_name_cur, 1))) s_name_at[s_nname++] = va + 28;
    }
    tt_dbg("[HEROES] %d name tables\n", s_nname);
}
static void name_set(const char *title)
{
    int k, i, end;
    if (s_nname < 0) name_find();
    for (k = 0; k < s_nname; k++) {
        uint32_t q = s_name_at[k];
        /* still ours? (a menu file reloaded since puts other data there) */
        if (!u16_is(q, "Isildur", 1) && !u16_is(q, s_name_cur, 1)) continue;
        for (i = 0, end = 0; i < 8; i++) {   /* 7 letters at most, then the end */
            if (i == 7 || !title[i]) end = 1;
            G16(q + 2 * i) = end ? 0 : (uint16_t)title[i];
        }
    }
    snprintf(s_name_cur, sizeof s_name_cur, "%s", title);
}

/* ===================================================================== */
/* hero 4's records, one set per extra hero                              */
/* ===================================================================== */
/* What the save keeps per hero (0x000D2000 / 0x000D2130), for hero 4: */
typedef struct { uint32_t va, len; } Span;
static const Span s_rec[] = {
    { 0x4AB69Eu + 3 * 15, 15 },            /* levels open / done */
    { 0x4AB6DCu + 3 * 15 * 8, 15 * 8 },    /* per-level scores */
    { 0x4AB8BCu + 4 * 4, 4 },
    { 0x4AB944u + 3 * 0x348, 0x348 },      /* experience, upgrade points, ... */
    { 0x4AC600u + 3 * 0x50, 0x50 },        /* upgrades bought */
};
#define REC_BYTES (15 + 120 + 4 + 0x348 + 0x50)
static unsigned char s_recs[N_EXTRA + 1][REC_BYTES];   /* [0..3] extra heroes, [4] Isildur */
static int s_rec_have[N_EXTRA + 1];
static int s_rec_owner = -1;                           /* whose records hero 4 holds now: -1 Isildur */

static void rec_copy(unsigned char *buf, int to_mem)
{
    size_t o = 0, k, i;
    for (k = 0; k < sizeof s_rec / sizeof s_rec[0]; k++)
        for (i = 0; i < s_rec[k].len; i++, o++) {
            if (to_mem) G8(s_rec[k].va + i) = buf[o];
            else buf[o] = G8(s_rec[k].va + i);
        }
}
static void rec_save_file(void)
{
    char p[600];
    FILE *f;
    paths();
    snprintf(p, sizeof p, "%s/heroes/records.dat", s_dir);
    mkdirs(p);
    if ((f = fopen(p, "wb"))) {
        fwrite("TTH1", 1, 4, f);
        fwrite(s_rec_have, sizeof s_rec_have, 1, f);
        fwrite(s_recs, sizeof s_recs, 1, f);
        fclose(f);
    }
}
static void rec_load_file(void)
{
    char p[600], m[4];
    FILE *f;
    static int done;
    if (done) return;
    done = 1;
    paths();
    snprintf(p, sizeof p, "%s/heroes/records.dat", s_dir);
    if ((f = fopen(p, "rb"))) {
        if (fread(m, 1, 4, f) == 4 && !memcmp(m, "TTH1", 4)) {
            if (fread(s_rec_have, sizeof s_rec_have, 1, f) != 1 || fread(s_recs, sizeof s_recs, 1, f) != 1)
                memset(s_rec_have, 0, sizeof s_rec_have);
        }
        fclose(f);
    }
    s_rec_have[N_EXTRA] = 0;    /* Isildur's are the save's */
}
/* hero 4 becomes guest g (-1 Isildur): the holder's records out, g's in */
static void rec_switch(int g)
{
    int slot = g < 0 ? N_EXTRA : g, old;
    rec_load_file();
    if (s_rec_owner == g) return;
    old = s_rec_owner < 0 ? N_EXTRA : s_rec_owner;
    rec_copy(s_recs[old], 0); s_rec_have[old] = 1;
    if (s_rec_have[slot]) rec_copy(s_recs[slot], 1);
    else {
        /* first time: a new hero -- level 1, nothing bought; the missions
         * open to him are the ones open to anyone */
        unsigned char fresh[REC_BYTES];
        int lv;
        memcpy(fresh, s_recs[old], REC_BYTES);
        memset(fresh + 15, 0, 120);                                  /* no scores */
        memset(fresh + 15 + 120 + 4, 0, 0x348);                      /* no experience */
        memset(fresh + 15 + 120 + 4 + 0x348, 0, 0x50);               /* nothing bought */
        for (lv = 0; lv < 15; lv++) if (fresh[lv] > 1) fresh[lv] = 1;   /* open, not done */
        rec_copy(fresh, 1);
    }
    s_rec_owner = g;
    rec_save_file();
    tt_dbg("[HEROES] hero 4 is now %s\n", g < 0 ? "Isildur" : s_skins[g].name);
}
static int s_rec_saving_owner = -2;

/* ===================================================================== */
/* the level: point the hero's keys at the skin's                         */
/* ===================================================================== */
static uint32_t s_buf;     /* the level file in guest memory */

static int find_level_buffer(void)
{
    uint32_t va;
    /* the directory's first entry is {400, 8, 0}; the file starts n bytes
     * before its count, with version 9 and n at +4 */
    for (va = 0x80000000u; va < 0x83FFFF00u; va += 4) {
        uint32_t base;
        if (G32(va + 4) != 400u || G32(va + 8) != 8u || G32(va + 12) != 0u) continue;
        for (base = va & ~0xFFFu; base >= 0x80000000u && va - base < 0x2000000u; base -= 0x1000u)
            if (G8(base) == 9 && G32(base + 4) == va - base) { s_buf = base; return 1; }
    }
    return 0;
}
static int cmp_key(const void *a, const void *b)
{
    uint32_t x = *(const uint32_t *)a, y = *(const uint32_t *)b;
    return x < y ? -1 : x > y;
}
static uint32_t key_type(uint32_t (*t)[2], uint32_t n, uint32_t key)
{
    uint32_t lo = 0, hi = n;
    if (!key) return 0;
    while (lo < hi) {
        uint32_t m = (lo + hi) / 2;
        if (t[m][0] < key) lo = m + 1; else if (t[m][0] > key) hi = m; else return t[m][1];
    }
    return 0;
}
/* the hero's placement record -- {mesh 100, anim 150, tex 300} after a
 * name with "Hero" in it -- and every reference to its keys -> the skin's */
static void skin_apply(void)
{
    int sk = active_skin();
    uint32_t n, cnt, i, va, hero[3] = { 0, 0, 0 }, to[3];
    static uint32_t keyt[4096][2];
    uint32_t nk;
    if (sk < 0 || !find_level_buffer()) return;
    n = G32(s_buf + 4); cnt = G32(s_buf + n);
    nk = cnt < 4096 ? cnt : 4096;
    for (i = 0; i < nk; i++) { keyt[i][0] = G32(s_buf + n + 4 + 12 * i + 8); keyt[i][1] = G32(s_buf + n + 4 + 12 * i); }
    qsort(keyt, nk, sizeof keyt[0], cmp_key);
    for (va = s_buf + 8; va + 12 < s_buf + n && !hero[0]; va += 4) {
        uint32_t a = G32(va), b, c, j;
        if (key_type(keyt, nk, a) != 100) continue;
        b = G32(va + 4); c = G32(va + 8);
        if (key_type(keyt, nk, b) != 150 || key_type(keyt, nk, c) != 300) continue;
        for (j = 4; j < 0x80 && !hero[0]; j++) {
            char nm[40];
            uint32_t q = va - j, z;
            if (G8(q) < 'A' || G8(q - 1) != 0) continue;
            for (z = 0; z < 39 && G8(q + z) >= 32 && G8(q + z) < 127; z++) nm[z] = (char)G8(q + z);
            nm[z] = 0;
            if (z >= 4 && (strstr(nm, "Hero") || strstr(nm, "hero"))) {
                hero[0] = a; hero[1] = b; hero[2] = c;
                tt_dbg("[HEROES] hero record \"%s\": mesh %08X anim %08X tex %08X\n", nm, a, b, c);
            }
        }
    }
    if (!hero[0]) { tt_dbg("[HEROES] no hero record found\n"); return; }
    to[0] = s_skins[sk].mesh; to[1] = (s_skins[sk].map && !s_native) ? hero[1] : s_skins[sk].anim; to[2] = s_skins[sk].tex;
    {
        int hits = 0;
        for (va = s_buf + 8; va + 4 <= s_buf + n; va += 4) {
            uint32_t v = G32(va), k;
            for (k = 0; k < 3; k++) if (v == hero[k]) { G32(va) = to[k]; hits++; break; }
        }
        tt_dbg("[HEROES] %s: %d references swapped\n", s_skins[sk].name, hits);
    }
    /* his own weapon: the hero's weapon records ("weaponObjNN", 0x16 bytes
     * of header, position at +0x28, model key +0x40, texture +0x50) that
     * stand where a hero record does hold Aragorn's bow or sword; the one
     * for his hand becomes his */
    if (s_skins[sk].wmesh || s_skins[sk].w2mesh) {
        static const uint32_t hand_key[2] = { 0x36AC3F58u, 0x4586A62Cu };   /* Aragorn's bow, sword */
        float hx[8], hy[8];
        int nh = 0, swapped = 0;
        for (va = s_buf + 8; va + 0x60 < s_buf + n && nh < 8; va += 4) {
            char nm[40];
            uint32_t z;
            if (G32(va) != 1 || G32(va + 4) != 0x20) continue;
            for (z = 0; z < 39 && G8(va + 8 + z) >= 32 && G8(va + 8 + z) < 127; z++) nm[z] = (char)G8(va + 8 + z);
            nm[z] = 0;
            if (z >= 4 && strstr(nm, "Hero")) { hx[nh] = GF(va + 0x2C); hy[nh] = GF(va + 0x30); nh++; }
        }
        for (va = s_buf + 8; va + 0x60 < s_buf + n; va += 4) {
            int h;
            if (G32(va) != 0x16 || G32(va + 4) != 0x20 || G32(va + 8) != 0x70616577u /* "weap" */) continue;
            const char *ws; uint32_t wm, wt; int sl;
            for (sl = 0; sl < 2 && G32(va + 0x40) != hand_key[sl]; sl++) ;
            if (sl == 2 && G32(va + 0x40) == 0x13F82514u && !getenv("TT_NOSWORD2")) sl = 1;   /* the sword drawn in his hand */
            if (sl == 2 || !skin_weapon(sk, sl, &ws, &wm, &wt)) continue;
            for (h = 0; h < nh; h++)
                if (fabsf(GF(va + 0x28) - hx[h]) < 0.01f && fabsf(GF(va + 0x2C) - hy[h]) < 0.01f) {
                    G32(va + 0x40) = wm; G32(va + 0x50) = wt; swapped++;
                    break;
                }
        }
        tt_dbg("[HEROES] %s: his weapon in %d weapon record(s) (%d hero records)\n", s_skins[sk].name, swapped, nh);
    }
}

/* TT_KEYSWAP="A=B,C=D" (testing): every aligned dword equal to key A in
 * the contiguous window becomes B, but for the resource directories */
static void keyswap_apply(void)
{
    const char *e = getenv("TT_KEYSWAP");
    uint32_t from[16], to[16], va;
    int n = 0, hits = 0, i;
    if (!e) return;
    while (*e && n < 16) {
        char *q;
        from[n] = (uint32_t)strtoul(e, &q, 16);
        if (*q != '=') break;
        to[n] = (uint32_t)strtoul(q + 1, &q, 16);
        n++;
        e = (*q == ',') ? q + 1 : q;
        if (!*q) break;
    }
    for (va = 0x80000000u; va < 0x84000000u; va += 4) {
        uint32_t v = G32(va);
        for (i = 0; i < n; i++)
            if (v == from[i]) {
                if (G32(va + 4) < 1000u && G32(va - 4) < 0x2000000u && (G32(va - 4) & 0x7Fu) == 0) break;
                G32(va) = to[i]; hits++; break;
            }
    }
    tt_dbg("[KEYSWAP] %d keys, %d places\n", n, hits);
}

/* ===================================================================== */
/* the character select                                                   */
/* ===================================================================== */
#define FE_MGR   0x49F440u     /* the menu's character manager: [0] array (0x1E0 each), [8] room (8) */
#define FE_TEXT  0x49FBE0u
#define N_PLACES (4 + N_EXTRA)
static int s_fe_extra = 0;               /* extra characters created (actors 4..) */
static uint32_t s_fe_last_args[4];       /* the fourth retail character's resources */
static uint32_t s_fe_anim0;              /* the first one's (Aragorn's) animation set */
static int s_spawning;
static int s_spawn_pending;               /* the menu's fourth character exists, ours not yet */
static int s_cursor = -1;                /* our place, 0..7 (the game's [menu+0x18] is min(this, 3)) */
static float s_ang[N_PLACES];            /* current angle, radians */
static int s_ang_ok;
static uint32_t s_actor[N_PLACES];       /* the characters' records in the manager, by creation */

/* The manager finds a character by the number in its record (+0x1B8), and
 * the game's own code (the "level" labels, the chosen pose, the confirm move)
 * works on character 3 for hero 4.  So the guest who is hero 4 takes number 3
 * and Isildur takes the guest's. */
static void hero4_actor(int g)
{
    int e;
    if (!s_actor[3]) return;
    G32(s_actor[3] + 0x1B8) = g < 0 ? 3u : (uint32_t)(4 + g);
    for (e = 0; e < N_EXTRA; e++)
        if (s_actor[4 + e]) G32(s_actor[4 + e] + 0x1B8) = e == g ? 3u : (uint32_t)(4 + e);
}
/* the number place p's character answers to now */
static uint32_t aid(int p) { return s_actor[p] ? G32(s_actor[p] + 0x1B8) : (uint32_t)p; }

static void fe_spawn_extras(void)
{
    int g;
    s_fe_extra = 0;
    s_spawning = 1;
    static int own_anim = -1;   /* testing: TT_FE_OWNANIM, the menu file's own animation sets */
    uint32_t mesh[N_EXTRA], anim[N_EXTRA], tex[N_EXTRA], wmesh = 0, wtex = 0, gwm[N_EXTRA], gwt[N_EXTRA];
    const volatile uint32_t *w = (const volatile uint32_t *)(xbox_GetMemoryOffset() + 0x80000000u);
    const uint32_t nw = (0x04000000u - 0x20u) / 4u, KEY0 = FE_KEY(0);
    uint32_t i, nearp = s_fe_last_args[1];
    const int fewlog = getenv("TT_FEWLOG") != NULL;
    /* several copies can be in memory (an earlier menu's, not cleared): the
     * one nearest the fourth retail character's model is this menu's */
#define IS_PROP(d) ((d) >= 0x80000000u && (d) < 0x83FFFFF0u && (w[((d) - 0x80000000u) / 4u] == PROP_MAGIC \
    || (w[((d) - 0x80000000u) / 4u] >= 0x80000000u && w[((d) - 0x80000000u) / 4u] < 0x83FFFFF0u && w[(w[((d) - 0x80000000u) / 4u] - 0x80000000u) / 4u] == PROP_MAGIC)))
#define CLOSER(cur, va) (!(cur) || (((va) > nearp ? (va) - nearp : nearp - (va)) < ((cur) > nearp ? (cur) - nearp : nearp - (cur))))
    if (own_anim < 0) own_anim = getenv("TT_FE_OWNANIM") != NULL;
    memset(mesh, 0, sizeof mesh); memset(anim, 0, sizeof anim); memset(tex, 0, sizeof tex); memset(gwm, 0, sizeof gwm); memset(gwt, 0, sizeof gwt);
    /* the menu file's resource objects, wherever the loader put them in the
     * contiguous window: meshes and animation sets {0, key, 0, data} (data
     * "\x20XBG" / "aniz"), textures {0x1709C4, 0, key, 0, data} */
    for (i = 0; i < nw; i++) {
        uint32_t k = w[i + 1] - KEY0, d;
        /* Aragorn's sword on the character select: model and texture key 2 */
        if (w[i] == 0 && w[i + 1] == MENU_SWORD_KEY && w[i + 2] == 0 && w[i + 3] >= 0x80000000u && w[i + 3] < 0x83FFFFF0u
            && (w[(w[i + 3] - 0x80000000u) / 4u] == 0x47425820u || IS_PROP(w[i + 3]))) { uint32_t va = 0x80000000u + i * 4u; if (CLOSER(wmesh, va)) wmesh = va; }
        /* each guest's own weapon: prop and texture keys FE_WKEY(g) */
        {
            uint32_t kw = w[i + 1] - FE_WKEY(0), kt = w[i + 2] - FE_WKEY(0);
            if (fewlog && w[i] == 0 && (kw < N_EXTRA || w[i + 1] == MENU_SWORD_KEY) && w[i + 2] == 0 && w[i + 3] >= 0x80000000u && w[i + 3] < 0x83FFFFF0u)
                tt_dbg("[HEROES] fe weapon? key %X at %08X data %08X magic %08X %08X\n", w[i + 1], 0x80000000u + i * 4u, w[i + 3], w[(w[i + 3] - 0x80000000u) / 4u], w[(w[i + 3] - 0x80000000u) / 4u + 1]);
            if (w[i] == 0 && kw < N_EXTRA && w[i + 2] == 0 && IS_PROP(w[i + 3])) { uint32_t va = 0x80000000u + i * 4u; if (CLOSER(gwm[kw], va)) gwm[kw] = va; }
            if (w[i] == 0x001709C4u && w[i + 1] == 0 && kt < N_EXTRA && w[i + 4] >= 0x80000000u && w[i + 4] < 0x84000000u)
                { uint32_t va = 0x80000000u + i * 4u; if (CLOSER(gwt[kt], va)) gwt[kt] = va; }
        }
        if (w[i] == 0x001709C4u && w[i + 1] == 0 && w[i + 2] == MENU_SWORD_KEY && w[i + 4] >= 0x80000000u && w[i + 4] < 0x84000000u)
            { uint32_t va = 0x80000000u + i * 4u; if (CLOSER(wtex, va)) wtex = va; }
        if (w[i] == 0 && k < N_EXTRA && w[i + 2] == 0) {
            d = w[i + 3];
            if (d >= 0x80000000u && d < 0x83FFFFF0u) {
                uint32_t m = w[(d - 0x80000000u) / 4u];
                uint32_t va = 0x80000000u + i * 4u;
                if (m == 0x47425820u) { if (CLOSER(mesh[k], va)) mesh[k] = va; }
                else if (m == 0x7A696E61u) { if (CLOSER(anim[k], va)) anim[k] = va; }
            }
        }
        k = w[i + 2] - KEY0;
        if (w[i] == 0x001709C4u && k < N_EXTRA && w[i + 1] == 0 && w[i + 4] >= 0x80000000u && w[i + 4] < 0x84000000u)
            { uint32_t va = 0x80000000u + i * 4u; if (CLOSER(tex[k], va)) tex[k] = va; }
    }
    for (g = 0; g < N_EXTRA; g++) {   /* all four, or none yet */
        uint32_t an = (s_skins[g].map && !own_anim && !s_fe_native) ? s_fe_anim0 : anim[g];
        if (!mesh[g] || !an || !tex[g]) {
            if (s_spawn_pending == 1) tt_dbg("[HEROES] %s: menu model not loaded yet (%08X %08X %08X)\n", s_skins[g].name, mesh[g], an, tex[g]);
            s_spawn_pending = 2;
            s_spawning = 0;
            return;
        }
    }
    for (g = 0; g < N_EXTRA; g++) {
        uint32_t a[4], r, an = (s_skins[g].map && !own_anim && !s_fe_native) ? s_fe_anim0 : anim[g];   /* re-rigged: Aragorn's moves */
        a[0] = an; a[1] = mesh[g]; a[2] = tex[g]; a[3] = s_fe_last_args[3];   /* the shared second texture */
        r = tt_gcall(0x000CA490u, FE_MGR, 4, a);
        if ((int)r != 4 + g) { tt_dbg("[HEROES] %s: character %d, not %d\n", s_skins[g].name, (int)r, 4 + g); break; }
        tt_dbg("[HEROES] %s: character %d, weapon %08X %08X\n", s_skins[g].name, (int)r, gwm[g], gwt[g]);
        if (getenv("TT_NOFEW")) ;
        else if (gwm[g] && gwt[g]) {   /* his own weapon in hand: the game's own way, as for the retail four */
            uint32_t w3[3] = { r, gwm[g], gwt[g] };
            tt_gcall(0x000CA540u, FE_MGR, 3, w3);
        } else if (s_skins[g].map && wmesh && wtex) {   /* (else Aragorn's sword) */
            uint32_t w3[3] = { r, wmesh, wtex };
            tt_gcall(0x000CA540u, FE_MGR, 3, w3);
        }
        tt_dbg("[HEROES] %s: weapon on the select %08X %08X\n", s_skins[g].name, gwm[g], gwt[g]);
        s_fe_extra++;
    }
    s_spawning = 0;
    s_ang_ok = 0;
    if (s_fe_extra == N_EXTRA) s_spawn_pending = 0;
    memset(s_actor, 0, sizeof s_actor);
    if (s_fe_extra == N_EXTRA) {
        uint32_t arr = G32(FE_MGR), cnt = G32(FE_MGR + 8), k;
        for (k = 0; k < cnt && k < N_PLACES; k++) {
            uint32_t id = G32(arr + k * 0x1E0u + 0x1B8u);
            if (id < N_PLACES) s_actor[id] = arr + k * 0x1E0u;
        }
        hero4_actor(s_guest);
    }
    tt_dbg("[HEROES] %d extra characters on the character select (%s)\n", s_fe_extra,
           unlocked() ? "unlocked" : "locked: finish Hornburg Courtyard and the Tower of Orthanc first");
}

static int places(void)
{
    return (tt_heroes_on() && unlocked() && s_fe_extra == N_EXTRA) ? N_PLACES : 0;
}

/* the guest a place stands for: -1 Isildur / not hero 4 */
static int place_guest(int p) { return p >= 4 ? p - 4 : -1; }

static void cursor_changed(uint32_t menu)
{
    G32(menu + 0x18) = (uint32_t)(s_cursor < 4 ? s_cursor : 3);
    if (s_cursor >= 3) {
        int g = place_guest(s_cursor);
        s_guest = g;
        rec_switch(g);
        hero4_actor(g);
        name_set(g < 0 ? "Isildur" : s_skins[g].title);
    }
}

/* the ring: place p's angle, degrees, with c at the front */
static float target_deg(int p, int c, int n) { return 180.0f + 360.0f / n * (float)(((p - c) % n + n) % n); }

static void layout(uint32_t menu)
{
    int n = places(), i;
    uint32_t scratch;
    float center[3], step, pi2 = 6.2831853f, front, slot;
    int mode = (int)G32(menu + 0x20), dir = G8(menu + 0x210);
    /* scratch room for the calls' out-parameters: well below the stack */
    scratch = (tt_guest_esp() - 0x3000u) & ~0xFu;
    if (s_cursor < 0 || s_cursor >= n || G32(menu + 0x18) != (uint32_t)(s_cursor < 4 ? s_cursor : 3)) {
        s_cursor = (int)G32(menu + 0x18);
        if (s_cursor == 3 && s_guest >= 0) s_cursor = 4 + s_guest;
    }
    /* the ring's centre: the screen point (320, 340) at depth 17 */
    {
        uint32_t a[4] = { 0x140u, 0x154u, scratch, fbits(GF(0x173DBCu)) };
        tt_gcall(0x000CAEF0u, FE_TEXT, 4, a);
        center[0] = GF(scratch); center[1] = GF(scratch + 4); center[2] = GF(scratch + 8);
    }
    step = GF(0x4B8B98u);
    if (!(step <= 100.0f)) step = 100.0f;
    step *= 0.0035999f;
    front = 180.0f * 0.0174533f;
    slot = pi2 / n;
    for (i = 0; i < n; i++) {
        float tgt = target_deg(i, s_cursor, n) * 0.0174533f, a, alpha, d;
        while (tgt >= pi2) tgt -= pi2;
        if (!s_ang_ok || mode != 2) s_ang[i] = tgt;
        else if (s_ang[i] != tgt) {
            /* turn the way the cursor went, and stop on the target */
            float c = s_ang[i], dist = dir ? c - tgt : tgt - c;
            while (dist < 0) dist += pi2;
            while (dist >= pi2) dist -= pi2;
            if (dist <= step) {
                s_ang[i] = tgt;
                if (i == s_cursor) {   /* arrived in front: the "chosen" pose (and voice) */
                    if (i < 4) tt_gcall(0x00073830u, menu, 0, NULL);
                    else if (s_skins[i - 4].map) { uint32_t aa[4] = { aid(i), 0x25u, 0, 0x64u }; tt_gcall(0x000CA960u, FE_MGR, 4, aa); }
                }
            } else {
                c += dir ? -step : step;
                while (c < 0) c += pi2;
                while (c >= pi2) c -= pi2;
                s_ang[i] = c;
            }
        }
        a = s_ang[i];
        /* on a circle of radius 3 round the centre, in the ground plane */
        {
            /* Lurtz is a head taller than the others: a step further back,
             * so that his name above him stays clear */
            static const float back[N_EXTRA] = { 0, 0, 0, 1.8f }, down[N_EXTRA] = { 0, 0, 0, 0.5f };
            float rad = 3.0f - (i >= 4 ? back[i - 4] : 0.0f);
            GF(scratch + 0x20) = center[0] - rad * sinf(a);
            GF(scratch + 0x24) = center[1] + rad * cosf(a);
            GF(scratch + 0x28) = center[2] - (i >= 4 ? down[i - 4] : 0.0f);
        }
        { uint32_t aa[2] = { aid(i), scratch + 0x20 }; tt_gcall(0x000CAA10u, FE_MGR, 2, aa); }
        /* full colour in front, faded elsewhere */
        d = fabsf(a - front);
        if (d > pi2 / 2) d = pi2 - d;
        if (mode != 2 || !s_ang_ok) alpha = i == s_cursor ? 1.0f : 0.35f;
        else alpha = d >= slot ? 0.35f : 0.35f + (1.0f - 0.35f) * (slot - d) / slot;
        if (i >= 4 && !guest_unlocked(i - 4)) alpha = 0.12f;   /* locked: a faint shadow */
        { uint32_t aa[2] = { aid(i), fbits(alpha) }; tt_gcall(0x000CAAD0u, FE_MGR, 2, aa); }
    }
    s_ang_ok = 1;
    /* Aragorn's and Gimli's idles, as the game keeps them going */
    {
        static const uint32_t idle[2][2] = { { 0, 0x22 }, { 2, 0xA0 } };
        int k;
        for (k = 0; k < 2; k++) {
            uint32_t a1[1] = { idle[k][0] };
            if (tt_gcall(0x000CA9A0u, FE_MGR, 1, a1) & 0xFF) {
                if (tt_gcall(0x000CA9E0u, FE_MGR, 1, a1) != idle[k][1]) {
                    uint32_t aa[4] = { idle[k][0], idle[k][1], 1, 0 };
                    tt_gcall(0x000CA960u, FE_MGR, 4, aa);
                }
            }
        }
        /* the guests: Aragorn's stance (0x22) looping, after the chosen pose (0x25), once any other move is done */
        for (k = 4; k < n; k++) {
            uint32_t a1[1] = { aid(k) };
            uint32_t cur = tt_gcall(0x000CA9E0u, FE_MGR, 1, a1);
            /* back to the stance when nothing plays or a move (the chosen
             * pose 0x25, the game's confirm stab 0x28) has finished */
            if (cur == 0xFFFFFFFFu || (cur != 0x22u && (tt_gcall(0x000CA9A0u, FE_MGR, 1, a1) & 0xFF))) {
                uint32_t aa[4] = { aid(k), 0x22u, 1, 0 };
                tt_gcall(0x000CA960u, FE_MGR, 4, aa);
            }
        }
    }
}

/* ===================================================================== */
/* hooks                                                                  */
/* ===================================================================== */
static int s_last_kind = -1;
static int s_in_wop;   /* inside the weapon script op */
static int s_wop_swap; /* ... for the player's slot that the guest's own weapon takes */
static int s_wop_tex;  /* textures swapped so far in this op */
static uint32_t s_wop_mesh, s_wop_wtex;   /* ... to these */
static int s_wop_rec;
static int s_wop_player;   /* 1 the player's bow given now, 2 his sword */
static int s_wop_extra;
static uint32_t s_wop_ins, s_wop_ctx;
/* the script context's actor record the weapon op is for: [ctx+0x178]
 * records of 0xE4 bytes from ctx+0x188, [+4] the actor; record 0 is the
 * player's hero */
static int wop_record(uint32_t ctx)
{
    uint32_t ins = G32(ctx + 0x30), n = G32(ctx + 0x178), i;
    for (i = 0; i < n && i < 256; i++)
        if (G32(ctx + 0x188 + i * 0xE4u + 4) == G32(ins + 4)) return (int)i;
    return -1;
}

static DWORD WINAPI aw_thread(LPVOID u);
void tt_heroes_init(void)
{
    { int q; for (q = 0; q < 256; q++) s_idmap[q] = (uint8_t)q; }
    if (tt_heroes_on() || playas() >= 0) xbox_path_redirect = redirect;
    if (getenv("TT_ANIMWATCH") || getenv("TT_WOBJWATCH") || getenv("TT_WOBJSHOW") || getenv("TT_HPFIND") || getenv("TT_HPFREEZE") || getenv("TT_ANIMCYCLE") || getenv("TT_CYCSLOTS")) CreateThread(NULL, 0, aw_thread, NULL, 0, NULL);
    if (getenv("TT_GUEST")) s_guest = skin_by_name(getenv("TT_GUEST"));   /* testing: hero 4 is this one */
    if (getenv("TT_FIGDUMP")) {   /* testing: the upgrade figures as heroes/fig_<name>.ppm */
        int g, k; paths();
        for (g = 0; g < N_EXTRA; g++) {
            uint32_t *im = figure_render(g); char pth[700]; FILE *pf;
            if (!im) continue;
            snprintf(pth, sizeof pth, "%s/heroes/fig_%s.ppm", s_dir, s_skins[g].name);
            if ((pf = fopen(pth, "wb")) != NULL) { fprintf(pf, "P6 128 256 255\n"); for (k = 0; k < 128 * 256; k++) { unsigned char c3[3] = { (unsigned char)(im[k] >> 16), (unsigned char)(im[k] >> 8), (unsigned char)im[k] }; fwrite(c3, 1, 3, pf); } fclose(pf); }
            free(im);
        }
    }
    if (getenv("TT_GTEX")) s_skins[1].tex = s_skins[0].tex;
    if (getenv("TT_SWAPMESH")) {   /* testing: Boromir's slot with Gandalf's model (or texture with =2) */
        if (atoi(getenv("TT_SWAPMESH")) == 2) s_skins[0].tex = s_skins[1].tex;
        else { s_skins[0].mesh = s_skins[1].mesh; s_skins[0].map = s_skins[1].map; s_skins[0].nmap = s_skins[1].nmap; }
    }   /* testing: Gandalf in Boromir's texture */
    if (getenv("TT_UPG_SELFTEST")) {   /* testing: build the four upgrade pictures now */
        int g, keep = s_guest;
        for (g = 0; g < N_EXTRA; g++) { s_guest = g; upg_redirect("\\Device\\CdRom0\\UI\\upgbigi.BFF", "upgbigi.BFF"); upg_redirect("\\Device\\CdRom0\\UI\\endlvl.BFF", "endlvl.BFF"); upg_redirect("\\Device\\CdRom0\\UI\\upgradei.BFF", "upgradei.BFF"); }
        s_guest = keep;
    }
}

/* testing: TT_CALLTRACE=level -- each function reached through an indirect
 * call, the first time, with ms since that level's file was opened */
static uint32_t s_ct_t0;
static unsigned char *s_ct_seen;
static FILE *s_ct_f;
static void tt_ct_arm(const char *xp)
{
    const char *e = getenv("TT_CALLTRACE");
    if (e && !s_ct_t0 && strstr(xp, e)) s_ct_t0 = GetTickCount() | 1;
}
void tt_calltrace(uint32_t va)
{
    if (!s_ct_t0 || va >= 0x200000) return;
    if (!s_ct_seen) { s_ct_seen = (unsigned char *)calloc(0x200000, 1); if (!s_ct_seen) { s_ct_t0 = 0; return; } }
    if (s_ct_seen[va]) return;
    s_ct_seen[va] = 1;
    if (!s_ct_f) s_ct_f = fopen("calltrace.txt", "w");
    if (s_ct_f) { fprintf(s_ct_f, "%u %06X\n", (unsigned)(GetTickCount() - s_ct_t0), va); fflush(s_ct_f); }
}


/* testing: TT_ANIMWATCH -- which animation slots the player's moves play.
 * Finds the hero's animation set in memory (by its size), the words that
 * point at its records, and logs their changes as slot numbers. */
#define AW_MAXW 64
static uint32_t s_aw_set, s_aw_ns, s_aw_watch[AW_MAXW], s_aw_last[AW_MAXW];
static int s_aw_n = -1;
static int aw_slot(uint32_t v)
{
    uint32_t i, io = G32(s_aw_set + 0x10);
    for (i = 0; i < s_aw_ns; i++) { uint32_t r = G32(s_aw_set + io + 4 * i); if (r && s_aw_set + r == v) return (int)i; }
    return -1;
}
static void anim_watch(void)
{
    static int fr;
    uint32_t va, k;
    (void)fr;
    if (!s_aw_set) {
        uint32_t want = (uint32_t)strtoul(getenv("TT_ANIMWATCH"), NULL, 16);
        for (va = 0x80000000u; va < 0x83FFFF00u; va += 0x10)
            if (G32(va) == 0x7A696E61u && G32(va + 0xC) == want) { s_aw_set = va; s_aw_ns = G16(va + 6); break; }
        if (!s_aw_set) return;
        tt_dbg("[AW] set at %08X, %u slots\n", s_aw_set, s_aw_ns);
    }
    if (s_aw_n < 0 && ++fr > 200) {
        uint32_t lo = s_aw_set, hi = s_aw_set + G32(s_aw_set + 0xC);
        s_aw_n = 0;
        for (va = 0x80000000u; va < 0x83FFFFFCu && s_aw_n < AW_MAXW; va += 4) {
            uint32_t v = G32(va);
            if ((v == lo || (v > lo && v < hi && G32(v) == 0x6D696E61u)) && (va < lo || va >= hi)) {
                s_aw_watch[s_aw_n++] = va;
                tt_dbg("[AW] %08X holds %08X (slot %d)\n", va, v, aw_slot(v));
            }
        }
        { static uint32_t snap[AW_MAXW][48]; (void)snap; }
    }
    {
        static uint32_t snap[AW_MAXW][48]; static int have;
        for (k = 0; k < (uint32_t)(s_aw_n > 0 ? s_aw_n : 0); k++) {
            int j;
            for (j = 0; j < 48; j++) {
                uint32_t a2 = s_aw_watch[k] - 0x60 + 4 * j, v = G32(a2);
                if (have && 4 * j - 0x60 == 64 && v != snap[k][j] && (v < 260 || (v > s_aw_set && v < s_aw_set + G32(s_aw_set + 0xC))))
                    tt_dbg("[AW] t%u %08X+%d: %u -> %u (slot %d)\n", GetTickCount() / 100 % 100000, s_aw_watch[k], 4 * j - 0x60, snap[k][j], v, aw_slot(v));
                snap[k][j] = v;
            }
        }
        if (s_aw_n > 0) have = 1;
    }
}
static void anim_cycle(void)
{
    static uint32_t set, k, last;
    uint32_t va;
    if (!s_ncyc) return;
    if (!set) {
        for (va = 0x80000000u; va < 0x83FFFF00u; va += 0x10)
            if (G32(va) == 0x7A696E61u && G32(va + 0xC) == s_comp_size) { set = va; break; }
        if (!set) return;
        last = GetTickCount();
        tt_dbg("[CYC] set at %08X\n", set);
    }
    if (GetTickCount() - last < (getenv("TT_CYCMS") ? (DWORD)atoi(getenv("TT_CYCMS")) : 5000u)) return;
    last = GetTickCount();
    {
        uint32_t io = G32(set + 0x10), q;
        static const int idles[] = { 0, 1, 3, 4, 5, 33, 34, 37, 38, 39 };
        for (q = 0; q < sizeof idles / sizeof idles[0]; q++) G32(set + io + 4 * idles[q]) = s_cyc[k % s_ncyc][2];
        { FILETIME ft; ULARGE_INTEGER u; GetSystemTimeAsFileTime(&ft); u.LowPart = ft.dwLowDateTime; u.HighPart = ft.dwHighDateTime;
          tt_dbg("[CYC] unix %llu showing his slot %u\n", (unsigned long long)(u.QuadPart / 10000000ull - 11644473600ull), s_cyc[k % s_ncyc][0]); }
        k++;
    }
}
/* testing: TT_WOBJWATCH -- the player's weapon objects' words that change */
static uint32_t s_sword_res, s_shooter;   /* the guest's sword-hand model as the game holds it */
static uint32_t s_lk_key, s_lk_ty, s_bow_res, s_beam_obj[8], s_beam_n, s_launching;   /* the last resource lookup; the guest's bow-hand model */
static uint32_t s_wobj[4];   /* the player's bow and sword objects, his actor */
static void wobj_watch(void)
{
    static uint32_t snap[4][0x200]; static int have[4];
    int k, j;
    if (getenv("TT_WOBJSHOW") && s_wobj[0]) {   /* testing: flag word +0x110 bits off */
        uint32_t m = (uint32_t)strtoul(getenv("TT_WOBJSHOW"), NULL, 16);
        G32(s_wobj[0] + 0x110) &= ~m;
    }
    if (!getenv("TT_WOBJWATCH") || !strcmp(getenv("TT_WOBJWATCH"), "0")) return;
    for (k = 0; k < 2; k++) {
        uint32_t o = s_wobj[k];
        if (!o) continue;
        for (j = 0; j < 0x200; j++) {
            uint32_t v = G32(o + 4 * j);
            if (have[k] && v != snap[k][j])
                tt_dbg("[WOBJ] t%u w%d %08X+%X: %08X -> %08X\n", GetTickCount() / 10 % 1000000, k, o, 4 * j, snap[k][j], v);
            snap[k][j] = v;
        }
        have[k] = 1;
    }
}
/* testing: TT_HPFIND=<value> -- words holding the hero's starting health
 * (float or int) at 40 s, which of them changed by 80 s; TT_HPFREEZE=<addr>
 * keeps a float there at its value */
static void hp_find(void)
{
    static uint32_t cand[4096]; static int nc = -1, done;
    static DWORD t0;
    float want = (float)atof(getenv("TT_HPFIND"));
    uint32_t va;
    if (!t0) t0 = GetTickCount();
    if (nc < 0 && GetTickCount() - t0 > 40000) {
        nc = 0;
        for (va = 0x80000000u; va < 0x83FFFFFCu && nc < 4096; va += 4)
            if (GF(va) == want || G32(va) == (uint32_t)want) cand[nc++] = va;
        tt_dbg("[HP] %d candidates\n", nc);
    }
    if (nc > 0 && !done && GetTickCount() - t0 > 90000) {
        int i;
        done = 1;
        for (i = 0; i < nc; i++) if (GF(cand[i]) != want && G32(cand[i]) != (uint32_t)want)
            tt_dbg("[HP] %08X now %.2f / %u\n", cand[i], GF(cand[i]), G32(cand[i]));
    }
}
static DWORD WINAPI aw_thread(LPVOID u) { (void)u; for (;;) { Sleep(50);
        if (getenv("TT_HPFIND")) hp_find();
        if (getenv("TT_HPFREEZE")) { static float keep; static int have; uint32_t a = (uint32_t)strtoul(getenv("TT_HPFREEZE"), NULL, 16); if (G32(a)) { if (!have) { keep = GF(a); have = 1; } if (GF(a) < keep) GF(a) = keep; } } if (getenv("TT_ANIMWATCH")) anim_watch(); if (getenv("TT_WOBJWATCH") || getenv("TT_WOBJSHOW")) wobj_watch(); anim_cycle(); } return 0; }

static void wdb_dump(void)
{
    if (G32(0x424AA0u) && G32(0x424A9Cu)) {   /* testing: the weapon table */
        static int done; uint32_t n = G32(G32(0x424AA0u) + 0xC), b = G32(0x424A9Cu), i, q;
        if (!done && n && n < 200) {
            done = 1;
            for (i = 0; i < n; i++) {
                uint32_t r = b + i * 0xB0u; char nm[33]; int k;
                for (k = 0; k < 32 && G8(r + k) >= 32 && G8(r + k) < 127; k++) nm[k] = (char)G8(r + k);
                nm[k] = 0;
                tt_dbg("[WDB] %2u %-24s id %u dmg %u ext %.2f..%.2f samp %u trail", i, nm, G32(r + 0x20), G32(r + 0x24), GF(r + 0x44), GF(r + 0x48), G32(r + 0x4C));
                for (q = 0x5C; q < 0x9C; q += 4) tt_dbg(" %u", G32(r + q));
                tt_dbg("\n");
            }
        }
    }
}
/* testing: TT_PARTLOG -- particle spawns (kind 0: id, pos) and LightGlowEffect calls (1) */
void tt_partlog(int kind, uint32_t a, uint32_t b, uint32_t c)
{
    static int on = -1, wd = -1; static unsigned n[1024], g;
    if (on < 0) { on = getenv("TT_PARTLOG") ? 1 : 0; wd = getenv("TT_WDBDUMP") ? 1 : 0; }
    if (wd) wdb_dump();
    if (kind == 3 && getenv("TT_FEWLOG")) { tt_dbg("[FEW] CA540 id %u mesh %08X (%08X %08X %08X %08X) tex %08X (%08X %08X %08X %08X %08X)\n", a, b, G32(b), G32(b + 4), G32(b + 8), G32(b + 12), c, G32(c), G32(c + 4), G32(c + 8), G32(c + 12), G32(c + 16)); return; }
    if (kind == 3) return;
    if (!on) return;
    if (kind == 1) { if (g++ < 50) tt_dbg("[GLOW] args %08X %08X %08X\n", a, b, c); return; }
    if (kind == 2) { if (g++ < 50) tt_dbg("[SHIMMER] args %08X %08X %08X\n", a, b, c); return; }
    { static DWORD last; if (GetTickCount() - last > 5000) { int i; last = GetTickCount(); for (i = 0; i < 1024; i++) if (n[i] > 20) tt_dbg("[PARTN] id %X n %u\n", i, n[i]); } }
    if (a < 1024 && n[a]++ < 3) tt_dbg("[PART] id %X pos %.1f %.1f %.1f\n", a, b >= 0x10000u && b < 0x84000000u ? GF(b) : 0, b >= 0x10000u && b < 0x84000000u ? GF(b + 4) : 0, b >= 0x10000u && b < 0x84000000u ? GF(b + 8) : 0);
    (void)c;
}
/* testing: TT_SWEEPLOG -- script callbacks counted (22 OnKillingBlow, 24 OnBreakShield) */
void tt_cbev(uint32_t obj, uint32_t ev)
{
    static unsigned n[64];
    static int on = -1;
    (void)obj;
    if (on < 0) on = getenv("TT_SWEEPLOG") ? 1 : 0;
    if (!on || ev >= 64) return;
    n[ev]++;
    if (ev == 22 || ev == 24) tt_dbg("[CB] ev %u count %u\n", ev, n[ev]);
    { static DWORD last; if (GetTickCount() - last > 5000) { char b[512]; int i, l = 0; last = GetTickCount(); for (i = 0; i < 32; i++) l += snprintf(b + l, sizeof b - l, "%u ", n[i]); tt_dbg("[CBH] %s\n", b); } }
}
/* testing: TT_SWEEPLOG -- the melee sweeps' results per weapon id (hits) */
/* testing: TT_HEADLOG -- at each sweep of the player's sword: its owner's
 * heading (a z-up 4x4 matrix found in an object the weapon points to, near
 * the weapon), the victim's bearing and the blade's direction, relative to
 * that heading */
static int find_zup(uint32_t obj, const float *nrp, float lim)
{
    uint32_t o;
    if (obj < 0x80000000u || obj >= 0x83FFF000u) return -1;
    for (o = 0; o < 0x800; o += 4) {
        float m[16]; int i, ok = 1;
        for (i = 0; i < 16; i++) { m[i] = GF(obj + o + 4u * (uint32_t)i); if (!(m[i] > -1e5f && m[i] < 1e5f)) ok = 0; }
        if (!ok) continue;
        if (fabsf(m[2]) > 0.02f || fabsf(m[6]) > 0.02f || fabsf(m[10] - 1) > 0.02f || fabsf(m[8]) > 0.02f || fabsf(m[9]) > 0.02f) continue;
        if (fabsf(m[0] * m[0] + m[1] * m[1] - 1) > 0.03f || fabsf(m[4] * m[4] + m[5] * m[5] - 1) > 0.03f || fabsf(m[0] * m[4] + m[1] * m[5]) > 0.03f) continue;
        if (fabsf(m[0]) > 0.9999f && fabsf(m[12]) < 1e-3f) continue;
        if (nrp && (fabsf(m[12] - nrp[0]) > lim || fabsf(m[13] - nrp[1]) > lim)) continue;
        return (int)o;
    }
    return -1;
}
static uint32_t s_hl_w, s_hl_own; static int s_hl_mo;
/* testing: TT_HEADLOG -- every HUD frame, once the sweep found them: the
 * sword's hand (the weapon's place) and tip in its owner's frame (x along
 * the owner's X row, y along its Y row) */
void tt_framelog(void)
{
    static int on = -1;
    float m[16], x, y, z, tx, ty, tz;
    uint32_t w = s_hl_w, own = s_hl_own;
    int i;
    if (on < 0) on = getenv("TT_HEADLOG") ? 1 : 0;
    if (!on || !w || !own) return;
    for (i = 0; i < 16; i++) m[i] = GF(own + (uint32_t)s_hl_mo + 4u * (uint32_t)i);
    x = GF(w + 0x60 + 48) - m[12]; y = GF(w + 0x60 + 52) - m[13]; z = GF(w + 0x60 + 56) - m[14];
    tx = x + 4 * GF(w + 0x60 + 16); ty = y + 4 * GF(w + 0x60 + 20); tz = z + 4 * GF(w + 0x60 + 24);
    tt_dbg("[HL] %.2f %.2f %.2f  %.2f %.2f %.2f\n", x * m[0] + y * m[1], x * m[4] + y * m[5], z, tx * m[0] + ty * m[1], tx * m[4] + ty * m[5], tz);
}
void tt_sweep2(uint32_t a0, uint32_t a1, double res)
{
    static int on = -1, wo = -1, mo = -1, vo = -1;
    uint32_t w, own;
    float wt[3], h, bx, by, vx, vy;
    if (on < 0) on = getenv("TT_HEADLOG") ? 1 : 0;
    if (!on || a0 < 0x10000u || a0 >= 0x84000000u || a1 < 0x80000000u || a1 >= 0x83FFF000u) return;
    w = G32(a0 + 0x14); if (w < 0x80000000u || w >= 0x84000000u || G32(w + 0x2F4) != 1) return;
    wt[0] = GF(w + 0x60 + 48); wt[1] = GF(w + 0x60 + 52); wt[2] = GF(w + 0x60 + 56);
    if (wo < 0 && wo != -2) {
        uint32_t o;
        for (o = 0; o < 0x800 && wo < 0; o += 4) {
            uint32_t p = G32(w + o);
            int m = find_zup(p, wt, 8.0f);
            if (m >= 0 && p != a1) { wo = (int)o; mo = m; tt_dbg("[HEAD] owner at weapon +%X (%08X), matrix +%X\n", o, p, m); }
        }
        if (wo < 0) { wo = -2; tt_dbg("[HEAD] no owner found\n"); }
    }
    if (wo < 0) return;
    own = G32(w + (uint32_t)wo);
    s_hl_w = w; s_hl_own = own; s_hl_mo = mo;
    vo = mo;   /* (an actor, as the owner) */
    h = atan2f(GF(own + mo + 4), GF(own + mo)) * 57.29578f;
    bx = GF(w + 0x60 + 16); by = GF(w + 0x60 + 20);
    vx = GF(a1 + vo + 48) - GF(own + mo + 48); vy = GF(a1 + vo + 52) - GF(own + mo + 52);
    {   /* the blade's tip (4 along its Y) from the owner */
        float tx = GF(w + 0x60 + 48) + 4 * bx - GF(own + mo + 48), ty = GF(w + 0x60 + 52) + 4 * by - GF(own + mo + 52);
        tt_dbg("[HEAD] tip %.0f %.1f victim %.0f %.1f hit %d\n", remainderf(atan2f(ty, tx) * 57.29578f - h, 360.0f), sqrtf(tx * tx + ty * ty),
               remainderf(atan2f(vy, vx) * 57.29578f - h, 360.0f), sqrtf(vx * vx + vy * vy), res >= 0);
    }
}
void tt_sweep(uint32_t a0, double res)
{
    static unsigned n[64], hit[64], last;
    uint32_t w, id;
    static int on = -1;
    if (on < 0) on = getenv("TT_SWEEPLOG") ? 1 : 0;
    if (!on || a0 < 0x10000u || a0 >= 0x84000000u) return;
    w = G32(a0 + 0x14); if (w < 0x80000000u || w >= 0x84000000u) return;
    id = G32(w + 0x2F4); if (id >= 64) return;
    n[id]++; if (res >= 0) hit[id]++;
    if (id == 1 && n[id] == 3) {   /* the player's sword: the models it refers to (a resource's key at +4) */
        uint32_t o2;
        tt_dbg("[SWP] sword res %08X key %08X\n", s_sword_res, s_sword_res ? G32(s_sword_res + 4) : 0);
        for (o2 = 0; o2 < 0x800; o2 += 4) { uint32_t q = G32(w + o2); if (q >= 0x80000000u && q < 0x84000000u && (G32(q + 4) & 0xFF000000u) && G32(q) >= 0x80000000u && G32(q) < 0x84000000u) tt_dbg("[SWP]   w+%03X -> %08X (+4 %08X)\n", o2, q, G32(q + 4)); }
    }
    if (GetTickCount() - last > 5000) { int i; last = GetTickCount(); for (i = 0; i < 64; i++) if (n[i]) tt_dbg("[SWP] id %d sweeps %u hits %u\n", i, n[i], hit[i]); }
}
/* The game's melee hit test (the sweep, sub_000BA110) samples the weapon
 * from WEAPON_MIN_EXTENTS to WEAPON_MAX_EXTENTS along its local +Y (the
 * blade), through its world matrices (object +0x60, last frame's +0xA0),
 * by the vector transform sub_000FF13D (out, v, m) -- the guests' swings
 * pass a little off the hero's (their arms are not his), so their blade's
 * samples reach further: {0, y * reach, 0} for the player's weapon (id 1). */
static const float s_wreach[N_EXTRA] = { 1.35f, 1.35f, 1.6f, 1.35f };   /* Frodo's blade is short */
int tt_wvec(uint32_t out, uint32_t v, uint32_t m, uint32_t ret)
{
    static int off = -1;
    static float reach = -1.0f;
    uint32_t obj = 0;
    float x, M[16], o[4];
    int c;
    if (ret != 0xBA2AEu && ret != 0xBA314u) return 0;   /* the sweep's two samples */
    if (off < 0) { off = getenv("TT_NOWAXIS") ? 1 : 0; reach = getenv("TT_WREACH") ? (float)atof(getenv("TT_WREACH")) : 0.0f; }
    if (off || s_guest < 0 || s_guest >= N_EXTRA || G8(HERO_BYTE) != 4) return 0;
    if ((G32(v) & 0x7FFFFFFFu) || (G32(v + 8) & 0x7FFFFFFFu) || !(G32(v + 4) & 0x7FFFFFFFu)) return 0;
    if (m >= 0x80000100u && m < 0x83FFF000u) {   /* the player's sword (weapon id 1): this frame's matrix or the last */
        if (G32(m - 0x60u + 0x2F4u) == 1u) obj = m - 0x60u;
        else if (G32(m - 0xA0u + 0x2F4u) == 1u) obj = m - 0xA0u;
    }
    if (!obj) return 0;
    for (c = 0; c < 16; c++) M[c] = GF(m + 4u * (uint32_t)c);
    x = GF(v + 4) * (reach != 0 ? reach : s_wreach[s_guest]);
    for (c = 0; c < 4; c++) o[c] = x * M[4 + c] + M[12 + c];
    if (o[3] != 0.0f && o[3] != 1.0f) for (c = 0; c < 3; c++) o[c] /= o[3];
    for (c = 0; c < 3; c++) GF(out + 4u * (uint32_t)c) = o[c];
    return 1;
}
/* a shot's shooter (a weapon object, its model resource at +0x494; the
 * resource's key at +4) is the guest's bow hand: the model the weapon op
 * gave it, or (should that lookup have been missed) its key */
static int shot_res_is(uint32_t shooter, uint32_t res, uint32_t key)
{
    uint32_t m;
    if (shooter < 0x80000000u || shooter >= 0x84000000u) return 0;
    m = G32(shooter + 0x494);
    if (res && m == res) return 1;
    return m >= 0x80000000u && m < 0x84000000u && G32(m + 4) == key;
}
int tt_hk(int id, int phase, uint32_t *r)
{
    uint32_t g_ecx = r[1], g_esp = r[3];
    if (id == 21 && phase == 0 && getenv("TT_TABDUMP")) {   /* testing: the table at 0x424A0C (rows 0x4C), count [0x424A10]+0xC */
        static int done;
        uint32_t tab = G32(0x424A0C), db = G32(0x424A10);
        if (!done && tab && db) {
            uint32_t n = G32(db + 0xC), i, q;
            done = 1;
            for (i = 0; i < n && i < 64; i++) {
                char line[700]; int l = 0;
                l += snprintf(line + l, sizeof line - l, "[TAB] %2u:", i);
                for (q = 0; q < 0x4C; q += 4) l += snprintf(line + l, sizeof line - l, " %X", G32(tab + i * 0x4C + q));
                tt_dbg("%s\n", line);
            }
        }
    }
    if (id == 21 && phase == 0 && getenv("TT_PROJDUMP")) {   /* testing: the projectile database (rows 0x40 at [0x424A50], count [[0x424A4C]+0xC]) */
        static int done;
        uint32_t db = G32(0x424A4C), tab = G32(0x424A50);
        if (!done && db && tab) {
            uint32_t n = G32(db + 0xC), i, q;
            done = 1;
            tt_dbg("[PROJ] db %08X tab %08X n %u\n", db, tab, n);
            for (i = 0; i < n && i < 64; i++) {
                char line[700]; int l = 0;
                l += snprintf(line + l, sizeof line - l, "[PROJ] %2u:", i);
                for (q = 0; q < 0x40; q += 4) l += snprintf(line + l, sizeof line - l, " %X", G32(tab + i * 0x40 + q));
                tt_dbg("%s\n", line);
            }
        }
    }
    if (id == 3 && phase == 0) {
        static int once;
        s_last_kind = (int)G32(r[3] + 8);
        if (!once) { once = 1; tt_heroes_init(); }
        if (s_last_kind == 0) {   /* a level: is it Isildur's run at the secret level's end? */
            char nm[64];
            uint32_t p = G32(g_esp + 4);
            int i;
            for (i = 0; i < 63 && p && G8(p + i) >= 32 && G8(p + i) < 127; i++) nm[i] = (char)G8(p + i);
            nm[i] = 0;
            s_orth_pending = strstr(nm, "21ORTH2") && G8(HERO_BYTE) == 4 && s_guest < 0;
        }
    }
    /* his shots: the shooter (the bow-hand weapon's object, its model at
     * +0x494) carries his bow-hand model -- the player's shot. Gandalf's
     * are all the magic bolt (projectile 15, whatever arrows he has) */
    if (id == 22 && phase == 0 && tt_heroes_on() && G8(HERO_BYTE) == 4 && s_guest >= 0 && s_skins[s_guest].beam && !getenv("TT_NOBEAM")
        && (shot_res_is(G32(g_esp + 4), s_bow_res, EMPTY_PROP_KEY))) {
        s_beam_obj[s_beam_n++ & 7] = r[1];
        s_shooter = G32(g_esp + 4);
        if (!getenv("TT_KEEPPROJ")) G32(g_esp + 16) = 15u;
    }
    /* Gandalf's beam: as his bolt leaves (the launch done: the projectile
     * holds where it left, +0x3E8, and where it is aimed, +0x3F8), a line
     * of glowing particles from his staff's head to that point */
    if (id == 22 && phase == 0 && getenv("TT_SHOTLOG")) {   /* testing */
        uint32_t sh = G32(g_esp + 4);
        tt_dbg("[SHOT] ret %08X shooter %08X id %u res %08X bow %08X proj %u guest %d hero %u\n", G32(g_esp), sh, sh >= 0x80000000u && sh < 0x84000000u ? G32(sh + 0x2F4) : 0,
               sh >= 0x80000000u && sh < 0x84000000u ? G32(sh + 0x494) : 0, s_bow_res, G32(g_esp + 16), s_guest, G8(HERO_BYTE));
        if (sh >= 0x80000000u && sh < 0x84000000u && G32(sh + 0x494) >= 0x80000000u && G32(sh + 0x494) < 0x84000000u) { uint32_t rr = G32(sh + 0x494), q; for (q = 0; q < 0x40; q += 16) tt_dbg("[SHOT]   res+%02X %08X %08X %08X %08X\n", q, G32(rr + q), G32(rr + q + 4), G32(rr + q + 8), G32(rr + q + 12)); }
    }
    if (id == 22 && phase == 0) s_launching = r[1];
    if (id == 22 && phase == 1 && tt_heroes_on() && G8(HERO_BYTE) == 4 && s_guest >= 0 && s_skins[s_guest].beam && !getenv("TT_NOBEAM")) {
        uint32_t o = s_launching, scratch = (tt_guest_esp() - 0x3000u) & ~0xFu, pid;
        float a[3], b[3], d[3], len, step;
        int k, n, c, mine = 0, q;
        for (q = 0; q < 8; q++) if (o && s_beam_obj[q] == o) { mine = 1; s_beam_obj[q] = 0; }
        if (mine) {
            pid = getenv("TT_BEAMPART") ? (uint32_t)strtoul(getenv("TT_BEAMPART"), NULL, 0) : 0x135u;
            step = getenv("TT_BEAMSTEP") ? (float)atof(getenv("TT_BEAMSTEP")) : 1.0f;
            for (c = 0; c < 3; c++) { a[c] = GF(o + 0x3E8 + 4 * c); b[c] = GF(o + 0x3F8 + 4 * c); d[c] = b[c] - a[c]; }
            {   /* from his staff's head: the staff's object (the sword hand's
                 * weapon, its model at +0x494, near the shooter) holds its
                 * world box at +0xE0 (8 corners of 16 bytes): the second four
                 * the far end of the model's long axis -- the head */
                uint32_t va, ob = 0;
                if (s_shooter) {
                    const char *ws; uint32_t wm = 0, wt;
                    skin_weapon(s_guest, 1, &ws, &wm, &wt);
                    for (va = s_shooter - 0x4000u; va < s_shooter + 0x4000u && !ob; va += 4)
                        if (va - 0x494u != s_shooter && G32(va) >= 0x80000000u && G32(va) < 0x84000000u
                            && ((s_sword_res && G32(va) == s_sword_res) || (wm && G32(G32(va) + 4) == wm))) ob = va - 0x494u;
                }
                if (ob && !getenv("TT_TIP")) {
                    float h[3] = { 0, 0, 0 };
                    for (q = 0; q < 4; q++) for (c = 0; c < 3; c++) h[c] += GF(ob + 0x120 + 0x10 * (uint32_t)q + 4 * (uint32_t)c) * 0.25f;
                    for (c = 0; c < 3; c++) if (!(fabsf(h[c] - a[c]) < 20.0f)) ob = 0;   /* (nothing sensible: the old way) */
                    if (ob) for (c = 0; c < 3; c++) { a[c] = h[c]; d[c] = b[c] - a[c]; }
                }
                if (!ob) {   /* off the shot's own start: tip = {ahead, right, up} */
                    float tip[3] = { 1.0f, -1.1f, 2.5f }, fw[2], hl = sqrtf(d[0] * d[0] + d[1] * d[1]);
                    if (getenv("TT_TIP")) sscanf(getenv("TT_TIP"), "%f,%f,%f", &tip[0], &tip[1], &tip[2]);
                    if (hl > 0.01f) {
                        fw[0] = d[0] / hl; fw[1] = d[1] / hl;
                        a[0] += fw[0] * tip[0] + fw[1] * tip[1];
                        a[1] += fw[1] * tip[0] - fw[0] * tip[1];
                        a[2] += tip[2];
                        for (c = 0; c < 3; c++) d[c] = b[c] - a[c];
                    }
                }
            }
            len = sqrtf(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
            if (len > 120.0f) { for (c = 0; c < 3; c++) d[c] *= 120.0f / len; len = 120.0f; }
            n = (int)(len / step); if (n > 72) n = 72; if (n < 1) n = 1;
            for (q = 0; q < 16; q++) GF(scratch + 0x40 + 4 * q) = (q % 5) ? 0.0f : 1.0f;   /* an identity matrix */
            for (k = 0; k <= n; k++) {
                float f = (float)k / (float)n;
                uint32_t args[4];
                for (c = 0; c < 3; c++) GF(scratch + 4 * c) = a[c] + d[c] * f;
                GF(scratch + 12) = 1.0f;
                args[0] = pid; args[1] = scratch; args[2] = scratch + 0x40; args[3] = fbits(-1.0f);
                tt_gcall(0x0008E470u, 0, 4, args);
            }
            if (getenv("TT_PROJLOG")) tt_dbg("[BEAM] %d particles %X over %.1f from %.2f %.2f %.2f\n", n + 1, pid, len, a[0], a[1], a[2]);
        }
    }
    if ((id == 22 || id == 23) && getenv("TT_PROJLOG")) {   /* testing: projectiles */
        static uint32_t track, launching; static int nup;
        uint32_t o = r[1];
        if (id == 22 && phase == 0) launching = o;
        if (id == 22 && phase == 1) o = launching;
        if (id == 22 && phase == 0) {
            uint32_t a1 = G32(g_esp + 4), va;
            tt_dbg("[PRJ] launch obj %08X ret %08X args %08X %08X %08X %08X %08X\n", o, G32(g_esp), a1, G32(g_esp + 8), G32(g_esp + 12), G32(g_esp + 16), G32(g_esp + 20));
            {   /* pointers in the shooter (two levels) to an animation set */
                uint32_t q, q2;
                for (q = 0; q < 0x800; q += 4) {
                    uint32_t p = G32(a1 + q);
                    if (p < 0x80000000u || p >= 0x84000000u) continue;
                    if (G32(p) == 0x7A696E61u) tt_dbg("[PRJ]   +%X -> aniz size %X\n", q, G32(p + 0xC));
                    for (q2 = 0; q2 < 0x200; q2 += 4) { uint32_t p2 = G32(p + q2); if (p2 >= 0x80000000u && p2 < 0x84000000u && G32(p2) == 0x7A696E61u) tt_dbg("[PRJ]   +%X+%X -> aniz size %X\n", q, q2, G32(p2 + 0xC)); }
                }
                tt_dbg("[PRJ]   bow res %08X\n", s_bow_res);
                for (q = 0; q < 0x800; q += 4) {
                    uint32_t p = G32(a1 + q);
                    if (p == s_bow_res) tt_dbg("[PRJ]   +%X = bow res\n", q);
                    if (p >= 0x80000000u && p < 0x84000000u) for (q2 = 0; q2 < 0x100; q2 += 4) if (G32(p + q2) == s_bow_res) tt_dbg("[PRJ]   +%X+%X = bow res\n", q, q2);
                }
            }
        }
        if (id == 22 && phase == 1) {
            char line[900]; int l = 0; uint32_t q;
            track = o; nup = 0;
            l += snprintf(line + l, sizeof line - l, "[PRJ] obj %08X:", o);
            for (q = 0x3D0; q < 0x4E0; q += 4) l += snprintf(line + l, sizeof line - l, " %X", G32(o + q));
            tt_dbg("%s\n", line);
        }
        if (id == 23 && phase == 0) { static int n23; if (n23++ < 20) tt_dbg("[PRJ] upd call obj %08X (track %08X)\n", o, track); }
        if (id == 23 && phase == 0) o = r[1];
        if (id == 23 && phase == 0 && o == track && nup++ < 40) {
            char line[900]; int l = 0; uint32_t q;
            l += snprintf(line + l, sizeof line - l, "[PRJ] t%u upd:", GetTickCount() % 100000);
            for (q = 0; q < 0x40; q += 4) l += snprintf(line + l, sizeof line - l, " %.2f", GF(o + 0x3E8 + q));
            l += snprintf(line + l, sizeof line - l, " |");
            for (q = 0xD0; q < 0x120; q += 4) l += snprintf(line + l, sizeof line - l, " %.2f", GF(o + q));
            tt_dbg("%s\n", line);
        }
    }
    if (id == 10 && phase == 0 && s_last_kind == 0) { keyswap_apply(); skin_apply(); }

    /* the weapon script op: the player's weapon in that hand becomes the
     * guest's own (resource lookups of type 2 = model, 1 = texture) */
    if (id == 21 && phase == 0 && getenv("TT_WOPDUMP")) {
        uint32_t ins = G32(g_ecx + 0x30), q;
        char line[600]; int l = 0;
        l += snprintf(line + l, sizeof line - l, "[WOP] rec %d ins %08X:", wop_record(g_ecx), ins);
        for (q = 0; q < 0x40; q += 4) l += snprintf(line + l, sizeof line - l, " %08X", G32(ins + q));
        tt_dbg("%s\n", line);
    }
    if (id == 21) {
        s_in_wop = phase == 0;
        if (phase == 0) { s_wop_swap = 0; s_wop_tex = 0; s_wop_player = 0; s_wop_ins = G32(g_ecx + 0x30); s_wop_ctx = g_ecx; }
        if (phase == 0) s_wop_rec = wop_record(g_ecx) * 100 + (int)G32(G32(g_ecx + 0x30) + 0x18);
        if (phase == 1 && s_wop_player) {   /* the player's weapon objects (bow +0xBC, sword +0xC0 of his record) */
            uint32_t ctx = s_wop_ctx, n = G32(ctx + 0x178), i;
            for (i = 0; i < n && i < 64; i++) {
                uint32_t e = ctx + 0x188 + i * 0xE4;
                if (G32(e + 4) == G32(s_wop_ins + 4)) {
                    s_wobj[0] = G32(e + 0xBC); s_wobj[1] = G32(e + 0xC0);
                    s_wobj[2] = G32(e + 8);
                    if (getenv("TT_WOBJWATCH")) tt_dbg("[WOBJ] record %u: bow obj %08X sword obj %08X actor %08X\n", i, s_wobj[0], s_wobj[1], G32(e + 8));
                }
            }
        }
        /* his second hand: once the player's sword is given, the op again
         * for another slot, with his shield (the lookups swapped below) */
        if (phase == 1 && s_wop_player == 2 && !s_wop_extra && tt_heroes_on() && G8(HERO_BYTE) == 4 && s_guest >= 0
            && s_skins[s_guest].xmesh && !getenv("TT_NOWEAPON")) {
            uint32_t ctx = s_wop_ctx, ins = s_wop_ins, save_ip = G32(ctx + 0x30), save_slot = G32(ins + 0x18);
            int slot = getenv("TT_XSLOT") ? atoi(getenv("TT_XSLOT")) : s_skins[s_guest].xslot;
            s_wop_extra = 1;
            G32(ctx + 0x30) = ins; G32(ins + 0x18) = (uint32_t)slot;
            {
                extern void *recomp_lookup(uint32_t);
                tt_dbg("[HEROES] extra op: ctx %08X ins %08X fn %p\n", ctx, ins, recomp_lookup(0x0001AE00u));
            }
            tt_gcall(0x0001AE00u, ctx, 0, NULL);
            G32(ins + 0x18) = save_slot; G32(ctx + 0x30) = save_ip;
            s_wop_extra = 0;
            tt_dbg("[HEROES] %s: second hand (slot %d)\n", s_skins[s_guest].name, slot);
        }
    }
    /* the guest's bow-hand weapon's model as the game holds it (the
     * lookup's result): a shot whose shooter carries it is his */
    if (id == 2 && phase == 0) s_lk_key = G32(g_esp + 8), s_lk_ty = G32(g_esp + 4);
    if (id == 2 && phase == 1 && s_lk_ty == 2 && s_guest >= 0 && s_lk_key && (int)r[0]) {
        const char *ws; uint32_t wm, wt;
        if (s_in_wop && (s_lk_key == 0x36AC3F58u || (skin_weapon(s_guest, 0, &ws, &wm, &wt) && s_lk_key == wm))) s_bow_res = r[0];
        if (s_in_wop && (s_lk_key == 0x4586A62Cu || (skin_weapon(s_guest, 1, &ws, &wm, &wt) && s_lk_key == wm))) s_sword_res = r[0];
    }
    if (id == 2 && phase == 0 && getenv("TT_LKLOG"))   /* testing: every resource lookup */
        tt_dbg("[LK] t%u ty %u key %08X from %08X\n", GetTickCount() / 10 % 1000000, G32(g_esp + 4), G32(g_esp + 8), G32(g_esp));
    if (id == 2 && phase == 0 && s_in_wop && getenv("TT_WOPLOG"))
        tt_dbg("[WOPLK] rec %d ty %u key %08X\n", s_wop_rec, G32(g_esp + 4), G32(g_esp + 8));
    /* the weapon op's resource lookups (type 2 model, 1 texture): the
     * hero's bow / sword -> the guest's own; in the extra op, his shield */
    if (id == 2 && phase == 0 && s_in_wop && tt_heroes_on() && G8(HERO_BYTE) == 4 && s_guest >= 0 && !getenv("TT_NOWEAPON")) {
        uint32_t ty = G32(g_esp + 4), key = G32(g_esp + 8);
        if (ty == 2) {
            const char *ws; uint32_t wm, wt;
            /* the player's record holds the bow (36AC3F58) and two
             * sword-hand models: 4586A62C and 13F82514 (the one drawn in
             * his hand as he fights) -- both become the guest's */
            int sl = key == 0x36AC3F58u ? 0 : key == 0x4586A62Cu ? 1 : -1;
            if (sl < 0 && key == 0x13F82514u && !getenv("TT_NOSWORD2")) sl = 1;   /* every record: the cutscenes' copies of him too */
            if (sl < 0 && key) {   /* already the guest's (the level's weapon records were changed) */
                const char *ws2; uint32_t wm2, wt2;
                if (skin_weapon(s_guest, 0, &ws2, &wm2, &wt2) && key == wm2) sl = 0;
                else if (skin_weapon(s_guest, 1, &ws2, &wm2, &wt2) && key == wm2) sl = 1;
            }
            s_wop_swap = 0;
            if (sl >= 0) s_wop_player = sl + 1;
            if (s_wop_extra && sl >= 0) { s_wop_mesh = s_skins[s_guest].xmesh; s_wop_wtex = s_skins[s_guest].xtex; s_wop_swap = 1; }
            else if (sl >= 0 && skin_weapon(s_guest, sl, &ws, &wm, &wt)) { s_wop_mesh = wm; s_wop_wtex = wt; s_wop_swap = 1; }
            if (s_wop_swap) { G32(g_esp + 8) = s_wop_mesh; s_wop_tex = 0; }
        } else if (ty == 1 && s_wop_swap) {
            int k = s_wop_tex++;
            if (k == 0) G32(g_esp + 8) = s_wop_wtex;
            else if (k == 1 && weapon_tex2(s_wop_mesh) && !getenv("TT_NOTEX2")) G32(g_esp + 8) = weapon_tex2(s_wop_mesh);   /* its second layer (Sting's glow) */
        }
    }
    if (tt_heroes_on()) {
        /* the menu's characters: after the fourth retail one, ours */
        if (id == 17 && phase == 0 && !s_spawning) {
            int k;
            for (k = 0; k < 4; k++) s_fe_last_args[k] = G32(g_esp + 4 + 4 * k);
        }
        if (id == 17 && phase == 1 && !s_spawning && (int)r[0] == 0) s_fe_anim0 = s_fe_last_args[0];   /* Aragorn's */
        if (id == 17 && phase == 1 && !s_spawning && (int)r[0] == 3) {
            s_fe_extra = 0;
            s_spawn_pending = 1;
            s_nname = -1;   /* this menu's texts: found again on the next name change */
            /* at the first menu of a run the loader may not have reached our
             * models yet (they are at the end of the file): then the
             * character select tries again when it runs */
            if (unlocked() && getenv("TT_FE_LATE")) s_spawn_pending = 2;   /* testing: as if not loaded yet */
            else if (unlocked()) fe_spawn_extras();
            else { s_fe_extra = 0; memset(s_actor, 0, sizeof s_actor); tt_dbg("[HEROES] locked: finish Hornburg Courtyard and the Tower of Orthanc first\n"); }
        }
        /* never seen while locked */
        if (id == 18 && phase == 1 && !places() && s_fe_extra > 0) {
            int k;
            for (k = 4; k < 4 + s_fe_extra; k++) { uint32_t aa[2] = { (uint32_t)k, fbits(0.0f) }; tt_gcall(0x000CAAD0u, FE_MGR, 2, aa); }
        }
        /* the carousel: ours when it has eight places */
        if (id == 18 && phase == 0 && s_spawn_pending && s_fe_extra == 0 && unlocked()) {
            static unsigned t;
            if (++t % 15 == 0) fe_spawn_extras();   /* a scan of the whole window: not every frame */
        }
        if (id == 18 && phase == 0 && places()) {
            static int spin, spin_ok, tick;
            if (!spin_ok) { spin_ok = 1; spin = getenv("TT_FE_SPIN") ? atoi(getenv("TT_FE_SPIN")) : 0; }   /* testing: step right every N frames */
            static int spin_to = -2;
            if (spin_to == -2) spin_to = getenv("TT_FE_SPINTO") ? atoi(getenv("TT_FE_SPINTO")) : -1;
            if (spin != 0 && s_cursor != spin_to && ++tick % (spin < 0 ? -spin : spin) == 0) {   /* < 0: to the left */
                int n = places();
                if (s_cursor < 0 || s_cursor >= n) s_cursor = (int)G32(g_ecx + 0x18);
                s_cursor = (s_cursor + (spin > 0 ? 1 : n - 1)) % n;
                G8(g_ecx + 0x210) = spin > 0 ? 1 : 0;
                cursor_changed(g_ecx);
                tt_dbg("[SELECT] spin to place %d\n", s_cursor);
            }
            if (spin_to >= 4 && s_cursor == spin_to && getenv("TT_FE_STAB") && ++tick % 120 == 0) {   /* testing: the confirm move */
                uint32_t aa[4] = { aid(s_cursor), 0x28u, 0, 0x64u };
                tt_gcall(0x000CA960u, FE_MGR, 4, aa);
                tt_dbg("[SELECT] confirm move on place %d\n", s_cursor);
            }
            layout(g_ecx); r[3] += 4; return 1;
        }
        if ((id == 6 || id == 7) && phase == 0 && places()) {
            int n = places();
            if (s_cursor < 0 || s_cursor >= n) s_cursor = (int)G32(g_ecx + 0x18);
            {   /* locked guests stand in the ring, but the cursor passes them by */
                int step = 0;
                do s_cursor = (s_cursor + (id == 6 ? 1 : n - 1)) % n;
                while (s_cursor >= 4 && !guest_unlocked(s_cursor - 4) && ++step < n);
            }
            G8(g_ecx + 0x210) = id == 6 ? 1 : 0;
            cursor_changed(g_ecx);
            if (log_on()) tt_dbg("[SELECT] place %d (game cursor %u)\n", s_cursor, G32(g_ecx + 0x18));
            r[3] += 4; return 1;
        }
        /* the guest may play where the others may */
        /* testing: Hornburg Courtyard (0xB) and the Tower of Orthanc (0xD)
         * count as finished, as far as the game asks; nothing is written */
        if (id == 14 && phase == 0 && s_test_unlock) {
            uint32_t level = G32(r[3] + 4) & 0xFFu, hero = G32(r[3] + 8);
            if ((level == 0xB || level == 0xD) && hero >= 1 && hero <= 3) { r[0] = 1; r[3] += 4; return 1; }
        }
        if (id == 14 && phase == 0 && s_guest >= 0) {
            uint32_t level = G32(r[3] + 4), hero = G32(r[3] + 8), h, best = 0;
            if (hero == 4 && level < 15) {
                for (h = 1; h <= 4; h++) { uint32_t v = G8(0x4AB68Fu + h * 15 + level); if (v > best) best = v; }
                r[0] = best; r[3] += 4; return 1;
            }
        }
        /* the save after Isildur's finish of the Tower of Orthanc: one more */
        if (id == 12 && phase == 0 && s_orth_pending) {
            s_orth_pending = 0;
            s_isildur_wins = isildur_wins() + 1;
            wins_write(s_save_key, s_isildur_wins);
            tt_dbg("[HEROES] Isildur has finished the Tower of Orthanc %d time(s) on save %s\n", s_isildur_wins, s_save_key);
        }
        /* saving: Isildur's records in hero 4 while the save is written */
        if (id == 12 && phase == 0 && s_rec_owner >= 0) { s_rec_saving_owner = s_rec_owner; rec_switch(-1); }
        if (id == 12 && phase == 1 && s_rec_saving_owner >= 0) { int g = s_rec_saving_owner; s_rec_saving_owner = -2; rec_switch(g); }
        /* loading a save: hero 4 is Isildur's again */
        if (id == 11 && phase == 1 && getenv("TT_RELOCK")) {   /* testing: a save that has not finished the game */
            uint32_t h;
            for (h = 1; h <= 4; h++) { G8(0x4AB68Fu + h * 15 + 0xB) = 0; G8(0x4AB68Fu + h * 15 + 0xD) = 0; }
        }
        if (id == 11 && phase == 0) s_orth_pending = 0;
        if (id == 11 && phase == 1) { s_rec_owner = -1; s_guest = -1; s_cursor = -1; if (s_nname >= 0) name_set("Isildur"); }
    }

    if (!log_on()) return 0;
    switch (id) {
    case 1:
        if (phase == 0) {
            uint32_t ins = G32(g_ecx + 0x30), k;
            char s[400];
            int n = sprintf(s, "[CREATE] ctx %08X slot %u op %04X:", g_ecx, G32(g_ecx + 0x178), G16(ins));
            for (k = 1; k < 24; k++) n += sprintf(s + n, " %08X", G32(ins + 4 * k));
            tt_dbg("%s\n", s);
        }
        break;
    case 3:
        if (phase == 0) {
            char nm[96];
            int i;
            uint32_t p = G32(g_esp + 4);
            for (i = 0; i < 95 && p && G8(p + i) >= 32 && G8(p + i) < 127; i++) nm[i] = (char)G8(p + i);
            nm[i] = 0;
            tt_dbg("[LOADER] %s kind %u hero %u\n", nm, G32(g_esp + 8), G8(HERO_BYTE));
        }
        break;
    case 5:
        if (phase == 0) tt_dbg("[HERO] set %u\n", G32(g_esp + 4));
        break;
    case 2:
        if (phase == 1 && s_in_wop) tt_dbg("[WEAPON]   -> %08X\n", r[0]);
        if (phase == 0 && s_in_wop) tt_dbg("[WEAPON]   lookup type %u key %08X\n", G32(g_esp + 4), G32(g_esp + 8));
        break;
    case 21:
        if (phase == 1 && wop_record(g_ecx) == 0) {
            uint32_t rec = g_ecx + 0x188, k;
            for (k = 0; k < 4; k++) { uint32_t w = G32(rec + 0xbc + 4 * k); if (w) tt_dbg("[WEAPON]   player slot %u: obj %08X mesh %08X tex %08X\n", k, w, G32(w + 0x584), G32(w + 0x598)); }
        }
        if (phase == 0) {
            uint32_t ins = G32(g_ecx + 0x30), k;
            char t[300];
            int m = sprintf(t, "[WEAPON] ctx %08X rec %d op %04X:", g_ecx, wop_record(g_ecx), G16(ins));
            for (k = 1; k < 12; k++) m += sprintf(t + m, " %08X", G32(ins + 4 * k));
            tt_dbg("%s\n", t);
        }
        break;
    case 17:
        if (phase == 0) tt_dbg("[FEACTOR] create(%08X, %08X, %08X, %08X)\n", G32(g_esp + 4), G32(g_esp + 8), G32(g_esp + 12), G32(g_esp + 16));
        else tt_dbg("[FEACTOR]   -> %d\n", (int)r[0]);
        break;
    default: break;
    }
    return 0;
}

/* for the ECTS HUD mod: who hero 4 is now */
int tt_heroes_guest(void)
{
    return (tt_heroes_on() && G8(HERO_BYTE) == 4 && s_guest >= 0 && s_guest < N_EXTRA) ? s_guest : -1;
}
const char *tt_heroes_guest_name(int g)
{
    return g >= 0 && g < N_EXTRA ? s_skins[g].name : "";
}
