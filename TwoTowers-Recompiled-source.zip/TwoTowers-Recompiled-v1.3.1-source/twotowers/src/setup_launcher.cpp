// The Two Towers Recompiled - first-launch setup and launcher.
//
// Like the Mercenaries launcher, this stays outside the recompiled game process:
// it validates/extracts the user's retail disc (ISO or an extracted folder),
// stores display settings in twotowers_recomp.ini, and starts twotowers_recomp.exe.
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <bcrypt.h>
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
#include <shlobj.h>

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <functional>
#include <set>
#include <string>
#include <thread>
#include <vector>

namespace fs = std::filesystem;

static const char *kXbeSha256 = "ae2d1b5304b3e9572339b693a6a45ad0869bdaeec89aae374b5c14feebbb8d30";
static const wchar_t *kTitle = L"The Two Towers Recompiled";

// ───────────────────────────── XISO (XDVDFS) reader ─────────────────────────────

struct IsoFile {
    std::string path;
    uint64_t size = 0, offset = 0;
    bool dir = false;
};

static bool readAt(std::ifstream &in, uint64_t off, void *buf, size_t n)
{
    in.clear();
    in.seekg((std::streamoff)off);
    if (!in) return false;
    in.read((char *)buf, (std::streamsize)n);
    return (size_t)in.gcount() == n;
}

static bool scanIso(const fs::path &iso, std::vector<IsoFile> &files, std::string &err)
{
    std::ifstream in(iso, std::ios::binary);
    if (!in) { err = "Cannot open the ISO."; return false; }
    const uint64_t kSector = 2048, parts[] = {0, 0x18300000ULL, 0x0FD90000ULL, 0x02080000ULL};
    uint64_t part = 0;
    char magic[20];
    bool found = false;
    for (auto p : parts)
        if (readAt(in, p + 32 * kSector, magic, 20) && !memcmp(magic, "MICROSOFT*XBOX*MEDIA", 20)) { part = p; found = true; break; }
    if (!found) { err = "This is not an original Xbox disc image."; return false; }
    uint32_t rootSector = 0, rootSize = 0;
    readAt(in, part + 32 * kSector + 20, &rootSector, 4);
    readAt(in, part + 32 * kSector + 24, &rootSize, 4);
    std::function<void(uint32_t, uint32_t, const std::string &, int)> walkDir = [&](uint32_t sector, uint32_t size, const std::string &prefix, int depth) {
        if (!size || depth > 32 || size > 64u * 1024 * 1024) return;
        std::vector<uint8_t> t(size);
        if (!readAt(in, part + sector * kSector, t.data(), size)) return;
        std::set<uint32_t> seen;
        std::function<void(uint32_t)> node = [&](uint32_t off) {
            if (off + 14 > t.size() || !seen.insert(off).second) return;
            uint16_t l, r;
            uint32_t start, fsize;
            memcpy(&l, &t[off], 2);
            memcpy(&r, &t[off + 2], 2);
            memcpy(&start, &t[off + 4], 4);
            memcpy(&fsize, &t[off + 8], 4);
            uint8_t attr = t[off + 12], nlen = t[off + 13];
            if (l == 0xFFFF && r == 0xFFFF) return;
            if (off + 14 + nlen > t.size()) return;
            if (l) node(l * 4u);
            std::string name((const char *)&t[off + 14], nlen);
            if (!name.empty() && name != "." && name != ".." && name.find_first_of("/\\:") == std::string::npos) {
                IsoFile f;
                f.path = prefix.empty() ? name : prefix + "/" + name;
                f.dir = (attr & 0x10) != 0;
                f.size = f.dir ? 0 : fsize;
                f.offset = part + (uint64_t)start * kSector;
                files.push_back(f);
                if (f.dir) walkDir(start, fsize, f.path, depth + 1);
            }
            if (r) node(r * 4u);
        };
        node(0);
    };
    walkDir(rootSector, rootSize, "", 0);
    if (files.empty()) { err = "The disc image has no files."; return false; }
    return true;
}

static std::string lower(std::string s)
{
    for (auto &c : s) c = (char)tolower((unsigned char)c);
    return s;
}

// ───────────────────────────── helpers ─────────────────────────────

static std::wstring W(const std::string &s)
{
    if (s.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n);
    return w;
}

static std::string sha256Hex(const std::vector<uint8_t> &d)
{
    BCRYPT_ALG_HANDLE alg = nullptr;
    BCRYPT_HASH_HANDLE h = nullptr;
    unsigned char dig[32] = {};
    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, nullptr, 0) == 0) {
        if (BCryptCreateHash(alg, &h, nullptr, 0, nullptr, 0, 0) == 0) {
            BCryptHashData(h, (PUCHAR)d.data(), (ULONG)d.size(), 0);
            BCryptFinishHash(h, dig, 32, 0);
            BCryptDestroyHash(h);
        }
        BCryptCloseAlgorithmProvider(alg, 0);
    }
    std::string s;
    char b[3];
    for (unsigned char c : dig) { snprintf(b, 3, "%02x", c); s += b; }
    return s;
}

static fs::path exeDir()
{
    wchar_t b[MAX_PATH];
    GetModuleFileNameW(nullptr, b, MAX_PATH);
    return fs::path(b).parent_path();
}
static fs::path iniPath() { return exeDir() / L"twotowers_recomp.ini"; }

static std::wstring iniGet(const wchar_t *sec, const wchar_t *key, const wchar_t *def)
{
    wchar_t b[1024];
    GetPrivateProfileStringW(sec, key, def, b, 1024, iniPath().c_str());
    return b;
}
static void iniSet(const wchar_t *sec, const wchar_t *key, const std::wstring &v)
{
    WritePrivateProfileStringW(sec, key, v.c_str(), iniPath().c_str());
}

static bool xbeOk(const fs::path &dir, std::string *why)
{
    fs::path x;
    std::error_code ec;
    for (auto &e : fs::directory_iterator(dir, ec))
        if (lower(e.path().filename().string()) == "default.xbe") x = e.path();
    if (x.empty()) { if (why) *why = "default.xbe was not found in that folder."; return false; }
    std::ifstream in(x, std::ios::binary);
    std::vector<uint8_t> d((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    if (sha256Hex(d) != kXbeSha256) {
        if (why) *why = "That default.xbe is not the USA retail release this port was built from.";
        return false;
    }
    return true;
}

static fs::path currentGameDir()
{
    std::wstring g = iniGet(L"Paths", L"game_dir", L"");
    return g.empty() ? exeDir() / L"game_files" : fs::path(g);
}

// ───────────────────────────── UI ─────────────────────────────

enum { ID_ISO = 100, ID_DIR, ID_RES, ID_MODE, ID_INTERNAL, ID_VSYNC, ID_WIDE, ID_LOG, ID_PLAY, ID_OPEN, ID_PROGRESS, ID_STATUS, ID_GFX, ID_CTL };
static const UINT WM_STATUS = WM_APP + 1, WM_PROGRESS = WM_APP + 2, WM_DONE = WM_APP + 3;

static HWND g_hwnd, g_status, g_progress, g_res, g_mode, g_internal, g_vsync, g_wide, g_log, g_play;
static HFONT g_font;
static int g_fontH = 16;
static std::atomic<bool> g_busy{false};

struct Res { int w, h; };
static std::vector<Res> g_resList;
static const Res kInternal[] = {{640, 480}, {1280, 960}, {1920, 1440}, {2560, 1920}};

static void setStatus(const std::wstring &s) { SetWindowTextW(g_status, s.c_str()); }
static void postStatus(const std::string &s) { PostMessageW(g_hwnd, WM_STATUS, 0, (LPARAM) new std::wstring(W(s))); }

static void refreshStatus()
{
    fs::path g = currentGameDir();
    std::string why;
    if (fs::exists(g) && xbeOk(g, &why)) {
        setStatus(L"Game files ready:  " + g.wstring());
        EnableWindow(g_play, TRUE);
    } else {
        setStatus(L"Game files not installed yet. Select your The Two Towers (USA) Xbox ISO or extracted disc folder.");
        EnableWindow(g_play, FALSE);
    }
}

static void extractIso(fs::path iso)
{
    std::vector<IsoFile> files;
    std::string err;
    fs::path out = exeDir() / L"game_files";
    if (!scanIso(iso, files, err)) { postStatus("Error: " + err); PostMessageW(g_hwnd, WM_DONE, 0, 0); return; }
    auto xbe = std::find_if(files.begin(), files.end(), [](auto &f) { return lower(f.path) == "default.xbe"; });
    if (xbe == files.end()) { postStatus("Error: the disc has no default.xbe."); PostMessageW(g_hwnd, WM_DONE, 0, 0); return; }
    std::ifstream in(iso, std::ios::binary);
    std::vector<uint8_t> xd(xbe->size);
    readAt(in, xbe->offset, xd.data(), xd.size());
    if (sha256Hex(xd) != kXbeSha256) {
        postStatus("Error: this ISO is not the USA retail The Two Towers disc this port supports.");
        PostMessageW(g_hwnd, WM_DONE, 0, 0);
        return;
    }
    uint64_t total = 0, done = 0;
    for (auto &f : files) total += f.size;
    std::vector<char> buf(4 << 20);
    try {
        fs::create_directories(out);
        for (auto &f : files) {
            fs::path dst = out / fs::u8path(f.path);
            if (f.dir) { fs::create_directories(dst); continue; }
            fs::create_directories(dst.parent_path());
            std::ofstream o(dst, std::ios::binary | std::ios::trunc);
            uint64_t left = f.size, pos = f.offset;
            while (left) {
                size_t n = (size_t)std::min<uint64_t>(left, buf.size());
                if (!readAt(in, pos, buf.data(), n)) throw std::runtime_error("read failed: " + f.path);
                o.write(buf.data(), (std::streamsize)n);
                left -= n; pos += n; done += n;
                PostMessageW(g_hwnd, WM_PROGRESS, (WPARAM)(total ? done * 1000 / total : 0), 0);
            }
            postStatus("Extracting " + f.path);
        }
    } catch (const std::exception &e) {
        postStatus(std::string("Error: ") + e.what());
        PostMessageW(g_hwnd, WM_DONE, 0, 0);
        return;
    }
    iniSet(L"Paths", L"game_dir", L"");
    PostMessageW(g_hwnd, WM_DONE, 1, 0);
}

static void pickIso()
{
    if (g_busy) return;
    wchar_t file[MAX_PATH] = L"";
    OPENFILENAMEW ofn{sizeof(ofn)};
    ofn.hwndOwner = g_hwnd;
    ofn.lpstrFilter = L"Xbox disc image (*.iso;*.xiso)\0*.iso;*.xiso\0All files\0*.*\0";
    ofn.lpstrFile = file;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_FILEMUSTEXIST;
    if (!GetOpenFileNameW(&ofn)) return;
    g_busy = true;
    EnableWindow(g_play, FALSE);
    setStatus(L"Checking disc...");
    std::thread(extractIso, fs::path(file)).detach();
}

static void pickFolder()
{
    BROWSEINFOW bi{};
    bi.hwndOwner = g_hwnd;
    bi.lpszTitle = L"Select the extracted The Two Towers disc folder (contains default.xbe)";
    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    LPITEMIDLIST p = SHBrowseForFolderW(&bi);
    if (!p) return;
    wchar_t path[MAX_PATH];
    bool ok = SHGetPathFromIDListW(p, path);
    CoTaskMemFree(p);
    if (!ok) return;
    std::string why;
    if (!xbeOk(path, &why)) { MessageBoxW(g_hwnd, W(why).c_str(), kTitle, MB_ICONWARNING); return; }
    iniSet(L"Paths", L"game_dir", path);
    refreshStatus();
}

static void saveSettings()
{
    iniSet(L"Display", L"window", SendMessageW(g_wide, BM_GETCHECK, 0, 0) == BST_CHECKED ? L"1" : L"0");
    iniSet(L"Developer", L"logging", SendMessageW(g_log, BM_GETCHECK, 0, 0) == BST_CHECKED ? L"1" : L"0");
}

static void loadSettings()
{
    SendMessageW(g_wide, BM_SETCHECK, iniGet(L"Display", L"window", L"1") == L"1" ? BST_CHECKED : BST_UNCHECKED, 0);
    SendMessageW(g_log, BM_SETCHECK, iniGet(L"Developer", L"logging", L"1") == L"1" ? BST_CHECKED : BST_UNCHECKED, 0);
}


// ───────────────────────────── Graphics settings ─────────────────────────────
// A small modal window with one drop-down per [Display] option. The same
// options are available in game (F10, or hold Back + press Start).

struct GfxChoice { const wchar_t *label, *value; };
struct GfxOpt {
    const wchar_t *label, *key, *def;
    std::vector<GfxChoice> choices;
    HWND lbl = nullptr, combo = nullptr;
    std::wstring extra;   // a custom ini value not in the list, kept as an extra item
    const wchar_t *sec = L"Display";
};

static std::vector<GfxOpt> g_gfx;
static HWND g_gfxWnd;
static bool g_gfxDone;

static void gfxBuildOptions()
{
    g_gfx.clear();
    g_gfx.push_back({L"Frame rate", L"fps", L"30",
        {{L"30 fps (as on the Xbox)", L"30"}, {L"60 fps (experimental)", L"60"}, {L"Unlocked (experimental)", L"unlocked"}}});
    g_gfx.push_back({L"Display mode", L"fullscreen", L"0",
        {{L"Windowed", L"0"}, {L"Full screen (borderless)", L"1"}}});
    g_gfx.push_back({L"Window size", L"window_size", L"",
        {{L"Automatic", L""}, {L"1280 x 720", L"1280x720"}, {L"1280 x 960", L"1280x960"}, {L"1600 x 900", L"1600x900"},
         {L"1920 x 1080", L"1920x1080"}, {L"1920 x 1200", L"1920x1200"}, {L"2560 x 1080", L"2560x1080"},
         {L"2560 x 1440", L"2560x1440"}, {L"3440 x 1440", L"3440x1440"}, {L"3840 x 2160", L"3840x2160"},
         {L"5120 x 1440", L"5120x1440"}}});
    g_gfx.push_back({L"Aspect ratio", L"aspect", L"4:3",
        {{L"4:3 (original)", L"4:3"}, {L"16:9 widescreen", L"16:9"}, {L"16:10", L"16:10"},
         {L"21:9 ultrawide", L"21:9"}, {L"32:9 super ultrawide", L"32:9"}}});
    g_gfx.push_back({L"Internal resolution", L"render_scale", L"1",
        {{L"1x  (640 x 480, original)", L"1"}, {L"2x  (1280 x 960)", L"2"}, {L"3x  (1920 x 1440)", L"3"}, {L"4x  (2560 x 1920)", L"4"}}});
    g_gfx.push_back({L"Anisotropic filtering", L"anisotropic", L"1",
        {{L"Off", L"1"}, {L"2x", L"2"}, {L"4x", L"4"}, {L"8x", L"8"}, {L"16x", L"16"}}});
    g_gfx.push_back({L"Mipmaps", L"mipmaps", L"1", {{L"On (less shimmer)", L"1"}, {L"Off", L"0"}}});
    g_gfx.push_back({L"Anti-aliasing", L"antialiasing", L"off", {{L"Off", L"off"}, {L"FXAA", L"fxaa"}}});
    g_gfx.push_back({L"VSync", L"vsync", L"0", {{L"Off", L"0"}, {L"On (no tearing)", L"1"}}});
    g_gfx.push_back({L"Picture shape", L"stretch", L"0", {{L"Keep aspect (black bars)", L"0"}, {L"Stretch to fill", L"1"}}});
    g_gfx.push_back({L"Vertex programs", L"vertex_programs", L"gpu",
        {{L"Graphics card (faster)", L"gpu"}, {L"CPU (old method)", L"cpu"}}});
    g_gfx.push_back({L"Brightness", L"brightness", L"1",
        {{L"Darker", L"0.85"}, {L"Original", L"1"}, {L"Brighter", L"1.15"}, {L"Brighter +", L"1.3"}, {L"Brightest", L"1.45"}}});
    g_gfx.push_back({L"Sharpening", L"sharpening", L"0",
        {{L"Off", L"0"}, {L"Low", L"0.4"}, {L"Medium", L"0.7"}, {L"High", L"1"}}});
    g_gfx.push_back({L"Colour", L"colour", L"1", {{L"Original", L"1"}, {L"Vivid", L"1.25"}, {L"Muted", L"0.8"}}});
    g_gfx.push_back({L"Mod: ECTS 2002 HUD (experimental)", L"e3_hud", L"0",
        {{L"Off (retail HUD)", L"0"}, {L"On (ECTS 2002 demo HUD)", L"1"}}});
    g_gfx.back().sec = L"Mods";
    g_gfx.push_back({L"Mod: Orange health pickups (shown in pre-release & making-of videos)", L"e3_pickups", L"0",
        {{L"Off (green, as retail)", L"0"}, {L"On (orange health pickups)", L"1"}}});
    g_gfx.back().sec = L"Mods";
    g_gfx.push_back({L"Mod: Extra heroes (Boromir, Gandalf, Frodo, Lurtz; unlock with Isildur)", L"extra_heroes", L"0",
        {{L"Off (four heroes, as retail)", L"0"}, {L"On (eight heroes)", L"1"},
         {L"On, unlocked for testing (save not changed)", L"2"}}});
    g_gfx.back().sec = L"Mods";
}

static void gfxLoad(bool defaults)
{
    for (auto &o : g_gfx) {
        std::wstring v = defaults ? std::wstring(o.def) : iniGet(o.sec, o.key, o.def);
        SendMessageW(o.combo, CB_RESETCONTENT, 0, 0);
        int sel = -1;
        for (size_t i = 0; i < o.choices.size(); i++) {
            SendMessageW(o.combo, CB_ADDSTRING, 0, (LPARAM)o.choices[i].label);
            if (_wcsicmp(o.choices[i].value, v.c_str()) == 0) sel = (int)i;
        }
        o.extra.clear();
        if (sel < 0 && !v.empty()) {      // a custom value typed into the ini
            o.extra = v;
            sel = (int)SendMessageW(o.combo, CB_ADDSTRING, 0, (LPARAM)(L"Custom: " + v).c_str());
        }
        SendMessageW(o.combo, CB_SETCURSEL, sel < 0 ? 0 : sel, 0);
    }
}

static void gfxSave()
{
    for (auto &o : g_gfx) {
        int i = (int)SendMessageW(o.combo, CB_GETCURSEL, 0, 0);
        std::wstring v;
        if (i >= 0 && i < (int)o.choices.size()) v = o.choices[i].value;
        else if (i >= (int)o.choices.size()) v = o.extra;
        else v = o.def;
        iniSet(o.sec, o.key, v);
    }
}

enum { ID_GFX_OK = 300, ID_GFX_CANCEL, ID_GFX_DEFAULTS };

static LRESULT CALLBACK gfxProc(HWND h, UINT m, WPARAM wp, LPARAM lp)
{
    switch (m) {
    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case ID_GFX_OK: gfxSave(); DestroyWindow(h); return 0;
        case IDCANCEL:
        case ID_GFX_CANCEL: DestroyWindow(h); return 0;
        case ID_GFX_DEFAULTS: gfxLoad(true); return 0;
        }
        break;
    case WM_CTLCOLORSTATIC: SetBkMode((HDC)wp, TRANSPARENT); return (LRESULT)GetSysColorBrush(COLOR_WINDOW);
    case WM_CLOSE: DestroyWindow(h); return 0;
    case WM_DESTROY: g_gfxDone = true; return 0;
    }
    return DefWindowProcW(h, m, wp, lp);
}

static void graphicsSettings()
{
    static bool reg = false;
    HINSTANCE inst = GetModuleHandleW(nullptr);
    if (!reg) {
        WNDCLASSEXW wc{sizeof(wc)};
        wc.lpfnWndProc = gfxProc;
        wc.hInstance = inst;
        wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
        wc.hbrBackground = GetSysColorBrush(COLOR_WINDOW);
        wc.lpszClassName = L"TwoTowersGfx";
        wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(1));
        RegisterClassExW(&wc);
        reg = true;
    }
    gfxBuildOptions();
    int fh = g_fontH, M = std::max(14, fh), gap = std::max(6, fh / 2), ch = fh + fh / 2 + 8;
    int labW = fh * 11, comboW = fh * 17;
    int cw = M + labW + gap + comboW + M;
    int rows = (int)g_gfx.size();
    int noteH = fh * 3;
    /* a label too long for its column wraps: that row gets the text's height */
    std::vector<int> rowH(rows, ch);
    {
        HDC dc = GetDC(nullptr);
        HGDIOBJ of = SelectObject(dc, g_font);
        for (int i = 0; i < rows; i++) {
            RECT r{0, 0, labW, 0};
            DrawTextW(dc, g_gfx[i].label, -1, &r, DT_CALCRECT | DT_WORDBREAK | DT_NOPREFIX);
            if (r.bottom + 4 > ch) rowH[i] = r.bottom + 4;
        }
        SelectObject(dc, of);
        ReleaseDC(nullptr, dc);
    }
    int chH = M + noteH + gap + ch + M;
    for (int i = 0; i < rows; i++) chH += rowH[i] + gap;
    DWORD style = WS_POPUP | WS_CAPTION | WS_SYSMENU;
    RECT wr{0, 0, cw, chH};
    AdjustWindowRect(&wr, style, FALSE);
    RECT pr;
    GetWindowRect(g_hwnd, &pr);
    int ww = wr.right - wr.left, wh = wr.bottom - wr.top;
    int wx = pr.left + ((pr.right - pr.left) - ww) / 2, wy = pr.top + ((pr.bottom - pr.top) - wh) / 2;
    {
        RECT wa;
        SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
        wx = std::max<int>(wa.left, std::min<int>(wx, wa.right - ww));
        wy = std::max<int>(wa.top, std::min<int>(wy, wa.bottom - wh));
    }
    g_gfxWnd = CreateWindowExW(WS_EX_DLGMODALFRAME, L"TwoTowersGfx", L"Graphics settings", style,
                               wx, wy, ww, wh, g_hwnd, nullptr, inst, nullptr);
    auto child = [&](const wchar_t *cls, const wchar_t *t, DWORD st, int id, int x, int y, int w, int hh) {
        HWND c = CreateWindowExW(0, cls, t, WS_CHILD | WS_VISIBLE | st, x, y, w, hh, g_gfxWnd, (HMENU)(INT_PTR)id, inst, nullptr);
        SendMessageW(c, WM_SETFONT, (WPARAM)g_font, TRUE);
        return c;
    };
    int y = M;
    for (size_t i = 0; i < g_gfx.size(); i++) {
        auto &o = g_gfx[i];
        int rh = rowH[i];
        if (rh == ch)
            o.lbl = child(L"STATIC", o.label, SS_LEFT | SS_NOPREFIX, -1, M, y + (ch - fh) / 2, labW, fh + 4);
        else
            o.lbl = child(L"STATIC", o.label, SS_LEFT | SS_NOPREFIX, -1, M, y, labW, rh);
        o.combo = child(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_VSCROLL | WS_TABSTOP, 400 + (int)i, M + labW + gap,
                        y + (rh - ch) / 2, comboW, ch + fh * 14);
        y += rh + gap;
    }
    child(L"STATIC", L"All but the mods can also be changed while playing: press F10 (or hold Back and press Start). "
                     L"The mods are set here and take effect when the game starts.", SS_LEFT, -1, M, y, cw - 2 * M, noteH);
    y += noteH + gap;
    int bw = fh * 6;
    child(L"BUTTON", L"Defaults", WS_TABSTOP, ID_GFX_DEFAULTS, M, y, bw, ch);
    child(L"BUTTON", L"OK", BS_DEFPUSHBUTTON | WS_TABSTOP, ID_GFX_OK, cw - M - 2 * bw - gap, y, bw, ch);
    child(L"BUTTON", L"Cancel", WS_TABSTOP, ID_GFX_CANCEL, cw - M - bw, y, bw, ch);
    gfxLoad(false);

    EnableWindow(g_hwnd, FALSE);
    ShowWindow(g_gfxWnd, SW_SHOW);
    g_gfxDone = false;
    MSG msg;
    while (!g_gfxDone && GetMessageW(&msg, nullptr, 0, 0)) {
        if (!IsDialogMessageW(g_gfxWnd, &msg)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    }
    EnableWindow(g_hwnd, TRUE);
    SetForegroundWindow(g_hwnd);
    g_gfxWnd = nullptr;
}

// ───────────────────────────── Controls ─────────────────────────────
// Same actions, names and rules as the game (xboxrecomp src/input/input_bind.c):
// [Controls] kb_<action>=K, Mouse Left   pad_<action>=A

struct CtlAct { const char *key; const wchar_t *name; bool button; };
static const CtlAct kCtl[] = {
    {"a", L"A button", true}, {"b", L"B button", true}, {"x", L"X button", true}, {"y", L"Y button", true},
    {"black", L"Black button", true}, {"white", L"White button", true},
    {"lt", L"Left trigger", true}, {"rt", L"Right trigger", true},
    {"start", L"Start", true}, {"back", L"Back", true},
    {"dpad_up", L"D-pad up", true}, {"dpad_down", L"D-pad down", true},
    {"dpad_left", L"D-pad left", true}, {"dpad_right", L"D-pad right", true},
    {"ls_click", L"Left stick click", true}, {"rs_click", L"Right stick click", true},
    {"move_up", L"Move forward", false}, {"move_down", L"Move back", false},
    {"move_left", L"Move left", false}, {"move_right", L"Move right", false},
    {"look_up", L"Right stick up", false}, {"look_down", L"Right stick down", false},
    {"look_left", L"Right stick left", false}, {"look_right", L"Right stick right", false},
};
static const int kCtlN = (int)(sizeof kCtl / sizeof kCtl[0]);
static const wchar_t *kPadSrc[] = {L"None", L"A", L"B", L"X", L"Y", L"LB", L"RB", L"LT", L"RT", L"Start", L"Back",
                                   L"D-pad up", L"D-pad down", L"D-pad left", L"D-pad right", L"LS click", L"RS click"};
static const int kPadSrcN = 17;
static const struct { int vk; const wchar_t *name; } kKeyNames[] = {
    {VK_LBUTTON, L"Mouse Left"}, {VK_RBUTTON, L"Mouse Right"}, {VK_MBUTTON, L"Mouse Middle"},
    {VK_XBUTTON1, L"Mouse 4"}, {VK_XBUTTON2, L"Mouse 5"},
    {VK_SPACE, L"Space"}, {VK_RETURN, L"Enter"}, {VK_ESCAPE, L"Esc"}, {VK_TAB, L"Tab"},
    {VK_BACK, L"Backspace"}, {VK_SHIFT, L"Shift"}, {VK_CONTROL, L"Ctrl"}, {VK_MENU, L"Alt"},
    {VK_CAPITAL, L"Caps Lock"}, {VK_UP, L"Up"}, {VK_DOWN, L"Down"}, {VK_LEFT, L"Left"},
    {VK_RIGHT, L"Right"}, {VK_INSERT, L"Insert"}, {VK_DELETE, L"Delete"}, {VK_HOME, L"Home"},
    {VK_END, L"End"}, {VK_PRIOR, L"Page Up"}, {VK_NEXT, L"Page Down"},
    {VK_NUMPAD0, L"Num 0"}, {VK_NUMPAD1, L"Num 1"}, {VK_NUMPAD2, L"Num 2"}, {VK_NUMPAD3, L"Num 3"},
    {VK_NUMPAD4, L"Num 4"}, {VK_NUMPAD5, L"Num 5"}, {VK_NUMPAD6, L"Num 6"}, {VK_NUMPAD7, L"Num 7"},
    {VK_NUMPAD8, L"Num 8"}, {VK_NUMPAD9, L"Num 9"}, {VK_MULTIPLY, L"Num *"}, {VK_ADD, L"Num +"},
    {VK_SUBTRACT, L"Num -"}, {VK_DECIMAL, L"Num ."}, {VK_DIVIDE, L"Num /"},
    {VK_OEM_1, L"Semicolon"}, {VK_OEM_PLUS, L"Equals"}, {VK_OEM_COMMA, L"Comma"}, {VK_OEM_MINUS, L"Minus"},
    {VK_OEM_PERIOD, L"Period"}, {VK_OEM_2, L"Slash"}, {VK_OEM_3, L"Backquote"}, {VK_OEM_4, L"["},
    {VK_OEM_5, L"Backslash"}, {VK_OEM_6, L"]"}, {VK_OEM_7, L"Quote"},
};

static std::wstring keyName(int vk)
{
    for (auto &k : kKeyNames) if (k.vk == vk) return k.name;
    if ((vk >= 'A' && vk <= 'Z') || (vk >= '0' && vk <= '9')) return std::wstring(1, (wchar_t)vk);
    if (vk >= VK_F1 && vk <= VK_F24) return L"F" + std::to_wstring(vk - VK_F1 + 1);
    wchar_t b[16]; swprintf(b, 16, L"Key %02X", vk & 0xFF); return b;
}
static int keyFromName(std::wstring s)
{
    while (!s.empty() && s.front() == L' ') s.erase(s.begin());
    while (!s.empty() && s.back() == L' ') s.pop_back();
    if (s.empty() || s == L"-") return 0;
    for (auto &k : kKeyNames) if (!_wcsicmp(k.name, s.c_str())) return k.vk;
    if (s.size() == 1 && iswalnum(s[0])) return towupper(s[0]);
    if ((s[0] == L'F' || s[0] == L'f') && _wtoi(s.c_str() + 1) >= 1 && _wtoi(s.c_str() + 1) <= 24) return VK_F1 + _wtoi(s.c_str() + 1) - 1;
    if (!_wcsnicmp(s.c_str(), L"Key ", 4)) return (int)wcstol(s.c_str() + 4, nullptr, 16);
    return 0;
}

struct CtlState { int kb[24][3]; int pad[24]; };
static CtlState ctlDefaults(bool classic)
{
    CtlState c{};
    auto set = [&](int a, int k0, int k1 = 0, int k2 = 0) { c.kb[a][0] = k0; c.kb[a][1] = k1; c.kb[a][2] = k2; };
    for (int a = 0; a < 16; a++) c.pad[a] = a + 1;      // A B X Y LB(Black) RB(White) LT RT Start Back pad LS RS
    set(10, VK_UP); set(11, VK_DOWN); set(12, VK_LEFT); set(13, VK_RIGHT);
    if (classic) {
        set(0, 'Z'); set(1, 'X'); set(2, 'A'); set(3, 'S'); set(5, 'Q'); set(4, 'E'); set(6, '1'); set(7, '3');
        set(8, VK_RETURN); set(9, VK_BACK); set(14, VK_SHIFT); set(15, VK_CONTROL);
        set(16, VK_NUMPAD8); set(17, VK_NUMPAD2); set(18, VK_NUMPAD4); set(19, VK_NUMPAD6);
        set(20, 'I'); set(21, 'K'); set(22, 'J'); set(23, 'L');
    } else {
        set(0, 'K', VK_LBUTTON, VK_SPACE); set(1, 'L'); set(2, 'J', VK_RBUTTON); set(3, 'I');
        set(5, 'Z'); set(4, 'C'); set(6, 'F'); set(7, 'R');
        set(8, VK_RETURN, VK_ESCAPE); set(9, VK_BACK, VK_TAB); set(14, VK_SHIFT); set(15, VK_MBUTTON);
        set(16, 'W'); set(17, 'S'); set(18, 'A'); set(19, 'D');
        set(20, VK_NUMPAD8); set(21, VK_NUMPAD2); set(22, VK_NUMPAD4); set(23, VK_NUMPAD6);
    }
    return c;
}
static bool layoutClassic() { std::wstring l = iniGet(L"Input", L"layout", L"wasd"); return !l.empty() && (l[0] == L'c' || l[0] == L'C'); }
static CtlState ctlLoad()
{
    CtlState c = ctlDefaults(layoutClassic());
    for (int a = 0; a < kCtlN; a++) {
        std::wstring k = L"kb_" + W(kCtl[a].key), v = iniGet(L"Controls", k.c_str(), L"\x01");
        if (v != L"\x01") {
            int i = 0;
            memset(c.kb[a], 0, sizeof c.kb[a]);
            size_t p = 0;
            while (p <= v.size() && i < 3) {
                size_t q = v.find(L',', p);
                int vk = keyFromName(v.substr(p, q == std::wstring::npos ? std::wstring::npos : q - p));
                if (vk) c.kb[a][i++] = vk;
                if (q == std::wstring::npos) break;
                p = q + 1;
            }
        }
        if (kCtl[a].button) {
            std::wstring pk = L"pad_" + W(kCtl[a].key), pv = iniGet(L"Controls", pk.c_str(), L"");
            for (int s2 = 0; s2 < kPadSrcN && !pv.empty(); s2++) if (!_wcsicmp(kPadSrc[s2], pv.c_str())) c.pad[a] = s2;
        }
    }
    return c;
}
static std::wstring keysText(const CtlState &c, int a)
{
    std::wstring t;
    for (int i = 0; i < 3; i++) if (c.kb[a][i]) { if (!t.empty()) t += L", "; t += keyName(c.kb[a][i]); }
    return t.empty() ? L"-" : t;
}
static void ctlSave(const CtlState &c)
{
    for (int a = 0; a < kCtlN; a++) {
        iniSet(L"Controls", (L"kb_" + W(kCtl[a].key)).c_str(), keysText(c, a));
        if (kCtl[a].button) iniSet(L"Controls", (L"pad_" + W(kCtl[a].key)).c_str(), kPadSrc[c.pad[a]]);
    }
}

enum { ID_CTL_OK = 600, ID_CTL_CANCEL, ID_CTL_DEFAULTS, ID_CTL_KEY = 700, ID_CTL_PAD = 800, ID_CTL_CLR = 900 };
static HWND g_ctlWnd, g_ctlKey[24], g_ctlPad[24], g_ctlHint;
static CtlState g_ctl;
static int g_ctlCapture = -1;
static bool g_ctlDone;

static void ctlRefresh()
{
    for (int a = 0; a < kCtlN; a++) {
        SetWindowTextW(g_ctlKey[a], a == g_ctlCapture ? L"press a key or mouse button…" : keysText(g_ctl, a).c_str());
        if (g_ctlPad[a]) SendMessageW(g_ctlPad[a], CB_SETCURSEL, g_ctl.pad[a], 0);
    }
    SetWindowTextW(g_ctlHint, g_ctlCapture >= 0
        ? L"Press the key or mouse button for this action (Esc cancels). It replaces the action's first key; other actions lose it."
        : L"Click a key box, then press a key or mouse button. The drop-downs choose which button of your controller does each action. These can also be changed in game: F10, Controls page.");
}

static void ctlAssignKey(int a, int vk)
{
    for (int b = 0; b < kCtlN; b++)
        for (int i = 0; i < 3; i++)
            if (g_ctl.kb[b][i] == vk) { for (int j = i; j < 2; j++) g_ctl.kb[b][j] = g_ctl.kb[b][j + 1]; g_ctl.kb[b][2] = 0; i--; }
    g_ctl.kb[a][2] = g_ctl.kb[a][1]; g_ctl.kb[a][1] = g_ctl.kb[a][0]; g_ctl.kb[a][0] = vk;
}

static LRESULT CALLBACK ctlProc(HWND h, UINT m, WPARAM wp, LPARAM lp)
{
    switch (m) {
    case WM_COMMAND: {
        int id = LOWORD(wp);
        if (id == ID_CTL_OK) { ctlSave(g_ctl); DestroyWindow(h); return 0; }
        if (id == ID_CTL_CANCEL || id == IDCANCEL) { DestroyWindow(h); return 0; }
        if (id == ID_CTL_DEFAULTS) { g_ctl = ctlDefaults(layoutClassic()); g_ctlCapture = -1; ctlRefresh(); return 0; }
        if (id >= ID_CTL_KEY && id < ID_CTL_KEY + kCtlN && HIWORD(wp) == BN_CLICKED) {
            g_ctlCapture = id - ID_CTL_KEY; ctlRefresh(); SetFocus(h); return 0;
        }
        if (id >= ID_CTL_CLR && id < ID_CTL_CLR + kCtlN) {
            memset(g_ctl.kb[id - ID_CTL_CLR], 0, sizeof g_ctl.kb[0]); g_ctlCapture = -1; ctlRefresh(); return 0;
        }
        if (id >= ID_CTL_PAD && id < ID_CTL_PAD + kCtlN && HIWORD(wp) == CBN_SELCHANGE) {
            int a = id - ID_CTL_PAD, src = (int)SendMessageW(g_ctlPad[a], CB_GETCURSEL, 0, 0), old = g_ctl.pad[a];
            if (src > 0) for (int b = 0; b < kCtlN; b++) if (b != a && kCtl[b].button && g_ctl.pad[b] == src) g_ctl.pad[b] = old;
            g_ctl.pad[a] = src; ctlRefresh(); return 0;
        }
        break;
    }
    case WM_CTLCOLORSTATIC: SetBkMode((HDC)wp, TRANSPARENT); return (LRESULT)GetSysColorBrush(COLOR_WINDOW);
    case WM_CLOSE: DestroyWindow(h); return 0;
    case WM_DESTROY: g_ctlDone = true; return 0;
    }
    return DefWindowProcW(h, m, wp, lp);
}

static void controlsSettings()
{
    static bool reg = false;
    HINSTANCE inst = GetModuleHandleW(nullptr);
    if (!reg) {
        WNDCLASSEXW wc{sizeof(wc)};
        wc.lpfnWndProc = ctlProc; wc.hInstance = inst; wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
        wc.hbrBackground = GetSysColorBrush(COLOR_WINDOW); wc.lpszClassName = L"TwoTowersCtl";
        wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(1));
        RegisterClassExW(&wc); reg = true;
    }
    g_ctl = ctlLoad(); g_ctlCapture = -1;
    int fh = g_fontH, M = std::max(14, fh), gap = std::max(4, fh / 3), rh = fh + 10;
    int labW = fh * 8, keyW = fh * 11, clrW = fh * 2, padW = fh * 7;
    int colW = labW + gap + keyW + gap / 2 + clrW + gap + padW;
    int half = (kCtlN + 1) / 2;
    int cw = M + colW + M * 2 + colW + M;
    int hintH = fh * 3, ch = fh + fh / 2 + 8;
    int chH = M + rh + half * (rh + gap / 2) + gap + hintH + gap + ch + M;
    DWORD style = WS_POPUP | WS_CAPTION | WS_SYSMENU;
    RECT wr{0, 0, cw, chH};
    AdjustWindowRect(&wr, style, FALSE);
    int ww = wr.right - wr.left, wh = wr.bottom - wr.top;
    RECT pr; GetWindowRect(g_hwnd, &pr);
    int wx = pr.left + ((pr.right - pr.left) - ww) / 2, wy = pr.top + ((pr.bottom - pr.top) - wh) / 2;
    { RECT wa; SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
      wx = std::max<int>(wa.left, std::min<int>(wx, wa.right - ww)); wy = std::max<int>(wa.top, std::min<int>(wy, wa.bottom - wh)); }
    g_ctlWnd = CreateWindowExW(WS_EX_DLGMODALFRAME, L"TwoTowersCtl", L"Controls", style, wx, wy, ww, wh, g_hwnd, nullptr, inst, nullptr);
    auto child = [&](const wchar_t *cls, const wchar_t *t, DWORD st, int id, int x, int y, int w, int hh) {
        HWND c = CreateWindowExW(0, cls, t, WS_CHILD | WS_VISIBLE | st, x, y, w, hh, g_ctlWnd, (HMENU)(INT_PTR)id, inst, nullptr);
        SendMessageW(c, WM_SETFONT, (WPARAM)g_font, TRUE);
        return c;
    };
    for (int col = 0; col < 2; col++) {
        int x0 = M + col * (colW + M * 2), y = M;
        child(L"STATIC", L"Action", 0, -1, x0, y + 4, labW, fh + 4);
        child(L"STATIC", L"Keyboard / mouse", 0, -1, x0 + labW + gap, y + 4, keyW, fh + 4);
        child(L"STATIC", L"Controller", 0, -1, x0 + labW + gap + keyW + gap / 2 + clrW + gap, y + 4, padW, fh + 4);
        y += rh;
        for (int r = 0; r < half; r++) {
            int a = col * half + r;
            if (a >= kCtlN) break;
            int x = x0;
            child(L"STATIC", kCtl[a].name, 0, -1, x, y + (rh - fh) / 2, labW, fh + 4); x += labW + gap;
            g_ctlKey[a] = child(L"BUTTON", L"", WS_TABSTOP | BS_LEFT, ID_CTL_KEY + a, x, y, keyW, rh); x += keyW + gap / 2;
            child(L"BUTTON", L"×", WS_TABSTOP, ID_CTL_CLR + a, x, y, clrW, rh); x += clrW + gap;
            if (kCtl[a].button) {
                g_ctlPad[a] = child(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_VSCROLL | WS_TABSTOP, ID_CTL_PAD + a, x, y, padW, rh + fh * 12);
                for (int s2 = 0; s2 < kPadSrcN; s2++) SendMessageW(g_ctlPad[a], CB_ADDSTRING, 0, (LPARAM)kPadSrc[s2]);
            } else {
                g_ctlPad[a] = nullptr;
                child(L"STATIC", a >= 20 ? L"right stick" : L"left stick", 0, -1, x, y + (rh - fh) / 2, padW, fh + 4);
            }
            y += rh + gap / 2;
        }
    }
    int y = M + rh + half * (rh + gap / 2) + gap;
    g_ctlHint = child(L"STATIC", L"", SS_LEFT, -1, M, y, cw - 2 * M, hintH);
    y += hintH + gap;
    int bw = fh * 7;
    child(L"BUTTON", L"Defaults", WS_TABSTOP, ID_CTL_DEFAULTS, M, y, bw, ch);
    child(L"BUTTON", L"OK", BS_DEFPUSHBUTTON | WS_TABSTOP, ID_CTL_OK, cw - M - 2 * bw - gap, y, bw, ch);
    child(L"BUTTON", L"Cancel", WS_TABSTOP, ID_CTL_CANCEL, cw - M - bw, y, bw, ch);
    ctlRefresh();

    EnableWindow(g_hwnd, FALSE);
    ShowWindow(g_ctlWnd, SW_SHOW);
    g_ctlDone = false;
    MSG msg;
    while (!g_ctlDone && GetMessageW(&msg, nullptr, 0, 0)) {
        if (g_ctlCapture >= 0) {
            int vk = 0;
            switch (msg.message) {
            case WM_KEYDOWN: case WM_SYSKEYDOWN: vk = (int)msg.wParam; break;
            case WM_LBUTTONDOWN: vk = VK_LBUTTON; break;
            case WM_RBUTTONDOWN: vk = VK_RBUTTON; break;
            case WM_MBUTTONDOWN: vk = VK_MBUTTON; break;
            case WM_XBUTTONDOWN: vk = HIWORD(msg.wParam) == XBUTTON1 ? VK_XBUTTON1 : VK_XBUTTON2; break;
            }
            if (vk) {
                if (vk == VK_LSHIFT || vk == VK_RSHIFT) vk = VK_SHIFT;
                if (vk == VK_LCONTROL || vk == VK_RCONTROL) vk = VK_CONTROL;
                if (vk == VK_LMENU || vk == VK_RMENU) vk = VK_MENU;
                if (vk != VK_ESCAPE) ctlAssignKey(g_ctlCapture, vk);
                g_ctlCapture = -1;
                ctlRefresh();
                continue;   // the key / click is used up
            }
        }
        if (!IsDialogMessageW(g_ctlWnd, &msg)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    }
    EnableWindow(g_hwnd, TRUE);
    SetForegroundWindow(g_hwnd);
    g_ctlWnd = nullptr;
}

static void play()
{
    saveSettings();
    fs::path exe = exeDir() / L"twotowers_recomp.exe";
    STARTUPINFOW si{sizeof(si)};
    PROCESS_INFORMATION pi{};
    std::wstring cmd = L"\"" + exe.wstring() + L"\"";
    if (!CreateProcessW(nullptr, &cmd[0], nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, exeDir().c_str(), &si, &pi)) {
        MessageBoxW(g_hwnd, L"Could not start twotowers_recomp.exe.", kTitle, MB_ICONERROR);
        return;
    }
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    DestroyWindow(g_hwnd);
}

static HWND mk(const wchar_t *cls, const wchar_t *t, DWORD style, int id, DWORD ex = 0)
{
    HWND c = CreateWindowExW(ex, cls, t, WS_CHILD | WS_VISIBLE | style, 0, 0, 10, 10, g_hwnd, (HMENU)(INT_PTR)id, GetModuleHandleW(nullptr), nullptr);
    SendMessageW(c, WM_SETFONT, (WPARAM)g_font, TRUE);
    return c;
}

static int textW(HWND c)
{
    int n = GetWindowTextLengthW(c);
    std::wstring t(n, 0);
    GetWindowTextW(c, &t[0], n + 1);
    HDC dc = GetDC(c);
    HGDIOBJ o = SelectObject(dc, g_font);
    SIZE sz{};
    GetTextExtentPoint32W(dc, t.c_str(), n, &sz);
    SelectObject(dc, o);
    ReleaseDC(c, dc);
    return sz.cx;
}

static HWND g_cover;
static bool g_hasCover;   // box art: built in (resources/local/cover.bmp) or cover.bmp beside the exe
static HWND g_lblTitle, g_lblRes, g_lblMode, g_lblInt, g_btnIso, g_btnDir, g_btnOpen, g_btnGfx, g_btnCtl;

static int layout(bool apply)
{
    RECT r;
    GetClientRect(g_hwnd, &r);
    int W_ = r.right, fh = g_fontH, M = std::max(14, fh), gap = std::max(6, fh / 2);
    int lh = fh + 6, ch = fh + fh / 2 + 8, y = M;
    // Cover art column on the left, settings column on the right.
    int picW = g_hasCover ? fh * 15 : 0, picH = picW * 385 / 369;
    int L = g_hasCover ? M + picW + M : M;   // left edge of the settings column
    auto mv = [&](HWND h, int x, int yy, int w, int hh) { if (apply) MoveWindow(h, x - M + L, yy, w, hh, TRUE); };
    if (apply) MoveWindow(g_cover, M, M, picW, picH, TRUE);
    W_ -= L - M;                        // settings column width budget
    mv(g_lblTitle, M, y, W_ - 2 * M, lh); y += lh + gap;
    mv(g_status, M, y, W_ - 2 * M, lh * 2); y += lh * 2 + gap;
    mv(g_progress, M, y, W_ - 2 * M, fh); y += fh + gap * 2;
    int bw1 = textW(g_btnIso) + 2 * fh, bw2 = textW(g_btnDir) + 2 * fh;
    mv(g_btnIso, M, y, bw1, ch); mv(g_btnDir, M + bw1 + gap, y, bw2, ch); y += ch + gap * 2;
    for (HWND c : {g_wide, g_log}) { mv(c, M, y, textW(c) + 3 * fh, lh); y += lh + gap / 2; }
    y += gap;
    { int w1 = textW(g_btnGfx) + 2 * fh; mv(g_btnGfx, M, y, w1, ch); mv(g_btnCtl, M + w1 + gap, y, textW(g_btnCtl) + 2 * fh, ch); }
    y += ch + gap * 2;
    int pw = textW(g_play) + 4 * fh, ow = textW(g_btnOpen) + 2 * fh;
    mv(g_play, M, y, pw, ch + 4); mv(g_btnOpen, M + pw + gap, y, ow, ch + 4);
    y += ch + 4 + M;
    return std::max(y, M + picH + M);
}

static LRESULT CALLBACK proc(HWND h, UINT m, WPARAM wp, LPARAM lp)
{
    switch (m) {
    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case ID_ISO: pickIso(); return 0;
        case ID_DIR: pickFolder(); return 0;
        case ID_PLAY: play(); return 0;
        case ID_GFX: graphicsSettings(); return 0;
        case ID_CTL: controlsSettings(); return 0;
        case ID_OPEN: ShellExecuteW(nullptr, L"open", exeDir().c_str(), nullptr, nullptr, SW_SHOWNORMAL); return 0;
        }
        break;
    case WM_STATUS: { auto s = (std::wstring *)lp; setStatus(*s); delete s; return 0; }
    case WM_PROGRESS: SendMessageW(g_progress, PBM_SETPOS, wp, 0); return 0;
    case WM_DONE:
        g_busy = false;
        if (wp) { SendMessageW(g_progress, PBM_SETPOS, 1000, 0); refreshStatus(); }
        else EnableWindow(g_play, FALSE);
        return 0;
    case WM_SIZE: layout(true); return 0;
    case WM_CTLCOLORSTATIC: SetBkMode((HDC)wp, TRANSPARENT); return (LRESULT)GetSysColorBrush(COLOR_WINDOW);
    case WM_CLOSE:
        if (g_busy && MessageBoxW(h, L"Extraction is still running. Quit anyway?", kTitle, MB_YESNO) != IDYES) return 0;
        saveSettings();
        DestroyWindow(h);
        return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(h, m, wp, lp);
}

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE, PWSTR cmdLine, int show)
{
    SetProcessDPIAware();
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    INITCOMMONCONTROLSEX icc{sizeof(icc), ICC_STANDARD_CLASSES | ICC_PROGRESS_CLASS};
    InitCommonControlsEx(&icc);
    NONCLIENTMETRICSW ncm{sizeof(ncm)};
    SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, sizeof(ncm), &ncm, 0);
    g_font = CreateFontIndirectW(&ncm.lfMessageFont);
    {
        HDC dc = GetDC(nullptr);
        HGDIOBJ o = SelectObject(dc, g_font);
        TEXTMETRICW tm{};
        GetTextMetricsW(dc, &tm);
        SelectObject(dc, o);
        ReleaseDC(nullptr, dc);
        g_fontH = std::max<int>(14, tm.tmHeight + tm.tmExternalLeading);
    }
    WNDCLASSEXW wc{sizeof(wc)};
    wc.lpfnWndProc = proc;
    wc.hInstance = inst;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = GetSysColorBrush(COLOR_WINDOW);
    wc.lpszClassName = L"TwoTowersLauncher";
    wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(1));
    RegisterClassExW(&wc);
    DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
    g_hwnd = CreateWindowExW(0, wc.lpszClassName, kTitle, style, CW_USEDEFAULT, CW_USEDEFAULT, g_fontH * 40, g_fontH * 40, nullptr, nullptr, inst, nullptr);

    g_lblTitle = mk(L"STATIC", L"The Lord of the Rings: The Two Towers  -  native PC recompilation", 0, -1);
    g_status = mk(L"STATIC", L"", 0, ID_STATUS);
    g_progress = mk(PROGRESS_CLASSW, L"", 0, ID_PROGRESS);
    SendMessageW(g_progress, PBM_SETRANGE32, 0, 1000);
    g_btnIso = mk(L"BUTTON", L"Install from ISO…", WS_TABSTOP, ID_ISO);
    g_btnDir = mk(L"BUTTON", L"Use extracted folder…", WS_TABSTOP, ID_DIR);
    g_wide = mk(L"BUTTON", L"Show the game window", BS_AUTOCHECKBOX | WS_TABSTOP, ID_WIDE);
    g_log = mk(L"BUTTON", L"Write a log file (for bug reports)", BS_AUTOCHECKBOX | WS_TABSTOP, ID_LOG);
    g_btnGfx = mk(L"BUTTON", L"Graphics settings…", WS_TABSTOP, ID_GFX);
    g_btnCtl = mk(L"BUTTON", L"Controls…", WS_TABSTOP, ID_CTL);
    g_play = mk(L"BUTTON", L"Play", BS_DEFPUSHBUTTON | WS_TABSTOP, ID_PLAY);
    g_btnOpen = mk(L"BUTTON", L"Open folder", WS_TABSTOP, ID_OPEN);
    // Box art (your own disc's cover), scaled into the picture control.
    g_cover = mk(L"STATIC", L"", SS_BITMAP | SS_REALSIZECONTROL, -1);
    {
        HBITMAP cover = (HBITMAP)LoadImageW(inst, MAKEINTRESOURCEW(2), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION);
        if (!cover)
            cover = (HBITMAP)LoadImageW(nullptr, (exeDir() / L"cover.bmp").c_str(), IMAGE_BITMAP, 0, 0,
                                        LR_LOADFROMFILE | LR_CREATEDIBSECTION);
        if (cover) { SendMessageW(g_cover, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)cover); g_hasCover = true; }
        else ShowWindow(g_cover, SW_HIDE);
    }

    loadSettings();

    // Size the window to fit the measured layout.
    RECT wr{0, 0, g_fontH * 34 + (g_hasCover ? g_fontH * 15 + std::max(14, g_fontH) : 0), 0};
    int contentH = layout(false);
    wr.bottom = contentH;
    AdjustWindowRect(&wr, style, FALSE);
    SetWindowPos(g_hwnd, nullptr, 0, 0, wr.right - wr.left, wr.bottom - wr.top, SWP_NOMOVE | SWP_NOZORDER);
    layout(true);
    refreshStatus();
    ShowWindow(g_hwnd, show);
    /* "The Two Towers Recompiled.exe" --graphics opens the settings directly */
    if (cmdLine && wcsstr(cmdLine, L"--graphics")) { UpdateWindow(g_hwnd); graphicsSettings(); }
    if (cmdLine && wcsstr(cmdLine, L"--controls")) { UpdateWindow(g_hwnd); controlsSettings(); }

    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0)) {
        if (!IsDialogMessageW(g_hwnd, &msg)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    }
    return 0;
}
