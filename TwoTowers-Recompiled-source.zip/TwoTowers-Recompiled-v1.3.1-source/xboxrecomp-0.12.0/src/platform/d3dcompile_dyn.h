/* d3dcompile_dyn.h -- the HLSL compiler (D3DCompile), loaded at run time.
 * Include after <d3dcompiler.h>. */
#ifndef XBOXRECOMP_D3DCOMPILE_DYN_H
#define XBOXRECOMP_D3DCOMPILE_DYN_H
#include <stdio.h>
/* The HLSL compiler, loaded at run time. d3dcompiler_47 is part of Windows
 * 8.1 and later; Windows 7 has it only with KB4019990 or beside a program
 * that ships it, but most have the DirectX redistributable's 43. A static
 * import of 47 stopped the game from starting on a Windows 7 without it;
 * now the newest one present is used, and with none the software renderer
 * draws instead (and says why). */
typedef HRESULT (WINAPI *PFN_tt_D3DCompile)(LPCVOID, SIZE_T, LPCSTR, const D3D_SHADER_MACRO *, ID3DInclude *,
                                            LPCSTR, LPCSTR, UINT, UINT, ID3DBlob **, ID3DBlob **);
static PFN_tt_D3DCompile s_d3dcompile;
static int d3dcompiler_load(void)
{
    static int tried;
    static const char *const dlls[] = { "d3dcompiler_47.dll", "d3dcompiler_46.dll", "d3dcompiler_45.dll",
                                        "d3dcompiler_44.dll", "d3dcompiler_43.dll" };
    int i;
    if (tried) return s_d3dcompile != NULL;
    tried = 1;
    for (i = 0; i < 5 && !s_d3dcompile; i++) {
        HMODULE m = LoadLibraryA(dlls[i]);
        if (m) s_d3dcompile = (PFN_tt_D3DCompile)(void *)GetProcAddress(m, "D3DCompile");
        if (s_d3dcompile) fprintf(stderr, "  [D3D11] shader compiler: %s\n", dlls[i]);
    }
    if (!s_d3dcompile)
        fprintf(stderr, "  [D3D11] no HLSL compiler (d3dcompiler_47.dll or _43.dll); using the software renderer. "
                        "Installing the DirectX End-User Runtime gives one.\n");
    return s_d3dcompile != NULL;
}
static HRESULT tt_D3DCompile(LPCVOID src, SIZE_T n, LPCSTR name, const D3D_SHADER_MACRO *defs, ID3DInclude *inc,
                             LPCSTR entry, LPCSTR target, UINT f1, UINT f2, ID3DBlob **code, ID3DBlob **err)
{
    if (!d3dcompiler_load()) { if (code) *code = NULL; if (err) *err = NULL; return E_NOTIMPL; }
    return s_d3dcompile(src, n, name, defs, inc, entry, target, f1, f2, code, err);
}
#define D3DCompile tt_D3DCompile
#endif
